class BaseException extends Exception {
    BaseException(String message) {
        super(message);
    }
}

class SubException extends BaseException {
    SubException(String message) {
        super(message);
    }
}

class ExceptionDemo {
    public static void main(String[] args) {
        try {
            
            throw new SubException("This is a SubException");
        }  catch (SubException e) {
            System.out.println("Caught SubException: " + e.getMessage());
        }
    }
}
