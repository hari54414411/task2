package pack;
class Threadclass implements Runnable
{

public void run()
{
int id=0;
System.out.println("thread:"+id++);
}

}


class Main
{
public static void main(String[] args)
{
Threadclass t=new Threadclass();
Thread t1=new Thread(t);
for(int i=0;i<4;i++)
{
t1.start();
}
}
}