class ExceptionFinally
{
public static void main(String[] args)
{
int a=5;int b=0,c;
try
{
c=a/b;
System.out.println("Div two number:"+c);

}
catch(ArithmeticException e)
{
System.out.println("Zero cannot div the num:"+e);
}
finally
{
c=a+b;
System.out.println("Adding two number:"+c);
}
}
}