class MyThread1 extends Thread {
    public MyThread1() {
        super("thread one");
        start(); 
    }

    public void run() {
System.out.println("CurrentThread:"+Thread.currentThread());
        System.out.println("Child thread is running");
    }
}

class Main1 {
    public static void main(String[] args)throws Exception {
        System.out.println("Main thread is running");

        MyThread1 myThread = new MyThread1();
            myThread.join();
     
        System.out.println("Main thread is done");

    }
}
