class Array
{
public static int Arr(int arr[],int index)
{
if (index < 0 || index >= arr.length) {
            throw new ArrayIndexOutOfBoundsException("Index out of bounds");
        }
        return arr[index];
}
public static void main(String[] args)
{
try 
{
int arr[]={1,2,3,4,5};
System.out.println(Arr(arr,5));

}
catch(ArrayIndexOutOfBoundsException e)
{
System.out.println("arraysoutofbound:"+e);
}
}
}