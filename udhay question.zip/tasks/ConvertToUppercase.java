import java.util.Scanner;
import java.io.*;

public class ConvertToUppercase {
    public static void main(String[] args) {
try{
Scanner scanner = new Scanner(System.in);
System.out.print("Enter characters: ");
        String input = scanner.nextLine();
        String uppercase = input.toUpperCase();
            FileWriter writer = new FileWriter("example1.txt");
            writer.write(uppercase);
            writer.close();
       
        scanner.close();
}
catch(Exception e)
{
System.out.println(e);
}
    }
}
