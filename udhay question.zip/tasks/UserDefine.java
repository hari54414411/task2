class MyCustomException extends Exception
{
public MyCustomException(String message)
{
super(message);
}
}

class MyClass
{
public void method(int num)throws MyCustomException
{
if(num<0)
{
throw new MyCustomException("Negative Value not allowed");
}
System.out.println("Value:"+num);
}
}
class UserDefine
{
public static void main(String[] args)
{
MyClass obj=new MyClass();
try
{
int num=-1;
obj.method(num);

}
catch(MyCustomException e)
{
System.out.println("My Custom Exception e"+e);
}
}
}