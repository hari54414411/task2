class ArrayNeg
{
public static void main(String[] args)
{
try
{
int arr[]=new int[5];
for(int i=0;i<arr.length;i++)
{
arr[i]=i+1;
System.out.println(arr[i]);
}
}
catch(NegativeArraySizeException e)
{
System.out.println("Array size in Negative:"+e);
}
}

}