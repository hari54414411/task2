import java.io.FileOutputStream;
import java.io.IOException;

public class WriteToFileOutputStream {
    public static void main(String[] args) {
        try {
            FileOutputStream fos = new FileOutputStream("output.txt");
            String data = "This is a sample data to write into the file.";
            byte[] byteArray = data.getBytes();
            fos.write(byteArray);
            fos.close();
            System.out.println("Data written to file successfully.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
}
