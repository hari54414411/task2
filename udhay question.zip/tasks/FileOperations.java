import java.io.File;

public class FileOperations {
    public static void main(String[] args) {
        File file = new File("C:\\AutoUpdates\\History");
        if (file.exists()) {
            System.out.println("File exists: " + file.getName());
            System.out.println("Absolute path: " + file.getAbsolutePath());
            System.out.println("Is a directory: " + file.isDirectory());
            System.out.println("Is a file: " + file.isFile());
        } else {
            System.out.println("File does not exist.");
        }
    }
}
