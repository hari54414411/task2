import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.Scanner;

public class StoreInputToFile {
    public static void main(String[] args) {
        try {
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter text to store in file: ");
            String input = scanner.nextLine();
            scanner.close();

            FileWriter writer = new FileWriter("user_input.txt");
            writer.write(input);
            writer.close();
            System.out.println("Input stored in file successfully.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
}
