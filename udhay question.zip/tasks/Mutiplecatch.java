class Mutiplecatch
{
public static void main(String[] args)
{
int i=5;int j=2,k;
int arr[]=new int[5];
try
{
k=i/j;
for(int a=0;a<=arr.length;a++)
{
arr[i]=a+1;
}
for(int values:arr)
{
System.out.println(values);
}
}
catch(ArithmeticException e)
{
System.out.println("Cannot Divide By Zero "+e);
}
catch(ArrayIndexOutOfBoundsException e)
{
System.out.println("Max number array is 4 "+e);
}
}
}