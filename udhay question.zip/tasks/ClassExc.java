class ClassExc
{
public static void main(String[] args)
{
try
{
Class.forName("classA.class");

}
catch(ClassNotFoundException e)
{
System.out.println("ClassNotFoundException:"+e);
}
}
}