class MYThread extends Thread
{
public void run()
{
System.out.println("Java is hot, aromatic, and invigorating");

}
}
class Concurrently 
{
public static void main(String[] args)
{
MYThread t1=new MYThread();
MYThread t2=new MYThread();

t1.start();
t2.start();

}
}