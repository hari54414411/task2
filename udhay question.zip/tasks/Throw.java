class Throw
{
public static int method(int a,int b)
{
int result=0;

if(b==0)
{
throw new ArithmeticException();
}
else
{
return result=a/b;
}
}
public static void main(String[] args)
{
try
{
int a=10;int b=0;
System.out.println(method(a,b));
}
catch(ArithmeticException e)
{
System.out.println("Error:"+e);
}


}
}