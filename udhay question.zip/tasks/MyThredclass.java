class MyThread extends Thread
{
MyThread()
{
super();
}
public void run()
{
System.out.println("Child thread is running");
}
}

class MyThredclass
{
public static void main(String[] args) throws Exception
{
MyThread t=new MyThread();

t.start();
t.join();
 System.out.println("Main thread is done");

}
}