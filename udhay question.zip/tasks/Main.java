package pack;
class Threadclass implements Runnable
{

public void run()
{
int id=0;
try
{


System.out.println("thread:"+Thread.getId());

}
catch(Exception e)
{
System.out.println(e);
}
}
}
class Main
{
public static void main(String[] args)
{
for(int i=0;i<100;i++)
{
Thread t1=new Thread();
t1.start();
}
}
}