class Threads1 implements Runnable
{
public void run()
{

for(int i=1;i<10;i++)
{
System.out.println("Thread running "+i);
try
{
Thread.sleep(5000);
}
catch(Exception e)
{
System.out.println(e);
}
}
}
}

class Threads
{
public static void main(String[] args)
{
Threads1 t=new Threads1();
Thread t1=new Thread(t);
t1.start();

}
}