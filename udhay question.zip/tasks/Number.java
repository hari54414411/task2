class Number
{
public static int method(String s)
{
try
{
int num=Integer.parseInt(s);
return num;
}
catch(NumberFormatException e)
{
throw new NumberFormatException();
}
}
public static void main(String[] args)
{
try
{
String s="abc";
System.out.println(method(s));
}
catch(NumberFormatException e)
{
System.out.println("Number not found"+e);
}
}
}