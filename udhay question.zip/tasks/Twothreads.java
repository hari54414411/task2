class Twothreads2 extends Thread
{
Twothreads2(String name)
{
super(name);
start();
}
public void run()
{
System.out.println("Thread running "+getName());

}
}

class  Twothreads
{
public static void main(String args[])
{
Twothreads2 t1=new Twothreads2("Thread one");
Twothreads2 t2=new Twothreads2("Thread two");

}
}