class Throws
{
public int Vaildage(int a,int b)throws Exception
{
int c=a/b;
return c;
}
public static void main(String[] args)
{
try
{
Throws t=new Throws();
System.out.println(t.Vaildage(17,0));
}
catch(Exception e)
{
System.out.println(e);
}
}
}