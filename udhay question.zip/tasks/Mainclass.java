class MyThread extends Thread
{
MyThread(Runnable name)
{
super(name);
}
}

class MyClass implements Runnable
{
String name;
 MyClass(String name)
{
this.name=name;
}
public void run()
{
System.out.println("Thread "+name+" is Running");

}
}

class Mainclass
{
public static void main(String[] args)
{
MyClass t=new MyClass("Thread1");
MyThread t1=new MyThread(t);
MyClass t2=new MyClass("Thread2");
MyThread t3=new MyThread(t2);

t1.start();
t3.start();

}
}