class Main
{
	public static String EncryptedPassword(String s)
	{	
		char[] temp=s.toCharArray();
		for(int i=0;i<temp.length;i++){
			char c=temp[i];
			switch(c)
			{
				case 'z':
					temp[i]='a';
					break;
				case 'Z':
					temp[i]='A';
					break;
				case '9':
					temp[i]='0';
					break;
				default:
					temp[i]=c++;
					
			}
		}
		return new String(temp);
	}
	public static void main(String[] args)
	{
		String s="AaabbD";
		System.out.println(EncryptedPassword(s));
	}
}