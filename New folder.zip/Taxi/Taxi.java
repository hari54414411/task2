class Taxi
{

	int TaxiID;
	static int id=1;
	String Currentend;
	double Totalearnings;
	String FreeTime;

	Taxi()
	{
		TaxiID=id++;
		Currentend="A";
		//Taxifree=true;
		FreeTime="6:00";
		Totalearnings=0.0;

	}
	public int getTaxiID()
	{
		return TaxiID;
	}

	public void setCurrentend(String s)
	{
		this.Currentend=s;
	}

	public String getCurrentend()
	{
		return Currentend;
	}

	public void setTotalearnings(double amount)
	{
		this.Totalearnings+=amount;
	}
	
	public double getTotalearnings()
	{
		return Totalearnings;
	}

	public void setFreeTime(String FreeTime)
	{
		this.FreeTime=FreeTime;
	}
	
	public String getFreeTime()
	{
		return FreeTime;
	}

	public String toString()
	{
		return TaxiID+" "+Currentend+" "+" "+Totalearnings;
	}
	

	

			
}