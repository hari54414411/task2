import java.util.*;
class DataBase
{
		
	Map<Integer,Trip> trip=new HashMap<>();
	List<Taxi> taxi=new ArrayList<>();
}