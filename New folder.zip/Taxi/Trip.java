class Trip
{
	int TripID;
	static int id=1;
	int TaxiID;
	String Pickup;
	String Drop;
	int Distance;	
	String Starttime;	
	String Endtime;
	Double amount;
	
	Trip(int TaxiID,String Pickup,String Drop,String Starttime,String Endtime,int Distance,Double amount)
	{
		this.TripID=id++;
		this.TaxiID=TaxiID;
		this.Pickup=Pickup;
		this.Drop=Drop;
		this.Distance=Distance;
		this.Starttime=Starttime;
		this.Endtime=Endtime;
		this.amount=amount;	
	}	

}