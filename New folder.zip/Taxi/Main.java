import java.util.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
class Main
{
	static DataBase db;
	public static LocalTime Timeconvert(String timeString)
{
    LocalTime time = null;
    try {
        time = LocalTime.parse(timeString, DateTimeFormatter.ofPattern("HH:mm"));
    } catch (Exception e) {
        time = LocalTime.parse(timeString, DateTimeFormatter.ofPattern("H:mm"));
    }
    return time;
}


	public static void BookTaxi(String startpoint,String endpoint,String time)
	{
		LocalTime pickupTime=Timeconvert(time);

		Taxi freeTaxi=null;
		int dis=0;
		for(Taxi t:db.taxi)
		{
			LocalTime TaxiTime=Timeconvert(t.getFreeTime());
			Duration duration = Duration.between(pickupTime, TaxiTime);
        		long differenceMinutes = duration.toMinutes();
			int distance=Math.abs((t.Currentend.charAt(0)-'A')-(startpoint.charAt(0)-'A'))*15;

			if(differenceMinutes>=distance && freeTaxi==null)
			{
				dis=distance;
				freeTaxi=t;	
			}
			else if(dis<=distance){
				dis=distance;
				freeTaxi=(freeTaxi.getTotalearnings()>t.getTotalearnings())?t:freeTaxi;
			}
		}

		if(freeTaxi==null)
		{
			System.out.println("----------No Taxi Available----------");
			return;
		}
		else
		{
			
			 LocalTime newTime = Timeconvert(freeTaxi.getFreeTime());
			LocalTime newT=newTime.plusMinutes(dis);
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
       		        String formattedTime = newT.format(formatter);
			freeTaxi.setFreeTime(formattedTime,startpoint,endpoint);
		
	Trip(int TaxiID,String Pickup,String Drop,String Starttime,String Endtime,int Distance,Double amount)
			double amt=Math.abs((t.Currentend.charAt(0)-'A')-(startpoint.charAt(0)-'A'))*15;
			Trip tr=new Trip(freeTaxi.getTaxiID(),time,formattedTime,amt*10-5);
		}
		
	}

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		Boolean loop=true;
		db=new DataBase();

		
		for(int i=0;i<5;i++)
		{
			Taxi t=new Taxi();
			db.taxi.add(t);
		}

		while(loop)
		{
			System.out.println("1.BookTaxi\n2.TaxiHistory\n3.Exit");
			int option=sc.nextInt();
			
			switch(option)
			{
				case 1:
				{
					System.out.println("Enter the pickup point: ");
					String startpoint=sc.next();

					System.out.println("Enter the Drop point: ");
					String  endpoint=sc.next();	
					
					System.out.println("Enter the time to pickup:");
					String time=sc.next();

					if(startpoint.charAt(0)<'A'||startpoint.charAt(0)>'E'||endpoint.charAt(0)<'A'||endpoint.charAt(0)>'E')
					{
						System.out.println("Enter the Vaild startpoint or endpoint");
						return;
					}
					else
					{
						BookTaxi(startpoint,endpoint,time);
						
					}
				
				}
				break;
		
				case 2:
				{

				}
				break;

				case 3:
				{
					loop=false;
				}
				break;
				
			}
		}		
	}
}