class Time 
{
        int hours, minutes, seconds;

        Time(String timeStr) {
            String[] parts = timeStr.split(":");
            hours = Integer.parseInt(parts[0]);
            minutes = Integer.parseInt(parts[1]);
            seconds = Integer.parseInt(parts[2]);
        }

        int toSeconds() {
            return hours * 3600 + minutes * 60 + seconds;
        }

        public boolean isBetween(Time start, Time end) {
            int thisSeconds = this.toSeconds();
            return thisSeconds >= start.toSeconds() && thisSeconds <= end.toSeconds();
        }
    }
