class Interval
{
Time start,end;

	Interval(Time start,Time end)
	{
		this.start=start;
		this.end=end;
	}

}