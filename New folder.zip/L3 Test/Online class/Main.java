import java.util.*;
class Main
{
	public static int countStudentsAtTime(List<Interval> intervals, Time time) {
        int count = 0;
        for (Interval interval : intervals) {
            if (time.isBetween(interval.start, interval.end)) 
	    {
                count++;
            }
        }
        return count;
    }

public static void main(String[] args)
{

	Scanner sc=new Scanner(System.in);

	System.out.println("Enter the N number Students:");
	int N=sc.nextInt();

	System.out.println("Enter the class Start Time:");
	Time st=new Time(sc.next());

	System.out.println("Enter the class End Time:");
	Time se=new Time(sc.next());

	Time classtime=new Time(st,se);

	ArrayList<Interval> inteval=new ArrayList<>();

	for(int i=0;i<N;i++)
	{

		System.out.println("Enter the StudentID:");
		int SID=sc.nextInt();

		System.out.println("Enter How many Times of Intervals:");
		int M=sc.nextInt();

		for(int j=0;j<M;j++)
		{
			System.out.println("Enter the Starting Intervals:");
			Time intervalStart = new Time(sc.next());
		
			System.out.println("Enter the Ending Intervals:");
			Time intervalEnd = new Time(sc.next());

			intervals.add(new Interval(intervalStart, intervalEnd));
		}
	}
		int minStudents = Integer.MAX_VALUE;
        	List<Time> minTimes = new ArrayList<>();
		
		for (int i = start.toSeconds(); i <= end.toSeconds(); i++) 
		{

            		Time currentTime = new Time(String.format("%02d:%02d:%02d", i / 3600, (i % 3600) / 60, i % 60));
            		int count = countStudentsAtTime(intervals, currentTime);
            		if (count < minStudents) 
			{
                		minStudents = count;	
                		minTimes.clear();
                		minTimes.add(currentTime);
            		}
			else if (count == minStudents) 
			{
               			 minTimes.add(currentTime);
            }
        }










}
}