import java.util.*;
class Account 
{
	String accountnumber;
	int id;
	private double balance;
	ArrayList<String> log=new ArrayList<>();
	ArrayList<User> users=new ArrayList<>();
	
	Account(String number,int id)
	{
		this.accountnumber=number;
		this.id=id;
		balance=100.00;
	}

	public synchronized void transaction(User u,boolean isDeposit,double amount){
		if(isDeposit){
			balance+=amount;
			String l=u.name +" deposited "+"$"+amount +" Balance:"+balance;
			log.add(l);
			System.out.println(l);
		}
		else{
			if(amount<=balance){
				balance-=amount;
				String l=u.name+" withdrawn "+amount+" Balance:"+balance;
				log.add(l);
				System.out.println(l);
				
			}
			else{
				System.out.println(u.name+" "+"Declined:Insufficient Balance");
			}
		}
			try{
				u.sleep(3000);
			}
			catch(Exception e){};
	}
}
