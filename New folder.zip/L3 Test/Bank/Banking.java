import java.util.*;
class Banking 
{
	static Map<String,Account> account=new HashMap<>();
	static int AccId=1;
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) 
	{
		
		boolean loop=true;
		
		while(loop)
		{
			System.out.println("1.create Account\n2.Add member to a account\n3.check log\n4.Exit\nEnter choice:");
			int ch=sc.nextInt();
			switch(ch)
			{
			case 1:
			{
				createAccount();
				
			}
			break;
			
			case 2:
			{
				ADDMembers();
			}
			break;
			case 3:
			{
				CheckLog();
			}
			break;
			case 4:
			{
				loop=false;
			}
			break;
			
			
			}
		}

	}

	public static void createAccount() 
	{
		System.out.println("-----Creating new Account----");
		String num=""+AccId;
		int password=1234;
		Account acc=new Account(num,password);
		AccId++;
		System.out.println("---------Account Created -----");
		System.out.println("Account Number:"+(AccId-1));
		account.put(num,acc);
	}

	public static void ADDMembers() 
	{
		System.out.println("----Add members to a joint account----");
		System.out.println("Enter the members to add count");
		int count=sc.nextInt();
		System.out.println("Enter the Accountnumber:");
		int id=sc.nextInt();
		
		for(int i=0;i<count;i++)
		{
			System.out.println("Enter the Nmae:");
			String name=sc.next();
			System.out.println("Enter true(depositer)/false(withdrawer):");
		boolean dep=sc.nextBoolean();
		System.out.println("Enter the amount:");
		double amount=sc.nextDouble();
			if(account.containsKey(id+""))
			{
				System.out.println("------------------");
				Account acc=account.get(id+"");
				User newUser=new User(name,acc,dep,amount);
				acc.users.add(newUser);
			}
		}
		
		
	}

	public static void CheckLog()
	{
		System.out.println("Enter the AccountId:");
		int id=sc.nextInt();
		
		Account acc=account.get(id+"");
		System.out.println("------------------"+acc.accountnumber);
		ArrayList<User> user=acc.users;	
			
		for(int i=0;i<user.size();i++)
		{
			System.out.println("------------------");
			user.get(i).start();
		}
		
	}

}








