class User extends Thread
{
		String name;
		Account ac;
		double amount;
		boolean dep;
		User(String name,Account ac,boolean dep,double amount)
		{	
			this.name=name;
			this.dep=dep;
			this.amount=amount;
			this.ac=ac;
		}
		
		
		public void run(){
			while(true)
			{
				ac.transaction(this,dep,amount);
				try
				{
					sleep(1000);
				}
				catch(Exception e)
				{
					System.out.println("Error:"+e);
				};
			}
				
		}
	}
