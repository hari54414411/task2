import java.util.*;
class Q1
{

 public static int countPositiveSubstrings(int n, String s) {
        int total = 0;
         for(int i = 0; i < n; i++)
	{
            int countones = 0;
            int countzeros = 0;
        
            for(int j = i; j < n; j++)
	    {
                
               
                if(s.charAt(j)=='1'){
                    ++countones;
                }
                else{
                    ++countzeros;
                }
               
                if(countones>countzeros)
		{
                    ++total;
                }
            }
        }
        
        return total;
}


	public static void main(String[] args)
	{

		Scanner sc=new Scanner(System.in);

		System.out.println("Enter the How many Test cases:");
		int t=sc.nextInt();
		
		int count=0;
		int count1=0;

		for(int i=0;i<t;i++)
		{
			System.out.println("Enter the String length:");
			int n=sc.nextInt();
		
			System.out.println("Enter the Binary Number:");
			String s=sc.next();

		System.out.println(countPositiveSubstrings(n,s));
		
		}

			
	
}
}