class LiftDetails
{

	Strint Lift;
	int floor;
	int capacity;

	public LiftDetails(String Liftname,int floor,int capacity)
	{
		this.Liftname=name;
		this.floor=floor;
		this.capacity=capacity
	}

	public void setfloor(int floor)
	{
		this.floor=floor;
	}
	public int getfloor()
	{
		return this.floor;
	}

	public String getLiftname()
	{
		return this.Liftname; 
	}

	public String toString()
	{

		return "LiftName: "+this.Liftname+"| Position: "+floor;
	}
	
}