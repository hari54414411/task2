import java.util.*;
class Lift
{
public static void main(String[] args)
{

	Scanner sc=new Scanner(System.in);
        boolean loop=true;
	LiftManagement l=new LiftManagement(5);

	while(loop)
	{
	System.out.println("1.Display lift details\n2.Assign Lift\n3.Assign Lift Under Maintenance\n4.Exit");
	int chioce=sc.nextInt();

	switch(chioce)
	{
		case 1:
		{
			l.details();
		}
		break;

		case 2:
		{
			System.out.println("Enter the CurrentFloor:");
			int currentfloor=sc.nextInt();
			System.out.println("Enter which foor do you want to go:");
			int destinationFloor=sc.nextInt();
			if(currentfloor>=0&&0<=destinationFloor)
			{
			        l.AssignLift(currentfloor,destinationFloor);
			}
			else
			{
				System.out.println("Enter the currentFloor or destinationFloor");
			}
		}
		break;

		case 3:
		{
			System.out.println("Enter the Lift name");
			String liftname=sc.next();
			l.AssignunderMaintenance(liftname);
		}
		break;

		case 4:
		{
			loop=false;
		}
		break;
		
		
	}
	}
}
}