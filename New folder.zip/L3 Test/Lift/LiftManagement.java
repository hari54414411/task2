import java.util.*;
class LiftManagement
{	

ArrayList<LiftDetails> liftd=new ArrayList<>(); 
	public LiftManagement(int numberofLift)
	{
		for(int i=0;i<numberofLift;i++)
		{
			LiftDetails LD=new LiftDetails('L'+""+i,0,6);
			liftd.add(LD);
			
		}		
	}
	
	public void details()
	{
		for(LiftDetails l:this.liftd)
		{
			System.out.println(l+"  ");
			if(l.getfloor()==-1)
			{
				System.out.println("Lift is under maintenance");
			}

		}
	}



	public void AssignLift(int currentfloor,int destinationFloor)
	{
		List<LiftDetails> near=NearLift(currentfloor);
		LiftDetails nearlift=null;
	
		if(near.size()>1)
		{
			nearlift=Direction(near,(currentfloor-destinationFloor)>=0,currentfloor);
			
		}
		else if(near.size()!=0)
		{
			nearlift=near.get(0);
		}
		else
		{
			System.out.println("No Lifts are Available");
			return;

		}
		
		nearlift.setfloor(destinationFloor);
		System.out.println(nearlift.getLiftname()+" Lift is Assigned");
	}



	public List<LiftDetails> NearLift(int currentfloor)
	{
		int min=Integer.MAX_VALUE;
		List<LiftDetails> near=new ArrayList<LiftDetails>();
		for(LiftDetails l:this.liftd)
		{
		int dis=Math.abs(currentfloor-l.getfloor());
			
			if(min==dis)
			{
				near.add(l);
			}
			else if(dis<min && l.getfloor()!=-1)
			{
				near.clear();
				near.add(l);
				min=dis;
			} 
		}
		return near;
	}



	public LiftDetails Direction(List<LiftDetails> near,boolean b,int currentfloor)
	{

		LiftDetails nearlift=null;
		if(!b){
			for(LiftDetails l:near)
			{
				if(l.getLiftname()=="L1" || l.getLiftname()=="L2" || (currentfloor-l.getfloor())>=0 )
				{
					nearlift=l;
				}		
			}
		}

		else 
		{
			for(LiftDetails l:near){
				if( l.getLiftname()=="L3" || l.getLiftname()=="L4" || (currentfloor-l.getfloor())<0  ){
					nearlift=l;
				}		
			}
		}
		if(nearlift==null)nearlift=near.get(0);
		return nearlift;

	}















	public void AssignunderMaintenance(String liftname)
	{

		for(LiftDetails l:this.liftd)
		{
			if(l.getLiftname().equals(liftname))
			{
				l.setfloor(-1);
				System.out.println("Lift "+liftname+"  under Maintenance");
				break;
			}

		}
		
	
	}

}