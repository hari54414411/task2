import java.util.*;
class Admin {
    Scanner s = new Scanner(System.in);
    ProductDetail p = new ProductDetail();

    public void admin() {
        System.out.println("Enter the login id");
        int adminlogin = s.nextInt();

        System.out.println("Enter the Password");
        int password = s.nextInt();

        if (adminlogin == 12345 && password == 12345) {
            System.out.println("1.ADD Product\n2.Product Quantities\n3.Order History");
            int option = s.nextInt();

            switch (option) {
                case 1: {
                    p.add();
                    break;
                }
                case 2: {
                    p.showProductQuantities();
                    break;
                }
                case 3: {
                    p.Orderhistory();
                    break;
                }
            }
        } else {
            System.out.println("Sorry password or id not correct");
        }
    }
}
