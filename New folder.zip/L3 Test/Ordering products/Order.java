import java.util.*;

class Order {
    int orderID;
    User user;
    Product product;
    int quantity;
    double amount;
    String status;

    Order(int orderID, User user, Product product, int quantity, double amount, String status) {
        this.orderID = orderID;
        this.user = user;
        this.product = product;
        this.quantity = quantity;
        this.amount = amount;
        this.status = status;
    }

    @Override
    public String toString() {
        return "Order ID: " + orderID +
                ", User: " + user.name +
                ", Product: " + product.productname +
                ", Quantity: " + quantity +
                ", Amount: $" + amount +
                ", Status: " + status;
    }
}