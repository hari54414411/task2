class Product {
    String productname;
    int productID;
    int productcount;
    double price;

    Product(String productname, int productID, int productcount, double price) {
        this.productname = productname;
        this.productID = productID;
        this.productcount = productcount;
        this.price = price;
    }

    public String toString() {
        return productID + "   " + productname + "    " + productcount + "    " + price;
    }
}
