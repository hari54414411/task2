import java.util.*;
public class UserFunctions 
{
    User ud;
    Scanner scan = new Scanner(System.in);

    public UserFunctions(User ud) {
        this.ud = ud;
    }

    public void searchProduct() {
        System.out.println("Enter the product Id:");
        int id = scan.nextInt();

        if (DataBase.map1.containsKey(id)) {
            System.out.println(DataBase.map1.get(id));
        } else {
            System.out.println("No Product Available");
        }
    }


public void ConfirmOrder() {
    // Check if the user has any orders
    if (ud.orders.isEmpty()) {
        System.out.println("No orders to confirm.");
        return;
    }

    // Display the user's current orders
    System.out.println("Your current orders:");
    for (Order order : ud.orders) {
        System.out.println(order);
    }

    // Prompt the user to confirm the orders
    System.out.print("Do you want to confirm these orders? (yes/no): ");
    String choice = scan.next();
    if (choice.equalsIgnoreCase("yes")) {
        // Set the order status to "Confirmed"
        for (Order order : ud.orders) {
            order.status = "Confirmed";
        }
        System.out.println("Orders confirmed successfully.");
    } else {
        System.out.println("Order confirmation cancelled.");
    }
}

    public void wishList() {
        System.out.println("Enter the product ID or name to add to your wishlist:");
        String productIdOrName = scan.next();

        // Check if the product exists
        boolean found = false;
        for (Product product : DataBase.map1.values()) {
            if (Integer.toString(product.productID).equals(productIdOrName) || product.productname.equals(productIdOrName)) {
                ud.wishlist.add(product);
                found = true;
                break;
            }
        }

        if (found) {
            System.out.println("Product added to your wishlist successfully.");
        } else {
            System.out.println("Product not found. Please enter a valid product ID or name.");
        }
    }
	
public static void listofProduct() {
        System.out.println("List of Products:");
        for (Map.Entry<Integer, Product> entry : DataBase.map1.entrySet()) {
            Product product = entry.getValue();
            System.out.println(product);
        }
    }
    public void MyOrder() {
        if (ud.orders.isEmpty()) {
            System.out.println("No orders found in your order history.");
        } else {
            System.out.println("---- Order History ----");
            for (Order order : ud.orders) {
                System.out.println(order);
            }
        }
    }

    public void cancelOrder() {
        if (ud.orders.isEmpty()) {
            System.out.println("No orders found to cancel.");
        } else {
            System.out.println("Enter the Order ID to cancel:");
            int orderId = scan.nextInt();
            boolean found = false;
            for (Order order : ud.orders) {
                if (order.orderID == orderId) {
                    order.status = "Cancelled";
                    order.product.productcount += order.quantity; // Increase product count
                    found = true;
                    System.out.println("Order cancelled successfully.");
                    break;
                }
            }
            if (!found) {
                System.out.println("Order not found with the given ID.");
            }
        }
    }

    public void payment() {
        if (ud.orders.isEmpty()) {
            System.out.println("No orders found to make a payment.");
            return;
        }

        // Calculate total amount to pay
        double totalAmount = 0.0;
        for (Order order : ud.orders) {
            totalAmount += order.amount;
        }

        System.out.println("Total amount to pay: $" + totalAmount);

        // Here you can implement payment process, such as integrating with payment gateway
        // For simplicity, let's assume payment is confirmed if user confirms payment
        System.out.print("Confirm payment? (Y/N): ");
        String confirm = scan.next();
        if (confirm.equalsIgnoreCase("Y")) {
            // Payment confirmed, update order statuses and perform any other necessary actions
            for (Order order : ud.orders) {
                order.status = "Paid";
            }
            System.out.println("Payment successful.");
        } else {
            System.out.println("Payment cancelled.");
        }
    }
}
