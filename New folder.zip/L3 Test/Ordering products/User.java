import java.util.*;
class User {
     String name;
    private long MobileNumber;
    private String Address;
    private String EmailId;
    private String Password;
    ArrayList<Order> orders;
    ArrayList<Product> wishlist;

    User(String name, long MobileNumber, String Address, String EmailId, String Password) {
        this.name = name;
        this.MobileNumber = MobileNumber;
        this.Address = Address;
        this.EmailId = EmailId;
        this.Password = Password;
        orders = new ArrayList<>();
        wishlist = new ArrayList<>();
    }

 
	public void setAddress(String address)
	{
	this.Address=address;
	}
	
	public String getAddress()
	{
	return Address;	
	}

	public void setEmail(String email)
	{
	this.EmailId=email;
	}
	
	public String getEmails()
	{
	return EmailId;	
	}

	public void setPassword(String password)
	{
	this.Password=password;
	}
	
	public String getPassword()
	{
	return Password;	
	}

}