import java.util.*;

class Main {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        boolean loop = true;

        while (loop) {
            System.out.println("1.New LogIn\n2.Log In\n3.Admin LogIn\n4.Exit");
            int option = s.nextInt();

            switch (option) {
                case 1: {
                    System.out.println("-----Welcome New User-----");
                    UserLogin u = new UserLogin();
                    u.Newlogin();
                    break;
                }
                case 2: {
                    System.out.println("-----Welcome User-----");
                    UserLogin u = new UserLogin();
                    u.Login();
                    break;
                }
                case 3: {
                    System.out.println("*****Welcome Admin*****");
                    Admin a = new Admin();
                    a.admin();
                    break;
                }
                case 4: {
                    loop = false;
                    break;
                }
            }
        }
    }
}
