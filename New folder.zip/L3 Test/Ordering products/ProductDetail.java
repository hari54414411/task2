import java.util.*;
class ProductDetail {
    static int id = 1;
    Scanner s1 = new Scanner(System.in);

    public void add() {
        System.out.println("How Many Product need to add");
        int productcount = s1.nextInt();
        for (int i = 0; i < productcount; i++) {
            System.out.println("Enter the Product Name to add:");
            String productname = s1.next();

            System.out.println("Enter the count of product:");
            int count = s1.nextInt();

            System.out.println("Enter the Price of product:");
            double price = s1.nextDouble();

            Product p = new Product(productname, id, count, price);
            DataBase.map1.put(id, p);
            id++;
        }
        System.out.println("------product Successfully added------");
    }

    public void showProductQuantities() {
        System.out.println("ProductID  ProductName  ProductPrice  ProductCount");

        for (int i = 1; i < DataBase.map1.size(); i++) {
            Product p1 = DataBase.map1.get(i);
            System.out.println(p1);
        }
    }

    public void Orderhistory() {
        // implement order history functionality
    }
}
