import java.util.*;
class UserLogin {
    Scanner s = new Scanner(System.in);

    public void Newlogin() {
        System.out.println("Enter Your name:");
        String Name = s.next();

        System.out.println("Enter Your MobileNumber:");
        long MobileNumber = s.nextLong();

        System.out.println("Enter Your Address:");
        String Address = s.next();

        System.out.println("Enter the Email Id:");
        String EmailId = s.next();

        System.out.println("Enter Your Password:");
        String Password = s.next();

        User us = new User(Name, MobileNumber, Address, EmailId, Password);
        DataBase.map.put(EmailId, us);
    }

    public void Login() {
        System.out.println("Enter the Email Id:");
        String EmailId = s.next();

        System.out.println("Enter Your Password:");
        String Password = s.next();

        if (DataBase.map.containsKey(EmailId) && DataBase.map.get(EmailId).getPassword().equals(Password)) {
            User ud = DataBase.map.get(EmailId);
boolean loop=true;
	
	while(loop)
	{
            System.out.println("1.Search Product\n2.WishList\n3.ListofProduct\n4.ConfirmOrder\n5.MyOrder\n6.CancelOrder\n7.Payment\n8.Exit");
            int option = s.nextInt();
            UserFunctions user = new UserFunctions(ud);
	
            switch (option) {
                case 1: {
                    user.searchProduct();
                    break;
                }
                case 2: {
                    user.wishList();
                    break;
                }

                case 3: {
                    user.listofProduct(); 
                    break;
                }
		case 4:
		{
		user.ConfirmOrder();
                    break;	
		}

                case 5: {
                    user.MyOrder();
                    break;
                }
                case 6: {
                    user.cancelOrder();
                    break;
                }
                case 7: {
                    user.payment();
                    break;
                }
		case 8:	
		{
		loop=false;
		}
            }
        } 

    }
}
}