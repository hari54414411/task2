import java.util.*;
class DataBase {
    static Map<String, User> map = new HashMap<>();
    static Map<Integer, Product> map1 = new HashMap<>();
}