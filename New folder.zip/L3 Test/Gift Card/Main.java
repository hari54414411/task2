import java.util.*;
class Main
{
	public static String EncryptedPassword(String s)
	{
		char c[]=s.toCharArray();

        	for(int i=0;i<c.length;i++)
        	{
           		 switch(c[i])
            		 {
                		case 'A':
                		{
                    			c[i]='Z';
                		}
                		break;

                		case 'a':
                		{
                    			c[i]='z';
                		}
                		break;

                		case '1':
                		{
                   			 c[i]='0';
                		}
                		break;

                		default:
                		{
                   			 c[i]--;
                		}
                		break;

            }
        }
		return new String(c);
	}

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
			
		String ps=EncryptedPassword("ApipNbjm");
		User u=new User(11,11011,"Kumar",10000,ps);
		DataBase.userdetails.put(11,u);

		ps=EncryptedPassword("Cboljoh");
		User u1=new User(22,22022,"Madhu",20000,ps);
		DataBase.userdetails.put(22,u1);

		ps=EncryptedPassword("kbwb22");
		User u3=new User(33,33033,"Robin",30000,ps);
		DataBase.userdetails.put(33,u3);

		

		boolean loop=true;

		while(loop)
		{
			System.out.println("1. Account Login\n2.  Purchase\n3. Exit");
			int option=sc.nextInt();

			switch(option)
			{
				case 1:
				{
					System.out.println("Enter the cusid:");
					int cusid=sc.nextInt();

					System.out.println("Enter the Password:");
					String passw=EncryptedPassword(sc.next());

					if(DataBase.userdetails.containsKey(cusid) &&DataBase.userdetails.get(cusid).password.equals(passw))
					{

						Account ac=new Account();
						ac.AccountLogIn(cusid);		
					}
					else
					{
						System.out.println("Sorry Enter the correct cusid or password");
					}		
				}
				break;
				
				case 2:
				{
					
				}
				break;

				case 3:
				{
					loop=false;
				}
				break;
				
				
				
			}
		}
		
		
			
	}
}