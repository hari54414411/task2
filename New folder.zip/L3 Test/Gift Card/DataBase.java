import java.util.*;
class DataBase
{
	static Map<Integer,User> userdetails=new HashMap<>();
	static Map<Integer,GiftCard> usergiftcard=new HashMap<>();
	
}