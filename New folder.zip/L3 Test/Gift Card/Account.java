import java.util.*;
class Account
{
	 Scanner sc=new Scanner(System.in);
	 int cardnum=12345;

	public void AccountLogIn(int cusid)
	{

		
		
		boolean loop=true;
		

		while(loop)
		{

			System.out.println("1.Create new Gift Card\n2.Top up existing Gift Card\n3.Show Gift Card Transactions\n4.Block a existing Gift Card\n5.Logout");
			int option=sc.nextInt();
			switch(option)
			{

				case 1:
				{
					System.out.println("Your Giftcard Number:"+cardnum);
					System.out.println("Enter the Pin:");
					int pin=sc.nextInt();
					
					GiftCard gc=new GiftCard(cardnum,pin);
					DataBase.usergiftcard.put(cardnum,gc);
					cardnum++;

					System.out.println("Card Successfully Created");

					
				}

				break;

				case 2:
				{
					System.out.println("Enter the Card number");
					int cd=sc.nextInt();
			
					System.out.println("Enter the pin");
					int pin=sc.nextInt();

					if(DataBase.usergiftcard.containsKey(cd) && DataBase.usergiftcard.get(cd).pin==pin)
					{
						System.out.println("Enter the Amount add in gift card:");
						double amo=sc.nextInt();

						User u=DataBase.userdetails.get(cusid);
						u.setBalance(-amo);
						
						
						DataBase.usergiftcard.get(cd).setAmount(amo);
						System.out.println("Successfully amount deposited");
						GiftCard.history.add(amo+" is add to your GiftCard Account");
						
						
						
					}
					else
					{
						System.out.println("Sorry enter the correct cardnum and pin");
					}
					
				

				}
				break;
				case 3:
				{

				}
				break;

				case 4:
				{

				}
				break;
				

				case 5:
				{
					loop=false;	
				}
			}
		}

			
	}

}