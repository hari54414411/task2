import java.util.*;
class GiftCard
{
	int cardnum;
	int pin;
	double amount;
	ArrayList<String> history;
	GiftCard(int cardnm,int pinn)
	{	
		cardnum=cardnm;
		pin=pinn;
		amount=0;
		history=new ArrayList<>();

	}

	public void setAmount(double amount)
	{
		this.amount+=amount;
	}

	public double getAmount()
	{
		return amount;
	}
	
}