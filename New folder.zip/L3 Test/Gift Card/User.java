import java.util.*;
class User
{
	private int cusid;
	private int accno;
	private String name;
	private double balance;
	public String password;
	ArrayList<GiftCard> GC;

	User(int cusid,int accno,String name,double balance,String password)
	{	
		this.cusid=cusid;
		this.accno=accno;
		this.name=name;
		this.balance=balance;
		this.password=password;
		GC=new ArrayList<>();
	}

	public void setPassword(String password)
	{
		this.password=password;
	}

	public int getAccno()
	{
		return accno;
	}

	public double getBalance()
	{
		return balance;
	}

	public void setBalance(double amount)
	{
		balance+=amount;
	}

	

	public String toString()
	{
		return "Name: "+name+"CusId:"+cusid+"\nAcc No: "+accno+"\nBalance: "+balance+" ";
	}

}