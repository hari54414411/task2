import java.util.*;
class TicTac
{
	public static void print(String[][] Grid)
	{
		for(int i=0;i<Grid.length;i++)
		{
			for(int j=0;j<Grid.length;j++)
			{
				System.out.print(Grid[i][j]+"  ");
				
			}
			System.out.println();
			
		}
	}


	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);

		String Grid[][]=new String[3][3];

		int num=1;
		for(int i=0;i<Grid.length;i++)
		{	
			for(int j=0;j<Grid.length;j++)
			{
				Grid[i][j]=num+++" ";				
			}
		}
		int n=3;

		int grid=n*n;
		String point="X ";
		print(Grid);
	
		while(grid>0)
		{
			System.out.println("Enter the Number in Grid to place Your cell:");
			int number=sc.nextInt();
			

			int i=(number-1)/n;
			int j=(number-1)%n;

			Grid[i][j]=point;
			boolean loop=false;

			if(Grid[0][j]==Grid[1][j] && Grid[1][j]==Grid[2][j]){
				loop=true;
			}
			else if(Grid[i][0]==Grid[i][1] &&Grid[i][1]==Grid[i][2]){
				loop=true;
			}
			else if(Grid[0][0]==Grid[1][1] && Grid[1][1]==Grid[2][2]){
				loop=true;
			}
			else if(Grid[0][2]==Grid[1][1] && Grid[1][1]==Grid[2][0]){
				loop=true;
			}
			
			print(Grid);
			if(loop)
			{
				System.out.println("Congratulations! "+point+"'s have won! Thanks for playing");
				break;
			}
			grid--;
			point = point=="X "?"O ":"X ";
			
		}

		if(grid==0)
		{
			System.out.println("-----Game draw-------");
		}


		
	}

}



		
