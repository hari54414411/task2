import java.util.*;
class Balloon
{
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter the matrix size(m*n)");

System.out.println("Enter the size of row:");
int m=sc.nextInt();
System.out.println("Enter the size of columns:");
int n=sc.nextInt();
boolean loop=true;

	String matrix[][]=new String[m][n];

	for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{
			matrix[i][j]="- ";
		}
		System.out.println();
	}

	while(loop)
	{

	System.out.println("Enter the column number to fill balloon:");
	int columnnumber=sc.nextInt();

	System.out.println("Enter the color of the ballon:");
	String Ballooncolor=sc.next();
	
	for(int k= matrix.length-1;k>=0;k--)
	{	
		if(matrix[k][columnnumber-1]=="- ")
		{
			matrix[k][columnnumber-1]=Ballooncolor;
			break;
		}
		else if(matrix[0][columnnumber-1]!="- ")
		{
			System.out.println("Column is filled Completely");
			break;
		}
		
	}

        for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{
			System.out.print(matrix[i][j]);
		}
		System.out.println();
	}

	System.out.println("Do you wish to continue(Y/N)");
	
	String con=sc.next();
	if(con.equals("Y"))
	{
		continue;
	}
	else
	{
		System.out.println("Program Stopped");
		break;
	}
	
}
}
}