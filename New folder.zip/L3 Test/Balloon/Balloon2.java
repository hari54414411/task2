import java.util.*;
class Balloon2
{
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter the matrix size(m*n)");

System.out.println("Enter the size of row:");
int m=sc.nextInt();
System.out.println("Enter the size of columns:");
int n=sc.nextInt();
boolean loop=true;

	String matrix[][]=new String[m][n];

	for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{
			matrix[i][j]="- ";
		}
		System.out.println();
	}

	while(loop)
	{

	System.out.println("Enter the column number to fill balloon:");
	int columnnumber=sc.nextInt();

	System.out.println("Enter the color of the ballon:");
	String Ballooncolor=sc.next();
	
	for(int k=matrix.length-1;k>=0;k--)
	{	

		
		if(matrix[k][columnnumber-1]=="- ")
		{
			matrix[k][columnnumber-1]=Ballooncolor;
			break;
		}
		else if(matrix[k][columnnumber-2]=="- ")
		{
			matrix[k][columnnumber-2]=Ballooncolor;
			break;
		}	
		if(matrix[k][columnnumber]=="- ")	
		{
			matrix[k][columnnumber]=Ballooncolor;
			break;
		}

	}	
	

	Rowchecking(matrix);
	colchecking(matrix);

        for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{
			System.out.print(matrix[i][j]);
		}
		System.out.println();
	}

	System.out.println("Do you wish to continue(Y/N)");
	
	String con=sc.next();
	if(con.equals("Y"))
	{
		continue;
	}
	else
	{
		System.out.println("Program Stopped");
		break;
	}
	
}
}

public static void Rowchecking(String matrix[][])
{
	for(int i=0;i<matrix.length;i++)
	{
		if(matrix[0][i].equals(matrix[1][i])&&matrix[1][i].equals(matrix[2][i]))
		{
			matrix[0][i]="- ";
			matrix[1][i]="- ";
			matrix[2][i]="- ";	
		}
	}

}




public static void colchecking(String matrix[][])
{
	
		for(int j=0;j<matrix[0].length;j++)
		{
			if(matrix[j][0].equals(matrix[j][1])&&matrix[j][1].equals(matrix[j][2]))
			{
			matrix[j][0]="- ";
			matrix[j][1]="- ";
			matrix[j][2]="- ";	
			}

		
		}
	

}

}