import java.util.*;
import java.util.*;
public class Q1
{
public static String method(String s,boolean ind)
{
	StringBuilder sb=new StringBuilder();
		int i=0;
		while(i<s.length()){
			
			if(ind)
			{
				String  temp="";
				int j=i;
				while(j<s.length())
				{
				char a=s.charAt(j++);		
					
					if(a==' ') 
					{
						ind=false;
						break;
					}
						temp=a+temp;
				        }
		
				i=j;
				sb.append(temp+" ");
				
			}
			else{
				int j=i;
				while(j<s.length()){
					char a=s.charAt(j);
					if(a==' ')
					{
					ind=true;
					 break;
					}
					sb.append(a+"");
					j++;
				}
				sb.append(" ");
				i=j+1;
				
			}
			
			
		}
		return sb.toString();
}
public static void main(String arg[])
{
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter string:");
		String s=sc.nextLine();

		System.out.println("Enter odd  or even:");
		String index=sc.next();
		boolean i=index.equals("odd")?true:false;

		System.out.println(method(s,i));


}
}