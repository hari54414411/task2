import java.util.*;
class Q2
{
public static String method(String s)
{
int index[]=new int[200];
StringBuilder sb=new StringBuilder();
int count=1;
for(char c:s.toCharArray())
{
	index[c]++;
}

for(char c:s.toCharArray())
{
	while(index[c]>0)
	{
	     	if(index[c]==1)
		{

			sb.append((char)c).append(count);
			count=0;		
		}
		index[c]--;
	        count++;
   
	}
		
	

}
return sb.toString();
}

public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
String s=sc.next();
System.out.println(method(s));

}
}
