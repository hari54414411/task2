import java.util.*;

public class SnakeLadder{
	static Scanner sc=new Scanner(System.in);
	static HashMap<String,Integer> snakes=new HashMap<>();
	static HashMap<String,Integer> ladder=new HashMap<>();
	static List<String> tailEnd=new ArrayList<>();
	static String startVal="1";
	public static void createBoard(String[][] board,int n,int len){
			for(int i=0;i<len;i++){		
			n=i%2!=0?n-10:n;
			for(int j=0;j<len;j++){
				board[i][j]=n+"";
				if(i%2==0)n--;
				else n++;
			}
			if(i%2==0)n++;
			else n--;
			if(i%2!=0)n-=10;
		}
	}
	
	public static void main(String[]args){
		int len=10;
		int n=len*len;
		String[][] board=new String[10][10];

		createBoard(board,n,len);
		System.out.println();
		
		printBoard(board);		
		int loc=1;
		boolean flag=true;
		int[]ind={9,0};
		do{	System.out.println();
			System.out.println("----------------------------------------");
			System.out.println("1.Start game");
			System.out.println("2.Set snakes");
			System.out.println("3.Set Ladder");
			System.out.println("4.Exit");
			System.out.println("Enter what you want to do");int choice=sc.nextInt();
			switch(choice){
				case 1:	boolean Aflag=true;
					do{
						loc=movePlayer(board,ind,loc);
						printBoard(board);
						if(board[0][0].equals("A")){
							flag=false;
							Aflag=false;
							System.out.println("\tYou won the game");
						}else{
							System.out.println("Throw another dice?");
							System.out.println("Y / N");
							char c=sc.next().charAt(0);
							if(c=='N' || c=='n')Aflag=false;
						}
					}while(Aflag);
				break;
				case 2:boolean Bflag=true;
					int s=1;
					do{
						System.out.println("Enter snake head position: ");int head=sc.nextInt();
						System.out.println("Enter snake tail position: ");int tail=sc.nextInt();

						snakes.put("sH"+s,tail);
						tailEnd.add("sT"+s);

						placeSnakeAndLadder(board,head,tail,s++,"sH","sT");
						
						printBoard(board);

							System.out.println("Throw another dice?");
							System.out.println("Y / N");
							char c=sc.next().charAt(0);
							if(c=='N' || c=='n')Bflag=false;
						
					}while(Bflag);
					
				break;
				case 3:boolean Cflag=true;
					int l=1;
					do{
						System.out.println("Enter ladder start position: ");int head=sc.nextInt();
						System.out.println("Enter snake end position: ");int tail=sc.nextInt();

						ladder.put("lS"+l,tail);
						tailEnd.add("lE"+l);

						placeSnakeAndLadder(board,head,tail,l++,"lS","lE");
						
						printBoard(board);

							System.out.println("Throw another dice?");
							System.out.println("Y / N");
							char c=sc.next().charAt(0);
							if(c=='N' || c=='n')Cflag=false;
						
					}while(Cflag);

				break;
				case 4:flag=false;System.out.println("Exited successfully");
				break;
				default:System.out.println("Please pick correct Option!");
			}
			if(flag)printBoard(board);
		}while(flag);
		
		
	}
	public static int movePlayer(String[][]board,int[] ind,int loc){
		System.out.println("Enter dice value:");
		int dice=sc.nextInt();
		dice+=loc;
		int val=(dice-1)/10;
		int i=9-val;
		int j=((dice-1)%10);
		String end="";
		boolean flag=true;
		if(snakes.containsKey(board[i][j]) || ladder.containsKey(board[i][j])){flag=false;
			if(snakes.containsKey(board[i][j]))
				dice=snakes.get(board[i][j]);
			else dice=ladder.get(board[i][j]);
			playerMark(board,dice,ind,board[i][j]);
		}else if(board[i][j].equals(dice+"") || tailEnd.contains(board[i][j])){
			end=board[i][j];
			 board[i][j]="A";
		}
		else{
			j=9-j;
			if(snakes.containsKey(board[i][j]) || ladder.containsKey(board[i][j])){
				flag=false;
				if(snakes.containsKey(board[i][j]))
					dice=snakes.get(board[i][j]);
				else dice=ladder.get(board[i][j]);
				playerMark(board,dice,ind,board[i][j]);
			}else if(board[i][j].equals(dice+"") || tailEnd.contains(board[i][j])){
				end=board[i][j];
			 	board[i][j]="A";
			}
		}
		
		loc=dice;
		if(flag){
			board[ind[0]][ind[1]]=startVal;
			startVal=end;	
			ind[0]=i;
			ind[1]=j;
		}
		return loc;
		
	}
	public static void playerMark(String[][]board,int dice,int[] ind,String s){
		int val=(dice-1)/10;
		int i=9-val;
		int j=((dice-1)%10);
		String end="";
		if(board[i][j].equals(dice+"") || tailEnd.contains(board[i][j]) ){
			end=board[i][j];
			 board[i][j]="A";
		}
		else{
			j=9-j;
			end=board[i][j];
			 board[i][j]="A";
		}
		board[ind[0]][ind[1]]=startVal;
		startVal=end;
		ind[0]=i;
		ind[1]=j;


	}

	public static void placeSnakeAndLadder(String[][]board,int start,int tail,int sn,String s,String t){
		int val=(start-1)/10;
		int i=9-val;
		int j=(start-1)%10;
		if(board[i][j].equals(start+"")){
			board[i][j]=s+""+sn;
		}else{
			j=9-j;
			board[i][j]=s+""+sn;
		}
		 val=(tail-1)/10;
		 i=9-val;
		 j=(tail-1)%10;
		if(board[i][j].equals(tail+"")){
			board[i][j]=t+""+sn;
		}else{
			j=9-j;
			board[i][j]=t+""+sn;
		}

	}
	
	public static void printBoard(String[][]board){
		for(String[] a:board){
			System.out.println(Arrays.toString(a));
			System.out.println();
		}
	}
}