import java.util.*;
class ZigZig
{
	public static void Print(String matrix[][])
	{
		for(int i=0;i<matrix.length;i++)
		{
			for(int j=0;j<matrix.length;j++)
			{
				System.out.print(matrix[i][j]+" ");
			}
		System.out.println();
		}

	}


	public static void Game(String matrix1[][])
	{

	

		matrix1[9][2]="S1 ";
		matrix1[6][0]="S1 ";
	
		matrix1[8][2]="S2 ";
		matrix1[5][2]="S2 ";
		
		matrix1[9][4]="S3 ";
		matrix1[7][6]="S3 ";
	
		matrix1[4][6]="S4 ";
		matrix1[6][9]="S4 ";
		
		matrix1[1][8]="S5 ";
		matrix1[4][7]="S5 ";
		
		matrix1[5][4]="S6 ";
		matrix1[3][5]="S6 ";

		matrix1[4][2]="S7 ";
		matrix1[2][4]="S7 ";
		
		matrix1[0][1]="S8 ";
		matrix1[5][0]="S8 ";

		matrix1[9][3]="L1 ";
		matrix1[7][4]="L1 ";
	
		matrix1[5][5]="L2 ";
		matrix1[8][7]="L2 ";
		
		matrix1[5][8]="L3 ";
		matrix1[6][7]="L3 ";
	
		matrix1[5][9]="L4 ";
		matrix1[3][8]="L4 ";
		
		matrix1[3][2]="L5 ";
		matrix1[5][1]="L5 ";
		
		matrix1[1][0]="L6 ";
		matrix1[3][1]="L6 ";

		matrix1[0][8]="L7 ";
		matrix1[2][6]="L7 ";

		for(int i=0;i<matrix1.length;i++)
		{
			for(int j=0;j<matrix1.length;j++)
			{
				System.out.print(matrix1[i][j]+" ");
			}
		System.out.println();
		}


		
		
	}
	
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the matrix size:");
		int n=sc.nextInt();
			
		int num=100;

		String matrix[][]=new String[n][n];

		for(int i=0;i<matrix.length;i++)
		{
			if(i%2==0)
			{
				for(int j=0;j<matrix.length;j++)
				{
					matrix[i][j]=num+" ";
					num--;
				}
			}
			else
			{
				for(int k=matrix.length-1;k>=0;k--)
				{
					matrix[i][k]=num+" ";
					num--;
				}

			}
		System.out.println();
		}
	
		Print(matrix);	

		String p="A";
		String prv="";
		
		prv=matrix[matrix.length-1][0];
		matrix[matrix.length-1][0]=p;
		Print(matrix);
		matrix[matrix.length-1][0]=prv;

		System.out.println("Enter the Outcome of Dice Thrown:");
		int Dice=sc.nextInt();

			prv=matrix[matrix.length-1][Dice];
			matrix[matrix.length-1][Dice]=p;

		Print(matrix);
		
		matrix[matrix.length-1][Dice]=prv;
		

		Map<String,String> Snake=new HashMap<>();
		Map<String,String> Ladder=new HashMap<>();

		System.out.println("Filling the Snake:");

		Snake.put("40","3");
		Snake.put("43","18");
		Snake.put("27","5");
		Snake.put("54","31");
		Snake.put("89","53");
		Snake.put("66","45");
		Snake.put("76","58");
		Snake.put("99","41");	

		System.out.println("Filling the Ladder");
		
		Ladder.put("4","25");
		Ladder.put("13","46");
		Ladder.put("33","49");
		Ladder.put("50","69");
		Ladder.put("42","63");
		Ladder.put("62","81");
		Ladder.put("74","92");

		
		Game(matrix);

		System.out.println("-------------------Game Start--------------------");
		
		matrix[9][0]="A";
		Game(matrix);
		while(true)
		{
			System.out.println("Enter the Number:");
			break;	

		}
		

		
		
		
	}
}