import java.util.*;

class SnakeAndLadder {
    // Function to print the game board
    public static void printBoard(String[][] board) {
        for (String[] row : board) {
            for (String cell : row) {
                System.out.print(cell + "\t");
            }
            System.out.println();
        }
    }

    // Function to play the game
    public static void playGame(String[][] board) {
        // Initialize the player position
        int playerPosition = 0;

        // Create a map for snakes and ladders
        Map<Integer, Integer> snakes = new HashMap<>();
        snakes.put(40, 3);
        snakes.put(43, 18);
        snakes.put(27, 5);
        snakes.put(54, 31);
        snakes.put(89, 53);
        snakes.put(66, 45);
        snakes.put(76, 58);
        snakes.put(99, 41);

        Map<Integer, Integer> ladders = new HashMap<>();
        ladders.put(4, 25);
        ladders.put(13, 46);
        ladders.put(33, 49);
        ladders.put(50, 69);
        ladders.put(42, 63);
        ladders.put(62, 81);
        ladders.put(74, 92);

        // Start the game loop
        while (playerPosition < board.length * board[0].length) {
            // Simulate a dice roll (assuming a 6-sided dice)
            int diceRoll = new Random().nextInt(6) + 1;

            // Update player position
            playerPosition += diceRoll;

            // Check if the new position is a ladder or a snake
            if (snakes.containsKey(playerPosition)) {
                System.out.println("Oops! You encountered a snake!");
                playerPosition = snakes.get(playerPosition);
            } else if (ladders.containsKey(playerPosition)) {
                System.out.println("Hooray! You climbed a ladder!");
                playerPosition = ladders.get(playerPosition);
            }

            // Update the board with the player's new position
            int row = board.length - 1 - playerPosition / board.length;
            int col = (playerPosition % board[0].length == 0) ? board[0].length - 1 : playerPosition % board[0].length - 1;
            board[row][col] = "P";

            // Print the updated board
            printBoard(board);

            // Check if the player has won
            if (playerPosition == board.length * board[0].length) {
                System.out.println("Congratulations! You won!");
                break;
            }

            // Wait for user input before the next turn
            Scanner scanner = new Scanner(System.in);
            System.out.println("Press Enter to roll the dice...");
            scanner.nextLine();
        }
    }

    // Main method
    public static void main(String[] args) {
        // Initialize the board size
        int size = 10;

        // Create the game board
        String[][] board = new String[size][size];
        int cellValue = size * size;

        // Fill the board with cell values
        for (int i = 0; i < size; i++) {
            if (i % 2 == 0) {
                for (int j = 0; j < size; j++) {
                    board[i][j] = String.valueOf(cellValue--);
                }
            } else {
                for (int j = size - 1; j >= 0; j--) {
                    board[i][j] = String.valueOf(cellValue--);
                }
            }
        }

        // Start the game
        System.out.println("Welcome to Snake and Ladder Game!");
        printBoard(board);
        playGame(board);
    }
}
