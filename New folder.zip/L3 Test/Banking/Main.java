import java.util.*;
class Main
{
public static void main(String[] args)
{
	Scanner sc=new Scanner(System.in);

	boolean loop=true;

	
	Transactions transactions=new Transactions();

	DataBase.AccountDetails.put("Arnab",100d);
	DataBase.AccountDetails.put("Monodwip",80d);
	DataBase.AccountDetails.put("Mukta",40d);
	DataBase.AccountDetails.put("Rinkel",75d);
	DataBase.AccountDetails.put("Shubham",75d);
	
	

	while(loop)
	{

		System.out.println("1.CheckBalance\n2.WithDrawal\n3.Deposit\n4.Exit");
		int choice=sc.nextInt();


		switch(choice)
		{


			case 1:
			{
				System.out.println("Enter the name:");
				String name=sc.next();
				transactions.CheckBalance(name);
						
			}
			break;


			case 2:
			{
				System.out.println("Enter the name:");
				String name=sc.next();
				System.out.println("Enter the Amount to Withdrawal:");
				double amount=sc.nextInt();
				transactions.Withdrawal(name,amount);
			}
			break;
			

			case 3:
			{
				System.out.println("Enter the name:");
				String name=sc.next();
				System.out.println("Enter the Amount to Deposit:");
				double amount=sc.nextInt();
				transactions.Deposit(name,amount);
	
			}
			break;


			case 4:
			{
				loop=false;
			}
			break;

		

			
		}
	}


}
}