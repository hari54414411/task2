import java.util.*;
class DataBase
{
static Map<String,Double> AccountDetails=new HashMap<>();
}