import java.util.*;
class Transactions extends Thread
{
	

	public static void CheckBalance(String name)
	{
		System.out.println(name+"Balance: "+DataBase.AccountDetails.get(name));	
	}

	public synchronized static void Withdrawal(String name,double amount)
	{
	
		if(amount<=DataBase.AccountDetails.get(name))
		{
			double withdrawlamount=(DataBase.AccountDetails.get(name))-amount;
			DataBase.AccountDetails.put(name, withdrawlamount);
			System.out.println(name+"withdrawn"+amount+"\nBalance after withdrawal:"+withdrawlamount);
		
		}
		else 
		{
			System.out.println("Insuff Amount");
		}

		try{
				Thread.sleep(3000);
			}
			catch(Exception e){};

	}

	public synchronized static void Deposit(String name,double amount)
	{
			double Depositeamount=(DataBase.AccountDetails.get(name))+amount;
			DataBase.AccountDetails.put(name, Depositeamount);
			System.out.println(name+"Deposite"+amount+"\nBalance after Deposite:"+DataBase.AccountDetails.get(name));
		try{
				Thread.sleep(3000);
			}
			catch(Exception e){};

	}
}






