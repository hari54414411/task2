class History
{
	int id;
	String Type;
	Double amount;
	Double balance;

	History(int id,String Type,Double amount,Double balance)
	{
		this.id=id++;
		this.Type=Type;
		this.amount=amount;
		this.balance=balance;
	}	
	
	public String toString()
	{
		return this.id+" "+this.Type+" "+this.amount+" "+this.balance+"\n";
		
	}
	
		
}