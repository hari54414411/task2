import java.io.FileWriter;
import java.io.IOException;

class Files {
    private String name;

    public Files(String name)
    {
        this.name = name;
    }

    public void addAccount(int CustID,int  accountNumber, String accountHolder, double balance,String Password) {
        try (FileWriter writer = new FileWriter(name, true))
	 {
            writer.write(CustID+"   "+accountNumber + "    " + accountHolder + " " + balance + " "+Password+"\n");
        } 
	catch (IOException e) 
	{
            System.err.println("Error writing to file: " + e.getMessage());
        }
    }

    }
