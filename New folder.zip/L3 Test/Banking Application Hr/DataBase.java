import java.util.*;
class DataBase
{
	static Map<Integer,UserDetails> Details=new HashMap<>();
}