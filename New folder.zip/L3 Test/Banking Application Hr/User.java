import java.util.*;
import java.io.*;
class User {
    Scanner sc = new Scanner(System.in);

    public void LoginUser() {
        System.out.println("Enter the CustID:");
        int custID = sc.nextInt();

        System.out.println("Enter the Password:");
        String password = sc.next();
        String ep = EncryptedPassword(password);

        if (DataBase.Details.containsKey(custID) && DataBase.Details.get(custID).Password.equals(ep)) {
            System.out.println("1.ATM WithDrawal\n2.Cash Deposit\n3.Account Transfer");
            int option = sc.nextInt();
            Operations o = new Operations(custID);

            switch (option) {
                case 1:
                    o.WithDrawal();
                    break;

                case 2:
                    o.CashDeposit();
                    break;

                case 3:
                    o.AccountTransfer();
                    break;
            }

        } else {
            System.out.println("Enter the Correct password or custID");
        }
    }

    public void AdminLogin() {
        System.out.println("Enter the How many Members to Add");
        int n = sc.nextInt();

        for (int i = 0; i < n; i++) {
            System.out.println("Enter the CusterId:");
            int CustID = sc.nextInt();

            System.out.println("Enter the Account Number:");
            int Accnumber = sc.nextInt();

            System.out.println("Enter the Name:");
            String name = sc.next();

            System.out.println("Enter the Balance:");
            double Balance = sc.nextDouble();

            System.out.println("Enter the Encryptedpwd:");
            String Password = sc.next();

            String encryptedPassword = EncryptedPassword(Password);

            UserDetails ud = new UserDetails(CustID, Accnumber, name, Balance, encryptedPassword);

            DataBase.Details.put(CustID, ud);

            // Assuming Files and History classes are properly defined
            File f = new File("bank_db.txt");
            Files f1 = new Files("bank_db.txt");

            f1.addAccount(CustID, Accnumber, name, Balance, encryptedPassword);

            History h = new History(1, "Account Opening", Balance, Balance);

            UserDetails.history.add(h);

            System.out.println("------------------Successfully Added-------------------");
        }
    }

    public String EncryptedPassword(String s) {
        char[] c = s.toCharArray();
        for (int i = 0; i < c.length; i++) {
            char c1 = c[i];
            switch (c1) {
                case 'z':
                    c[i] = 'a';
                    break;
                case 'Z':
                    c[i] = 'A';
                    break;
                case '9':
                    c[i] = '0';
                    break;
                default:
                    c[i] = (char) (c1 + 1);
            }
        }
        return new String(c);
    }
}
