import java.util.*;
import java.lang.*;
public class Bank
{
    public static void main(String[] args) {
        System.out.println("-------------------Banking Application----------------------");
        Scanner sc = new Scanner(System.in);
        boolean loop = true;
        User b = new User();

        while (loop) {
            System.out.println("1. Login\n2. AdminLogin\n3. Exit");
            int option = sc.nextInt();

            switch (option) {
                case 1:
                    b.LoginUser();
                    break;
                case 2:
                    b.AdminLogin();
                    break;
                case 3:
                    loop = false;
                    break;
                default:
                    System.out.println("Invalid option. Please choose again.");
            }
        }
        sc.close();
    }
}