import java.util.*;
class Operations
{
	static int id=1;

	int CustId;
	Scanner sc=new Scanner(System.in);
	Operations(int CustId)
	{
		this.CustId=CustId;
	}

	UserDetails u=DataBase.Details.get(CustId);


	public void WithDrawal()
	{
		System.out.println("Enter the WithDrawal Amount");
		Double amount=sc.nextDouble();

		if(u.Balance<amount)	
		{
			double Amount=u.Balance-amount;

			u.Balance=Amount;

			History h=new History(id++,"ATM Withdrawal",amount,Amount);

			UserDetails.history.add(h);

			System.out.println("-----------------Successfully WithDrawal-----------------");
	
		}
				
			
	}

	public void CashDeposit()
	{
		System.out.println("Enter the CashDeposit Amount");
		Double amount=sc.nextDouble();

		double Amount=u.Balance+amount;

		u.Balance=amount;

		History h=new History(id++,"CashDeposit",amount,Amount);
		UserDetails.history.add(h);

		System.out.println("-----------------Successfully CashDeposit-----------------");
	}

	public void AccountTransfer()
	{
				
	}
}