import java.util.*;
class UserDetails
{

	int CustID;
	int Acccount;
	String Name;
	Double Balance;
	String Password;
	static ArrayList<History> history;

	UserDetails(int CustID,int Acccount,String Name,Double Balance,String Password)
	{
		this.CustID=CustID;
		this.Acccount=Acccount;
		this.Name=Name;
		this.Balance=Balance;
		this.Password=Password;
		history=new ArrayList<>();		
	}

	public String toString()
	{
		return this.CustID+" "+this.Acccount+" "+this.Name+" "+this.Balance+" "+this.Password;
	}
}