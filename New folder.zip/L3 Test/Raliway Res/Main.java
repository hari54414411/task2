import java.util.*;

class Main
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		boolean loop=true;

		while(loop)
		{
			System.out.println("1. BookTicket\n2. AvailableTickets\n3. CancelTicket\n4. ADDnewCoach\n5. ADDnewCabin\n6. Exit");
			int option=sc.nextInt();

			switch(option)
			{
				case 1:
				{
					Booking b=new Booking();
					b.BookTicket();
				}
				break;

				case 2:
				{
					AvailableTickets();
				}
				break;

				case 3:
				{
					CancelTicket();
				}
				break;

				case 4:
				{
					ADDnewCoach();
				}
				break;
	
				case 5:
				{
					ADDnewCabin();
				}
				break;

				case 6:
				{
					loop=false;
				}
				break;
			}
		}
	}
}