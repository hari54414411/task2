class Passenger
{
	String name;
	int age;
	String BP;
	ArrayList<Passenger> passengers;	

	Passenger(String name,int age,String BP)
	{
		this.name=name;
		this.age=age;
		this.BP=BP;
		passengers=new ArrayList<>();
	}
}