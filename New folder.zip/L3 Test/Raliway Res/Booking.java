class Booking
{
	Scanner sc=new Scanner(System.in);

	public static void BookTicket()
	{
		System.out.println("--------------Enter the member of tickect to Book");
		int t=sc.nextInt();
		

		for(int i=0;i<t;i++)
		{
			System.out.println("Enter the Passenger Name:");
			String name=sc.next();
			
			System.out.println("Enter the Passenger Age:");
			int age=sc.nextInt();
	
			System.out.println("Enter the BP(Lower\Middle\Upper)");
			int BP=sc.next():

			Passenger p=new Passenger(name,age,BP);
			
				
		}
			

	}
}