class DataBase
{

Map<Integer,ArrayList<passenger>> PassengerDetails=new HashMap<>();
}