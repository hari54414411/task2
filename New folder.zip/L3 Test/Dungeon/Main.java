import java.util.*;

public class Main {

    public static int shortestPath(String[][] dungeon, int startRow, int startCol, int endRow, int endCol) {
        int[][] directions = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
        Queue<int[]> queue = new LinkedList<>();
        queue.offer(new int[]{startRow, startCol});
        int steps = 0;

        while (!queue.isEmpty()) {
            int size = queue.size();
            steps++;

            for (int i = 0; i < size; i++) {
                int[] currentPosition = queue.poll();
                int row = currentPosition[0];
                int col = currentPosition[1];

                for (int[] dir : directions) {
                    int newRow = row + dir[0];
                    int newCol = col + dir[1];

                    if (newRow >= 0 && newRow < dungeon.length && newCol >= 0 && newCol < dungeon[0].length ) 
		    {
                        queue.offer(new int[]{newRow, newCol});
                        dungeon[newRow][newCol] = "Visited"; 
                    }
				
                    if (newRow == endRow && newCol == endCol) 
		    {

			
                        return steps;
                    }

		    
                }
            }
        }

        return -1;
    }



public static int shortestPath2(String[][] dungeon, int startRow, int startCol, int endRow, int endCol,int MRow,int MCol) {
        int[][] directions = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
        Queue<int[]> queue = new LinkedList<>();
        queue.offer(new int[]{startRow, startCol});

        int steps = 0;

        while (!queue.isEmpty()) {
            int size = queue.size();
            steps++;

            for (int i = 0; i < size; i++) {
                int[] currentPosition = queue.poll();
                int row = currentPosition[0];
                int col = currentPosition[1];

                for (int[] dir : directions) {
                    int newRow = row + dir[0];
                    int newCol = col + dir[1];
		
			
  		   if(dungeon[newRow][newCol]!="M")
		   {
			
		   }

                    if (newRow >= 0 && newRow < dungeon.length && newCol >= 0 && newCol < dungeon[0].length) 
		    {
                        queue.offer(new int[]{newRow, newCol});
                        dungeon[newRow][newCol] = "Visited"; 
                    }
				
                    if (newRow == endRow && newCol == endCol) 
		    {
			for (int[] pos : queue) 
			{
        		        System.out.print("(" + pos[0] + "," + pos[1] + ") ");
          	        }
			
                        return steps;
                    }
		}

		    
                }
            }
        

        return -1;
    }





    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        boolean loop = true;
        while (loop) {
            System.out.println("Dimensions of the dungeon (Row x Column):");
            int row = sc.nextInt();
            int column = sc.nextInt();
            String[][] Stage1= new String[row][column];

            System.out.println("Position Of Adventurer:");
            int pr = sc.nextInt()-1;
            int pc = sc.nextInt()-1;
            Stage1[pr][pc] = "A";

            System.out.println("Position of gold:");
            int gr = sc.nextInt()-1;
            int gc = sc.nextInt()-1;
            Stage1[gr][gc] = "G";

            int minSteps = shortestPath(Stage1, pr, pc, gr, gc);
            System.out.println("Minimum number of steps: " + (minSteps != -1 ? minSteps : "No path found"));
	
		if(minSteps==-1)
		{
			break;
		}	
	   boolean loop1=true;
	   while(loop1)
	   {
	    System.out.println("Dimensions of the dungeon (Row x Column):");
            int row1 = sc.nextInt();
            int column1 = sc.nextInt();
            String[][] Stage2= new String[row1][column1];

            System.out.println("Position Of Adventurer:");
            int pr1 = sc.nextInt()-1;
            int pc1 = sc.nextInt()-1;
            Stage2[pr1][pc1] = "A";

            System.out.println("Position of gold:");
            int gr1 = sc.nextInt()-1;
            int gc1 = sc.nextInt()-1;
            Stage2[gr1][gc1] = "G";

	    System.out.println("Position of monster:");
	    int mr=sc.nextInt()-1;
	    int mc=sc.nextInt()-1;
	    Stage2[mr][mc]="M";	


            int minSteps2 = shortestPath2(Stage2, pr1, pc1, gr1, gc1,mr,mc);
            System.out.println("Minimum number of steps: " + (minSteps2 != -1 ? minSteps2 : "No path found"));


		
	

           
            System.out.println("Do you want to continue? (yes/no)");
            String continueInput = sc.next().toLowerCase();
            if (!continueInput.equals("yes")) {
                loop1 = false;
		loop=false;
            }
	}
	    
			
        }
    }
}

