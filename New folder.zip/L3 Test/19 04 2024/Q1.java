class Q1 {
    public static boolean solveMaze(int[][] maze) {
        int n = maze.length;
        int[][] solution = new int[n][n];
        if (!solveMazeUtil(maze, 0, 0, solution)) {
            System.out.println("No solution exists.");
            return false;
        }
        printSolution(solution);
        return true;
    }

    public static  boolean solveMazeUtil(int[][] maze, int x, int y, int[][] solution) {
        int n = maze.length;
        if (x == n - 1 && y == n - 1 && maze[x][y] == 1) {
            solution[x][y] = 1;
            return true;
        }
        if (isSafe(maze, x, y)) {
            solution[x][y] = 1;
            if (solveMazeUtil(maze, x + 1, y, solution))
                return true;
            if (solveMazeUtil(maze, x, y + 1, solution))
                return true;
            solution[x][y] = 0;
            return false;
        }
        return false;
    }

    public static boolean isSafe(int[][] maze, int x, int y) {
        int n = maze.length;
        return x >= 0 && x < n && y >= 0 && y < n && maze[x][y] == 1;
    }

    public static void printSolution(int[][] solution) {
        int n = solution.length;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(solution[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
       
        int[][] maze = {{1, 0, 0, 0}, {1, 1, 0, 1}, {0, 1, 0, 0}, {1, 1, 1, 1}};
        solveMaze(maze);
    }
}
