class Q2 
{
    public static int longestZigZag(int[] arr) {
        int n = arr.length;
        if (n <= 1) return n;

        int[][] dp = new int[n][2];
        int maxLen = 1;
        for (int i = 0; i < n; i++) {
            dp[i][0] = 1;
            dp[i][1] = 1;
            for (int j = 0; j < i; j++) {
                if (arr[i] > arr[j]) {
                    dp[i][0] = Math.max(dp[i][0], dp[j][1] + 1);
                } else if (arr[i] < arr[j]) {
                    dp[i][1] = Math.max(dp[i][1], dp[j][0] + 1);
                }
            }
            maxLen = Math.max(maxLen, Math.max(dp[i][0], dp[i][1]));
        }
        return maxLen;
    }

    public static void main(String[] args) {
      
        int[] arr1 = {1, 5, 4};
        System.out.println(longestZigZag(arr1)); 
        int[] arr2 = {1, 4, 5};
        System.out.println(longestZigZag(arr2)); 

        int[] arr3 = {10, 22, 9, 33, 49, 50, 31, 60};
        System.out.println(longestZigZag(arr3));
    }
}
