import java.util.*;
public class Main {
    public static void main(String[] args) {
        // Sample usage
        Map<String, Double> tollRates1 = new HashMap<>();
        tollRates1.put("car", 5.0);
        tollRates1.put("truck", 10.0);
        Toll toll1 = new Toll("Toll1", tollRates1);
        
        Map<String, Double> tollRates2 = new HashMap<>();
        tollRates2.put("car", 7.0);
        tollRates2.put("truck", 15.0);
        Toll toll2 = new Toll("Toll2", tollRates2);

        List<Toll> tolls = new ArrayList<>();
        tolls.add(toll1);
        tolls.add(toll2);

        Highway highway = new Highway(tolls);

        double toll = highway.calculateTotalToll("car", "A", "B", true);
        System.out.println("Total toll: " + toll);




    }
}