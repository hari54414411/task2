import java.util.*;
class Vehicle {
    private String vehicleNumber;
    private List<Journey> journeys;

    public Vehicle(String vehicleNumber) {
        this.vehicleNumber = vehicleNumber;
        this.journeys = new ArrayList<>();
    }

    public void addJourney(Journey journey) {
        journeys.add(journey);
    }

    public List<Journey> getJourneys() {
        return journeys;
    }

    public String getVehicleNumber() {
        return vehicleNumber;
    }
}
