import java.util.*;

class Journey {
    private String vehicleNumber;
    private String start;
    private String destination;
    private List<String> passedTolls;
    private double totalAmountPaid;

    public Journey(String vehicleNumber, String start, String destination, List<String> passedTolls, double totalAmountPaid) {
        this.vehicleNumber = vehicleNumber;
        this.start = start;
        this.destination = destination;
        this.passedTolls = passedTolls;
        this.totalAmountPaid = totalAmountPaid;
    }

    public String getVehicleNumber() {
        return vehicleNumber;
    }

    public String getStart() {
        return start;
    }

    public String getDestination() {
        return destination;
    }

    public List<String> getPassedTolls() {
        return passedTolls;
    }

    public double getTotalAmountPaid() {
        return totalAmountPaid;
    }
}
