class Q1
{

	public static int method(int arr[])
	{
		int s=0;
		for(int i=0;i<arr.length;i++)
		{
			s=s^arr[i];
		}
	return s;
	}
public static void main(String[] args)
{
	int num[]={2,2,3,2};
	System.out.println(method(num));

}
}