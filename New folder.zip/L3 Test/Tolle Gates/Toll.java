import java.util.*;
class Toll {
    private String tollName;
    private Map<String, Double> vehicleTypeToRate;
    private List<String> vehiclesPassed;

    public Toll(String name, Map<String, Double> rates) {
        this.tollName = name;
        this.vehicleTypeToRate = rates;
        this.vehiclesPassed = new ArrayList<>();
    }

    public String getTollName() {
        return tollName;
    }

    public double calculateToll(String vehicleType, boolean isVIP) {
        double rate = vehicleTypeToRate.getOrDefault(vehicleType, 0.0);
        if (isVIP) {
            return rate * 0.8; // Applying 20% discount
        }
        return rate;
    }

    public void recordVehiclePass(String vehicleNumber) {
        vehiclesPassed.add(vehicleNumber);
    }

    public List<String> getVehiclesPassed() {
        return vehiclesPassed;
    }
}
