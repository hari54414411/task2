import java.util.*;
class Highway {
    private List<Toll> tolls;
    private List<Journey> journeys;
    private Map<String, Vehicle> vehicles;

    public Highway(List<Toll> tolls) {
        this.tolls = tolls;
        this.journeys = new ArrayList<>();
        this.vehicles = new HashMap<>();
    }

    public void addJourney(Journey journey) {
        journeys.add(journey);
        Vehicle vehicle = vehicles.computeIfAbsent(journey.getVehicleNumber(), Vehicle::new);
        vehicle.addJourney(journey);
        for (String tollName : journey.getPassedTolls()) {
            Toll toll = getTollByName(tollName);
            toll.recordVehiclePass(journey.getVehicleNumber());
        }
    }

    public double calculateTotalToll(String vehicleType, String start, String destination, boolean isVIP) {
        double totalToll = 0.0;
        for (Toll toll : tolls) {
            totalToll += toll.calculateToll(vehicleType, isVIP);
        }
        return totalToll;
    }

    public void displayTollDetails() {
        for (Toll toll : tolls) {
            System.out.println("Toll Name: " + toll.getTollName());
            System.out.println("Vehicles Passed: " + toll.getVehiclesPassed());
            // Add more details as needed
        }
    }

    public void displayVehicleDetails() {
        for (Vehicle vehicle : vehicles.values()) {
            System.out.println("Vehicle Number: " + vehicle.getVehicleNumber());
            for (Journey journey : vehicle.getJourneys()) {
                System.out.println("Start: " + journey.getStart());
                System.out.println("Destination: " + journey.getDestination());
                System.out.println("Passed Tolls: " + journey.getPassedTolls());
                System.out.println("Total Amount Paid: " + journey.getTotalAmountPaid());
            }
            // Add more details as needed
        }
    }

    private Toll getTollByName(String tollName) {
        for (Toll toll : tolls) {
            if (toll.getTollName().equals(tollName)) {
                return toll;
            }
        }
        return null;
    }

    // Other methods for finding shortest route, calculating tolls between routes, etc.
}
