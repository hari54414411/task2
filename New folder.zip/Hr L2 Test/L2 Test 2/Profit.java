import java.util.*;
class Profit
{
public static void main(String[] args)
{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the days of stock:");
	int size=sc.nextInt();
	int arr[]=new int[size];
	for(int i=0;i<size;i++)
	{
		arr[i]=sc.nextInt();
	}
        int min=arr[0];
        int max=0;
        int profit=0;

	for(int j=0;j<arr.length;j++)
	{
			
		if(min>arr[j])
		{
			min=arr[j];

		}
		profit=arr[j]-min;
		if(max<profit)
		{
			max=profit;

		}
	}
System.out.println("profit  :"+max);

}

}