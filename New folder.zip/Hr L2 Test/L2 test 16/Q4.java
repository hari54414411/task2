import java.util.*;
class Q4
{

public static boolean method(String s,String t)
{
  int count=0;
	for(int i=0;i<s.length();i++)
	{
		for(int j=0;j<t.length();j++)
		{
			if(s.charAt(i)==t.charAt(j))
			{
				count++;
				break;	
			}
		}
		if(count==s.length()||count==t.length())	
		{
			return true;
		}
	}
return false;
}
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter the String s:");
String s=sc.next();
System.out.println("Enter the String t:");
String t=sc.next();
System.out.println(method(s,t));
}
}