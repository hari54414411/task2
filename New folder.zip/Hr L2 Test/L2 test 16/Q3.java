import java.util.*;
class Q3
{

	public static String method(String s1,String s2)
	{
		StringBuilder sb=new StringBuilder();

		for(int i=0;i<=s1.length();i++)
		{
			if(s1.charAt(i)==s2.charAt(i))
			{
				sb.append("g");
			}
			else if(s2.charAt(i)==s1.charAt(i+1))
			{
				sb.append("y");
			}
			else if(s1.charAt(i)!=s2.charAt(i))
			{
				sb.append("-");
			}
		}
return sb.toString();
	}
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter the String s:");
String s1=sc.next();
System.out.println("Enter the String t:");
String s2=sc.next();
System.out.println(method(s1,s2));

}
}