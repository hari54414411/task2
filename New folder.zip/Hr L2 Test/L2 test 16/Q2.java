import java.util.*;
class Q2
{
public static long Excel(String s)
{
long ans=0;

for(char c:s.toCharArray())
{
	int num=(c-'A'+1);
	ans=ans*26+num;
}
return ans;
}
public static void main(String[] args)
{

Scanner sc=new Scanner(System.in);
System.out.println("Enter the String:");
String s=sc.next();
System.out.println(Excel(s));
}
}