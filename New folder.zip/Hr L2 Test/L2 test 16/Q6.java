import java.util.*;
class Q6
{
    public static String decodeString(String s) 
    {
        int i=0;
	StringBuilder sb=new StringBuilder();

	while(i<s.length())
	{
		char c=s.charAt(i);
		if(Character.isDigit(c))
		{
			int numstart=i;
			while(Character.isDigit(s.charAt(i+1)))
			{	
				i++;
			}

			int num=Integer.parseInt(s.substring(numstart,i+1));
			int start=i+2;

			int end=findEndOfEncodedString(s,start);

			String decodestring=decodeString(s.substring(start,end));
			
			for(int j=0;j<num;j++)
			{
				sb.append(decodestring);
			}
			i=end+1;
		}
		else
		{
			sb.append(c);
			i++;
		}

	} 

return sb.toString();
   
    }
	public static int findEndOfEncodedString(String s,int start)
	{
		int brackets=1;
		int i=start;
		while(brackets!=0)
		{
			if(s.charAt(i)=='[')
			{
				brackets++;
			}
			else if(s.charAt(i)==']')
			{
				brackets--;
			}
			i++;
		}
		return i-1;
	}
public static void main(String[] args)
{
	Scanner sc=new Scanner(System.in);
	String s=sc.next();

	System.out.println(decodeString(s));
}
}