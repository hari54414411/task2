import java.util.*;
class Q1
{
public static int Missing(int arr[])
{
	int n=arr.length;
	int m=n*(n+1)/2;
	int sum=0;
for(int i=0;i<arr.length;i++)
{
	sum+=arr[i];
}
return m-sum;

}

public static void main(String[] args)
{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the Size of the Array:");
	int size=sc.nextInt();
	int arr[]=new int[size];

	for(int i=0;i<size;i++)
	{
		arr[i]=sc.nextInt();
	}

System.out.println(Missing(arr));

	
}
}