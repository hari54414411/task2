import java.util.*;
class Subset
{
	public static boolean method(int arr[],int sum)
	{
	for(int i=0;i<arr.length;i++)
	{
	for(int j=i+1;j<arr.length;j++)
	{
	if(sum==arr[i]+arr[j])
	{
	return true;
	}
	}
	}
	return false;
	}


public static void main(String[] args)
{
	Scanner s=new Scanner(System.in);
	System.out.println("Enter the Array Size:");
	int size=s.nextInt();
        int arr[]=new int[size]; 
	
        System.out.println("Enter the Array values");
	for(int i=0;i<size;i++)
	{
	arr[i]=s.nextInt();
	}
	System.out.println("Enter the Sum Value:");
	int sum=s.nextInt();
        System.out.println(method(arr,sum));
}
}