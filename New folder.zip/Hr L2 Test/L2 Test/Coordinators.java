import java.util.*;
class Coordinators
{
public static void main(String[] args)
{
	Scanner s=new Scanner(System.in);
	System.out.println("Enter the Array Size:");
	int size=s.nextInt();
        int arr[]=new int[size]; 
	
        System.out.println("Enter the Array values");
	for(int i=0;i<size;i++)
	{
	arr[i]=s.nextInt();
	}
        int max=arr[arr.length-1];
	for(int i=arr.length-1;i>=0;i--)
	{
	if(arr[i]>max)
	{
	max=arr[i];
	System.out.print("Coordinators elements: "+max+" ");
	}
	}

}
}