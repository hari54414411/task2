import java.util.*;
class Parenthesis
{
	public static int method(String s)
	{
	int open=0;
	int close=0;
	
	if(s.charAt(0)=='(')
	{
	for(int i=0;i<s.length();i++)
	{
		if(s.charAt(i)=='(')
		{
		open++;
		}
        	else	
		{
		close++;	
		}
	}
	if(open==close)
	{
	return open;	
	}
	else if(open<close)
	{
	return close-open;
	}
	else 
	{
	return open-close;
	}
	}
	return -1;
	}

public static void main(String[] args)
{
Scanner s=new Scanner(System.in);
System.out.println("Enter the String Parenthesis:");
String s1=s.next();
System.out.println(method(s1));

}
}