class Formed
{
public static void main(String[] args)
{
String[] s={"cat","table","eat","tic","xyz"};
int count=1;
int ans=-1;

for(int i=1;i<s.length;i++)
{
if(s[i-1].charAt(s[i-1].length()-1)==s[i].charAt(0))
{
count++;
ans=count;
}

}
System.out.println(ans);
}
}
