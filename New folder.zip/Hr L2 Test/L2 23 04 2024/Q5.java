class Q5
{

	public static void method(int arr[])
	{
		int max=Integer.MIN_VALUE;
		int n=1<<arr.length;
		for(int i=0;i<n;i++)
		
		{
			String s="";
			int count=0;
			int sum=1;
			for(int j=0;j<arr.length;j++)
			{
				if((i&(1<<j))!=0)
				{
					s+=arr[j]+" ";
					sum*=arr[j];
					count++;

				}
			}
			if(count==3&&max<sum)
			{
				max=sum;
					
			}
		}
System.out.println(max);
			
	}
	public static void main(String[] args)
	{
		int arr[]={1,-4,3,-6,7,0};
		method(arr);
	}
}