import java.util.*;
class Q3
{
	public static void method(int arr[],int sum)
	{
		int left=0;
		int right=arr.length-1;
		
		while(left<=right)
		{
			int sum2=arr[left]+arr[right];
			if(sum==sum2)
			{
				System.out.println(arr[left]+" "+arr[right]);
				left++;
			}
			else
			{
				right--;
			}
		}
	}
	public static void main(String[] args)
	{
		int arr[]={1,-2,1,0,5};
		int sum=0;

		method(arr,sum);
	}
}