import java.util.*;
class Q2
{

	public static int[] RemovingDuplicates(int arr[])
	{
		
		int p=arr[0];
		int j=1;
		Arrays.sort(arr);
		for(int i=1;i<arr.length;i++)
		{
			if(arr[i]!=p)
			{
				p=arr[i];
				arr[j++]=p;
								
			}
						
		}
	int arr1[]=new int[j];

	for(int i=0;i<arr1.length;i++)
	{
		arr1[i]=arr[i];
	}
		


return arr1;
		
	}
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Array Size:");
		int size=sc.nextInt();
		int arr[]=new int[size];
		for(int i=0;i<size;i++)
		{
			arr[i]=sc.nextInt();
		}
		
		System.out.println(Arrays.toString(RemovingDuplicates(arr)));
	}

}
