import java.util.*;
class Q4
{

	public static void method(int arr[])
	{
		boolean flag=true;
		for(int i=0;i<arr.length;i++)
		{
			int k=i;
			for(int j=i;j<arr.length;j++)
			{
				if(flag && arr[k]>arr[j])
				{
					k=j;
				}
				else if(!flag && arr[k]<arr[j])
				{
					k=j;
				}			
			}

			int temp=arr[i];
			arr[i]=arr[k];
			arr[k]=temp;
			flag=(flag)?false:true;
		}
	}
	public static void main(String[] args)
	{
	int arr[]={1,2,3,4,5,6,7,8,9};
	method(arr);
	System.out.println(Arrays.toString(arr));	
	}
}
