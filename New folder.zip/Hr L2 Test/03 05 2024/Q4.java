import java.util.*;
class Q4
{

	public static String method(int num)
	{
		int i=(num-1)/6;
		int j=(num-1)%6;

		if(i%2==1)
		{
			j=6-j-1;
		}
		
		

		if(j==0||j==5)
		{
			return "WS";
		}
		else if(j==1||j==4)
		{
			return "MS";
		}
	return "AS";

		
	}

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
		int num=sc.nextInt();
		System.out.println(method(num));

	}
}