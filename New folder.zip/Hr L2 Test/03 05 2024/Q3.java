import java.util.*;
class Q3
{

	public static int[] MovingZero(int nums[])
	{
	int j=0;
        for(int i=0;i<nums.length;i++)
        {
            if(nums[i]!=0)
            {
                int tem=nums[i];
                nums[i]=nums[j];
                nums[j]=tem;
                j++;
            }
       }

	return nums;
	}

	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Array Size");
		int size=sc.nextInt();
		
		int arr[]=new int[size];
		System.out.println("Enter the Array Values");

		for(int i=0;i<size;i++)
		{
			arr[i]=sc.nextInt();
		}
		System.out.println(Arrays.toString(MovingZero(arr)));
	}
}