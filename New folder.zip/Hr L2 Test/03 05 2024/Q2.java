import java.util.*;
class Q2
{

	public static int[] Combine(int arr[],int m,int arr2[],int n)
	{
		int mergearr[]=new int[m+n];
		int k=0;
		for(int i=0;i<m+n;i++)
		{
			if(i%2==0)
			{
				mergearr[i]=arr[k];
				k++;
			}	
		}
		int j=0;
		for(int i=0;i<m+n;i++)
		{
			if(i%2==1)
			{
				mergearr[i]=arr2[j];
				j++;
			}	
		}
return mergearr;

	}

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Array Size");
		int size=sc.nextInt();
		
		int arr[]=new int[size];
		System.out.println("Enter the Array Values");

		for(int i=0;i<size;i++)
		{
			arr[i]=sc.nextInt();
		}

		System.out.println("Enter the Array Size2");
		int size2=sc.nextInt();
		
		int arr2[]=new int[size2];
		System.out.println("Enter the Array2 Values");

		for(int i=0;i<size2;i++)
		{
			arr2[i]=sc.nextInt();
		}


		
		System.out.println(Arrays.toString(Combine(arr,size,arr2,size2)));
	}
}