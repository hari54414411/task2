import java.util.*;
class Q6
{

	public static int method(int arr[],int arr2[])
	{
		int min=Integer.MAX_VALUE;
		int sum=0;

		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr2.length;j++)
			{
				if(i!=j)
				{
		
					sum=arr[i]+arr2[j];
					if(min>sum)
					{
						min=sum;
					}
					sum=0;
				}					
			}
		}
	return min;
	}
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Array Size");
		int size=sc.nextInt();
		
		int arr[]=new int[size];

		System.out.println("Enter the Array Values");

		for(int i=0;i<size;i++)
		{
			arr[i]=sc.nextInt();
		}

				
		int arr2[]=new int[size];
		System.out.println("Enter the Array2 Values");

		for(int i=0;i<size;i++)
		{
			arr2[i]=sc.nextInt();
		}
		
		System.out.println(method(arr,arr2));
		

	}
}