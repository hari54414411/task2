import java.util.*;
class Q5
{

	public static String method(int arr[])
	{
		int sum=0;
		int sum2=0;
		for(int i=0;i<arr.length;i++)
		{
			sum+=arr[i];
		}

		for(int i=0;i<arr.length;i++)
		{
			sum-=arr[i];
						
			if(sum==sum2)
			{
				return "YES";
			}
			sum2+=arr[i];
		}
		return "NO";

		
	}
	
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Array Size");
		int size=sc.nextInt();
		
		int arr[]=new int[size];
		System.out.println("Enter the Array Values");

		for(int i=0;i<size;i++)
		{
			arr[i]=sc.nextInt();
		}

		System.out.println(method(arr));
	}
}