import java.util.*;
class Q1
{
	public static void main(String[] args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the String:");

		String s=sc.next();
 
		String s1="";
		int n=s.length();
		int f[] = new int[26];

		Arrays.fill(f,-1);

		for(int i=0;i<n;i++)
		{

			f[s.charAt(i)-'a']++;

		
		}
		for(int i=0;i<n;i++)
		{
			if(f[s.charAt(i)-'a']!=-1)
			{
				s1+=s.charAt(i);
				f[s.charAt(i)-'a']=-1;

			}

	
		}
		System.out.println(s1);
		
}


}
		
