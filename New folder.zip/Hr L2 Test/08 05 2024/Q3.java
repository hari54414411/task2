import java.util.*;
class Q3
{

	public static int method(String s)
	{
		
       		 int P[] = new int[26];
        	 int Q[] = new int[26];

        	 int K=0,L=0;
       		 int count=0;

        for(int i=0;i<s.length();i++)
        {
            	Q[s.charAt(i)-97]++;
            if(Q[s.charAt(i)-97] == 1)
                L++;
        }


        for(int i=0;i<s.length();i++)
        {
            P[s.charAt(i)-97]++;
            Q[s.charAt(i)-97]--;
            if(Q[s.charAt(i)-97] == 0)
	    {
                L--;
	    }
		
            if(P[s.charAt(i)-97] == 1)
	    {
               K++;
	    }

            if(K == L)
	    {
                count++;
	    }
        }
        return count;
    }


	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String:");
		String S=sc.next();
		System.out.println(method(S));
	}
}