class Generation {
    String name;
    static int leaveDays;
    static int salary = 12000;
    static double DA;
    static int HRA = 150;
    static int TA = 120;
    static int PF;
    static int IT;
    static int others = 450;

    Generation(String name) {
        this.name = name;
    }

    public void calculate() {
        DA = (salary / 100) * 12;
        PF = (salary / 100) * 14;
        IT = (salary / 100) * 15;
        double netSalary = ((salary + DA + HRA + TA + others) - (PF + IT));
        System.out.println("Net Salary for " + name + ": $" + netSalary);
    }
}