import java.util.*;
class ElecticBillgeneration
{
public static void main(String[] args)
{
boolean loop=true;
while(loop)
{
System.out.println("Enter the choice \n1. Domestic \n2. commercial cases \n3. Exit:");
Scanner s=new Scanner(System.in);
int choice=s.nextInt();
System.out.println("Enter the units of Current:");
int Units=s.nextInt();
switch (choice) 
{

case 1:
{
Domestic d=new Domestic();
d.calculatedomestic(Units);
break;
}
case 2:
{
Commercial c=new Commercial();
c.calculatecommercialcases(Units);
break;
}
case 3:
{
loop=false;
break;
}
}
}
}
}