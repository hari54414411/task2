class TaxiBookingSystem
{
private List<Taxi> taxis;
TaxiBookingSystem(int numTaxis) {
taxis = new ArrayList<>();
for (int i = 1; i <= numTaxis; i++) 
{
taxis.add(new Taxi(i));
}
}
public String bookTaxi(int customerId, String pickupPoint, String dropPoint, int pickupTime) {
Taxi availableTaxi = findNearestAvailableTaxi(pickupPoint, pickupTime);
if (availableTaxi != null) {
int distance = calculateDistance(pickupPoint, dropPoint);
int fare = availableTaxi.calculateFare(distance);
availableTaxi.updatePosition(dropPoint, pickupTime, distance);
availableTaxi.earning += fare;
return "Taxi can be allotted.\nTaxi-" + availableTaxi.getId() + " is allotted";
} 
else 
{
return "Booking rejected. No available taxis.";
}
}

private Taxi findNearestAvailableTaxi(String pickupPoint, int pickupTime) {
Taxi nearestTaxi = null;
int minDistance = Integer.MAX_VALUE;
for (Taxi taxi : taxis) {
if (taxi.getCurrentPoint().equals(pickupPoint)) {
if (nearestTaxi == null || taxi.getEarning() < nearestTaxi.getEarning()) {
nearestTaxi = taxi;
} 
else 
{
int distance = calculateDistance(taxi.getCurrentPoint(), pickupPoint);
int arrivalTime = taxi.getCurrentTime() + (distance * 60); // 60 minutes per kilometer
if (arrivalTime <= pickupTime && distance < minDistance) {
nearestTaxi = taxi;
minDistance = distance;
}
}
}
return nearestTaxi;
}
private int calculateDistance(String point1, String point2) {
char p1 = point1.charAt(0);
char p2 = point2.charAt(0);
return Math.abs(p1 - p2) * 15;
}
}
}