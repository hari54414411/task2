import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class SalaryGeneration {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("                   Salary Generation                   ");
        boolean loop = true;
        List<Generation> generationList = new ArrayList<>();
        while (loop) {
            System.out.println("\n1. Add Employee\n2. Generate Salary\n3. Exit");
            int choice = s.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("Enter the Employee Name:");
                    String name = s.next();
                    generationList.add(new Generation(name));
                    break;
                case 2:
                    System.out.println("\nGenerating Salary...");
                    for (Generation employee : generationList) {
                        employee.calculate();
                    }
                    break;
                case 3:
                    loop = false;
                    break;
                default:
                    System.out.println("Invalid choice. Please enter again.");
            }
        }
        s.close();
    }
}