class Commercial
{

public void calculatecommercialcases(int unit)
{
System.out.println("Per unit electricity charge in Tamilnadu is Rs.5.50 till 100 units, Rs.8.00 from 101 till 200 unit");
double totalbill;
double perunitamount=5.50;
double perunitamount101to200=8.00;
if(unit<=100)
{
totalbill=perunitamount*unit;
System.out.println("Bill Amount:"+totalbill);
}
else
{
totalbill=perunitamount101to200*unit;
System.out.println("Bill Amount:"+totalbill);
}

}
}