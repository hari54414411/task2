import java.util.*;
class Booking
{
public static void main(String[] args)
{
Scanner s=new Scanner(System.in);
int id=0;
boolean loop=true;
while(loop)
{
System.out.println("1.Book Taxi\n2.Show TaxiDetails");
int choice=s.nextInt();
switch(choice)
{
case 1:
{
id++;
System.out.println("Enter the pickup:");
String pickup=s.next();
System.out.println("Enter the drop:");
String drop=s.next();
System.out.println("Enter the Time:");
int time=s.nextInt();
TaxiBookingSystem b1=new TaxiBookingSystem(100);
b1.bookTaxi(id,pickup,drop,time);
}
break;

break;
case 3:
{
loop=false;
}

}
}
}
}