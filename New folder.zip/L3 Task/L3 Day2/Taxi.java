import java.util.ArrayList;
import java.util.List;

class Taxi1 
{
public  int id;
public String currentPoint;
public  int currentTime;
public  int earning;

public Taxi1(int id)
{
this.id = id;
this.currentPoint = "A";
this.currentTime = 0;
this.earning = 0;
}
public int getId() 
{
return id;
}
public String getCurrentPoint() 
{
return currentPoint;
}
public int getCurrentTime() 
{
return currentTime;
 }
public int getEarning() 
{
return earning;
}
public void updatePosition(String newPoint, int pickupTime, int distance) 
{
this.currentPoint = newPoint;
this.currentTime = pickupTime + (distance * 60); 
}
private int calculateFare(int distance) 
{
int fare = 100; 
if (distance > 5) 
{
fare += (distance - 5) * 10; 
}
return fare;
}
}

