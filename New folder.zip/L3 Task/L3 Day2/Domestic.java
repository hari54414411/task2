class Domestic
{
public void calculatedomestic(int unit)
{
System.out.println("Per unit electricity charge in Tamilnadu is Rs.1.50 till 100 units, Rs.2.00 from 101 till 200 unit");
double totalbill;
double perunitamount=1.50;
double perunitamount101to200=2.00;
if(unit<=100)
{
totalbill=perunitamount*unit;
System.out.println("Bill Amount:"+totalbill);
}
else
{
totalbill=perunitamount101to200*unit;
System.out.println("Bill Amount:"+totalbill);

}
}

}