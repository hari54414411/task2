import java.sql.*;
import java.util.*;

class JDBC {
    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            String url = "jdbc:mysql://localhost:3306/students";
            String userName = "root";
            String password = "2904";
            Connection con = DriverManager.getConnection(url, userName, password);
	    Statement stmt = con.createStatement();

            Scanner sc = new Scanner(System.in);
            boolean b = true;

            while (b) {
                System.out.println("1.Insert\n2.Read\n3.Update\n4.Delete\n5.Exit");
                int option = sc.nextInt();
                switch (option) {
                    case 1: {
                        System.out.println("Enter the studentId");
                        int id = sc.nextInt();

                        System.out.println("Enter the studentname");
                        String name = sc.next();

                        System.out.println("Enter the studentDOB");
                        String DOB = sc.next();

                        System.out.println("Enter the studentAddress");
                        String Address = sc.next();

                        System.out.println("Enter the studentemail");
                        String email = sc.next();

                        System.out.println("Enter the studentCGPA");
                        String cgpa = sc.next();

                        String insert = "INSERT INTO students(studentId,studentname,studentDOB,studentAddress,studentEmail,studentCGPA) " +
                                        "VALUES(" + id + ",'" + name + "','" + DOB + "','" + Address + "','" + email + "','" + cgpa + "')";
                        stmt.executeUpdate(insert);
			System.out.println("--------------successfully Add StudentId-------------");
                    }
                    break;

                    case 2:
                    {
			String selectquery="SELECT * FROM students";
               		ResultSet rs = stmt.executeQuery(selectquery);
			 while(rs.next())	
			 {		

				
				int id=rs.getInt(1);
				String name=rs.getString(2);
				String DOB=rs.getString(3);
				String Address=rs.getString(4);
				String email=rs.getString(5);
				String CGPA=rs.getString(6);

				System.out.println("studentId-"+id+"\n"+"studentName-"+name+"\n"+"studentDOB-"+DOB+"\n"+"studentAddress-"+Address+"\n"+"studentEmail-"+email+"\n"+"studentCGPA-"+CGPA);

				System.out.println("------------------------------------");

			 }

		    }
                        break;

                    case 3:
                    {
			System.out.println("Enter the Students Id:");
			int id=sc.nextInt();

			System.out.println("Enter the change Column");
			String change=sc.next();

			System.out.println("Enter the "+change+":");
			String input=sc.next();
		
			stmt.executeUpdate("Update students set "+change+"="+input+" where studentId ="+id);
			
	
			

			

		    }
		    break;

		    case 4:
                    {
			System.out.println("Enter the Student Id:");
			int id=sc.nextInt();
			stmt.executeUpdate("Delete from students where studentId ="+id);
			System.out.println("----------------Successfully Studens Details Deleted-----------------");
		    }
		    break;

			

                    case 5:
                        b = false;
                        break;
                }
            }
        } catch (Exception e) {
            System.out.println("Error: " + e);
        }
    }
}
