import java.util.*;
class Q2
{

	public static String[] method(String s[])
	{
		Map<String, Integer> map= new HashMap<>();
                List<String> result = new ArrayList<>();

		for(String s1:s)
		{
			String parts[]=s1.split(" ");
			int count=Integer.parseInt(parts[0]);
			String sub[]=parts[1].split("\\.");

			String CurrentDomain="";
			for(int i=sub.length-1;i>=0;i--)
			{
				CurrentDomain=sub[i]+(i<sub.length-1?".":"")+CurrentDomain;
				map.put(CurrentDomain,map.getOrDefault(CurrentDomain,0)+count);
			}

			for(Map.Entry<String,Integer> entry:map.entrySet())
			{
				 result.add(entry.getValue() + " " + entry.getKey());
			}
		}
		
		return result.toArray(new String[0]);


	}
	
public static void main(String[] args)
{
	 String[] s= {"9001 discuss.ashwin.com"};
	System.out.println(Arrays.toString(method(s)));
}
}