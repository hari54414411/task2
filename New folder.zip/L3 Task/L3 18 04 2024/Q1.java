import java.util.HashSet;
import java.util.Set;

public class BoggleSolver {
    private char[][] board;
    private Set<String> dictionary;
    private boolean[][] visited;
    private int[] row = {-1, -1, -1, 0, 0, 1, 1, 1};
    private int[] col = {-1, 0, 1, -1, 1, -1, 0, 1};
    private Set<String> result;

    public BoggleSolver(char[][] board, Set<String> dictionary) {
        this.board = board;
        this.dictionary = dictionary;
        this.visited = new boolean[board.length][board[0].length];
        this.result = new HashSet<>();
    }

    public Set<String> findWords() {
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[0].length; j++) {
                dfs(i, j, "");
            }
        }
        return result;
    }

    private void dfs(int i, int j, String path) {
        if (!isValid(i, j)) return;

        visited[i][j] = true;
        path += board[i][j];

        if (dictionary.contains(path)) {
            result.add(path);
        }

        for (int k = 0; k < 8; k++) {
            int nextRow = i + row[k];
            int nextCol = j + col[k];
            dfs(nextRow, nextCol, path);
        }

        visited[i][j] = false;
    }

    private boolean isValid(int i, int j) {
        return i >= 0 && i < board.length && j >= 0 && j < board[0].length && !visited[i][j];
    }

    public static void main(String[] args) {
        char[][] board = {
                {'S', 'T', 'A', 'R'},
                {'N', 'O', 'T', 'E'},
                {'S', 'A', 'N', 'D'},
                {'S', 'T', 'O', 'N'}
        };

        Set<String> dictionary = new HashSet<>();
        dictionary.add("START");
        dictionary.add("NOTE");
        dictionary.add("SAND");
        dictionary.add("STONED");

        BoggleSolver solver = new BoggleSolver(board, dictionary);
        Set<String> validWords = solver.findWords();

        System.out.println("Valid Words: " + validWords);
    }
}
