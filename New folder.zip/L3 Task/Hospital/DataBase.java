import java.util.*;
class DataBaste
{
static Map<Integer,User> Details=new HashMap<>();
static Queue<User> WaitingPatient= new LinkedList<>();


}