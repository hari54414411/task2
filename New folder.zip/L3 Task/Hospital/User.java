class User
{
	String Name;
	int PatientId;
	long MobileNumber;
	String Location;
	String Intime;
	String Outtime;
	String Doctortime;
	String professionalstime1;
	String professionalstime2;	
	String Medicaltime;
	
		User(String Name,int PatientId,long MobileNumber,String Location,String Intime)
		{
			this.Name=Name;
			this.PatientId=PatientId;
			this.MobileNumber=MobileNumber;
			this.Location=Location;
			thid.Intime=Intime;
		}
}