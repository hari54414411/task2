class Hosptial
{
static Random random = new Random();

	public static void MedicalProfssional1()
	{
		User p=DataBase.WaitingPatient.poll();
		String time=p.Intime;
		p.professionalstime1=add(time,5);
		Hosptial.MedicalProfssional2(p);
		
	}

	public static void MedicalProfssional2(User p)
	{
		String time=p.professionalstime1;
		p.professionalstime2=add(time,5);
		Hosptial.Doctor(p);	
	}


	public static void Doctor(User p)
	{
		String time=p.professionalstime2;

		p.Doctortime=add(time,rondom);
	}

	public static String add(String timeStr, int addMinutes) 
	{
                String[] parts = timeStr.split(":");
        int hours = Integer.parseInt(parts[0]);
        int minutes = Integer.parseInt(parts[1]);

        
        int totalMinutes = hours * 60 + minutes + addMinutes;

        
        int newHours = totalMinutes / 60;
        int newMinutes = totalMinutes % 60;

        
        String newTime = String.format("%02d:%02d", newHours, newMinutes);

        return newTime;
    }


}