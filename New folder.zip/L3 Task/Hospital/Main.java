import java.util.*;
import java.time.LocalTime;  
class Main
{
static int PatientId=111;
public static void main(String[] args)
{
	System.out.println("-------------Hospital O.P.D Management Services-------------");
	boolean loop=true;
        Scanner sc=new Scanner(System.in);
		
	while(loop)
	{

		System.out.println("1.New Patient For Hospital\n2.Already Visited Hospital\n3.Exit");
		switch(option)
		{
			case 1:
			{
				System.out.println("Enter the Name:");
				String Name=sc.next();

				System.out.println("Enter the Mobile Number:");
				long MobileNumber=sc.nextLong();

				System.out.println("Enter the Your Location:");
				String location=sc.next();
			
				System.out.println("Enter the Intime:(Enter the time in HH:MM this formate)");
				String Intime=sc.next();
				 

				User user=new User(Name,PatientId++,MobileNumber,location,intime);
				DataBase.Details.put(PatientId,user);

				System.out.println("-----------Successfully PatientID Added-------------");

				DataBase.WaitingPatient.push(user);
				MedicalProfssional1();

			}
			break;

			case 2:
			{
				System.out.println("Enter the Name:");
				String Name=sc.next();

				System.out.println("Enter the PatientId:");
				int PatientId=sc.nextInt();
				
				System.out.println("Enter the Intime:(Enter the time in HH:MM this formate)");
				String Intime=sc.next();
		
				
				
				if(DataBase.Details.containsKey(PatientId))
				{

			       		User p=DataBase.Details.getKey(PatientId);
					DataBase.WaitingPatient.push(p);
					MedicalProfssional1();
				}	
				else
				{
					System.out.println("PatientId Not Vaild");

				}

			}
			break;

			case 3:
			{
				loop=false;		
			}
			break;


		}
	}
}
}