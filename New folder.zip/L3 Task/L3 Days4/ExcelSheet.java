import java.util.*;
class ExcelSheet
{
public static void main(String[] args)
{
Scanner s=new Scanner(System.in);
System.out.println("Enter the String:");
String s1=s.next();
int l=0;

for(char c:s1.toCharArray())
{
	l=(l*26)+(c-64);
}
System.out.println(l);



}
}