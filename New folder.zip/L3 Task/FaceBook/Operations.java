import java.util.*;
class Operations
{
    Users u;
    Scanner sc=new Scanner(System.in);
    Operations(Users u)
    {
        this.u=u;
    }



    public void addfriends()
    {

        System.out.println("Enter the friend userID to ADD------>");
        String userid=sc.next();
        if(DataBase.UserDetails.containsKey(userid)) {
            Users fd = DataBase.UserDetails.get(userid);
            u.friend.add(fd);
            fd.friend.add(u);
            System.out.println("---------Successfully Friend ADDED---------");
        }
        else {
            System.out.println("Enter the vaild user id");
        }
    }
    public void unfollow()
    {
        System.out.println("Enter the friend userID to remove------>");
        String userid=sc.next();
        if(DataBase.UserDetails.containsKey(userid)) {
            Users fd=DataBase.UserDetails.get(userid);
            u.friend.remove(fd);
            fd.friend.remove(u);
            System.out.println("---------Successfully removed---------");
        }
        else {
            System.out.println("Enter the vaild user id");
        }
    }

    public void createpost()
    {

    }

    public void Deletepost()

    {

    }

    public void newsfeed()
    {

    }


}