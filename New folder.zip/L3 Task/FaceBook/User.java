import java.util.*;
class User
{
    Scanner sc=new Scanner(System.in);


    public void newuser()
    {
        System.out.println("<------------Enter your name------------>");
        String name=sc.next();

        System.out.println("<------------Creat User ID------------>");
        String userID=sc.next();


        System.out.println("<------------Enter your MobileNumber------------>");
        long mobileNumber=sc.nextLong();

        System.out.println("<------------Creat password------------>");
        String password=sc.next();

        Users Details=new Users(name,userID,mobileNumber,password);
        DataBase.UserDetails.put(userID,Details);

        System.out.println("<------------Successfully Account Created------------>");


    }

    public void login()
    {
        System.out.println("<------------Enter the UserID to Login------------>");
        String userId=sc.next();

        System.out.println("<------------Enter Your Password------------>");
        String password=sc.next();

        Users user=DataBase.UserDetails.get(userId);
        boolean loop=true;
        Operations op=new Operations(user);

        if(user.password.equals(password))
        {
            while(loop)
            {
                System.out.println("1.ADD Friends\n2.Unfollow Friends\n3.Create Post\n4.Delete Post\n5.NewsFeed\n6.Exit");
                int option=sc.nextInt();

                switch(option)
                {
                    case 1:
                    {
                        op.addfriends();
                    }
                    break;

                    case 2:
                    {
                        op.unfollow();
                    }
                    break;

                    case 3:
                    {
                        op.createpost();
                    }
                    break;

                    case 4:
                    {
                        op.Deletepost();
                    }
                    break;

                    case 5:
                    {
                        op.newsfeed();
                    }
                    break;


                    case 6:
                    {
                        loop=false;
                    }
                    break;


                }
            }

        }
        else
        {
            System.out.println("Enter the Correct Password");

        }

    }






}