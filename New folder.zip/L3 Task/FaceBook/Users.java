import java.util.*;
class Users
{

    String name;
    String userID;
    long mobilenumber;
    String password;
    ArrayList<String> Post;
    static ArrayList<Users> friend;

    Users(String name,String userID,long mobenumber,String password)
    {
        this.name=name;
        this.userID=userID;
        this.mobilenumber=mobilenumber;
        this.password=password;
        this.Post=new ArrayList<>();
        this.friend=new ArrayList<Users>();

    }


    public void Setname()
    {
        this.name=name;
    }

    public String getname()
    {
        return name;
    }


    public void SetuserID(String userID)
    {
        this.userID=userID;
    }

    public String getUserID()
    {
        return userID;
    }

    public void Setmoblienumber()
    {
        this.mobilenumber=mobilenumber;
    }

    public long getmoblienumber()
    {
        return mobilenumber;
    }


    public void Setpassword()
    {
        this.password=password;
    }

    public String getpassword()
    {
        return password;
    }




}