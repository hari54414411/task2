import java.util.*;
class Main
{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        boolean loop=true;
        User u=new User();

        System.out.println();
        while(loop)
        {
            System.out.println("1.NewUser\n2.LogIn\n3.Exit");
            int option=sc.nextInt();

            switch(option)
            {
                case 1:
                {
                    System.out.println("-----Welcome New User To FaceBook-----");
                    u.newuser();
                }
                break;

                case 2:
                {
                    System.out.println("-----Welcome Login Page-----");
                    u.login();

                }
                break;

                case 3:
                {
                    loop=false;
                }
                break;


            }

        }
    }
}