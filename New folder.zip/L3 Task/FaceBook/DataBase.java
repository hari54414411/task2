import java.util.*;
class DataBase
{
	static Map<String,Users> UserDetails=new HashMap<>();
	
}