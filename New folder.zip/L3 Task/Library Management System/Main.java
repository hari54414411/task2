import java.util.*;
class Main
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("----------Library Management System----------");

		boolean loop=true;
		LogIN l=new LogIN();

		while(loop)
		{
			System.out.println("1.Login as admin\n2.Login as a member\n3.Exit");
			int option=sc.nextInt();
			switch(option)
			{
				case 1:
				{
					l.AdminLogin();
				}
				break;

				case 2:
				{
					l.MemberLogin();
				}
				break;

				case 3:
				{
					loop=false;
				}
				break;


			}
		}
	
	}
}