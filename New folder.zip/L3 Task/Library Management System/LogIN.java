import java.util.*;
class LogIN
{

	static Scanner sc=new Scanner(System.in);
	public static void AdminLogin()
	{
		System.out.println("--------------Welcome to AdminLogIn Page--------------");

		System.out.println("Enter the Admin UserName:");
		String adminuser=sc.next();

		System.out.println("Enter the Admin Password:");
		String password=sc.next();
		Admin a=new Admin();
		boolean loop=true;
		while(loop)
		{
	
		if(adminuser.equals("admin")&&password.equals("admin"))
		{
			System.out.println("1. Add a new book\n2. Remove an existing book\n3. View list of books\n4. Add a new user\n5. Remove an existing\n6. View list of users\n7. Exit");

			int option=sc.nextInt();
			switch(option)
			{
				case 1:
				{
					a.Addbook();
				}	
				break;
		
				case 2:
				{
					a.Existingbook();
				}	
				break;
				
				case 3:
				{
					a.list_of_books();
				}	
				break;
				
				case 4:
				{
					a.Add_new_User();
				}	
				break;

				case 5:
				{
					a.Remove_existing_user();
				}	
				break;
				
				case 6:
				{
					a.list_users();
				}	
				break;

				case 7:
				{

					loop=false;
				}
				break;

				
			}

			
		}
		else
		{
			System.out.println("Pls Enter correct username or password");
		}
	}
		
		
	}

		
	public static void MemberLogin()
	{
		System.out.println("--------------Welcome to MemberLogIn Page--------------");

		System.out.println("Enter your User Id:");
		int userid=sc.nextInt();

		System.out.println("Enter the Member UserName:");
		String adminuser=sc.next();

		System.out.println("Enter the Member Password:");
		String password=sc.next();

		boolean flag=true;

		UserDetails ud=new UserDetails();

		if(DataBase.user.containsKey(userid))
		{
			while(flag)
			{
				System.out.println("1. Search for a book\n2. Issue a book by providing the book unique Id\n3. Return a book\n4. Exit");
				int op=sc.nextInt();
				switch(op)
				{
					case 1:
					{
						ud.SearchBook();
					}
					break;
				
					case 2:
					{
						ud.Issuebook(userid);
					}
					break;

					case 3:
					{
						ud.ReturnBook();
					}
					break;

					case 4:
					{
						flag=false;
					}
					break;
			}	
		}	
			
		}	
		else
		{
			System.out.println("User with ID " + userid + " not found");
		}
	

	}



	
}