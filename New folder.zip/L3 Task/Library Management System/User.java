import java.util.*;
class User
{

	int Memberid;
	String Username;
	String password;
	int Age;
	String Gender;
	String joiningdate;
	ArrayList<Book> listBook;
	User(int Memberid,String Username,String password,int Age,String Gender,String joiningdate)
	{
		this.Memberid=Memberid;
		this.Username=Username;
		this.password=password;
		this.Age=Age;
		this.Gender=Gender;	
		this.joiningdate=joiningdate;
		listBook=new ArrayList<>();
	}

	public String toString()
	{
		return "UserID: "+Memberid+"\n"+"UserName: "+Username+"\n"+"UserPassword: "+password+"\n"+"UserAge: "+Age+"\n"+"Gender: "+Gender+"\n"+"joiningdate: "+joiningdate;
	}


}