import java.util.*;
class Book
{

 	int BookId;
	String Title;
	String Description;	
	String AuthorDetails;
	String PublicationDate;
	String Edition;
	double price;
	int count;
	ArrayList<User> listUser;

	Book(int BookId,String Title,String Description,String AuthorDetails,String PublicationDate,String Edition,double price,int count)
	{
		this.BookId=BookId;
		this.Title=Title;
		this.Description=Description;
		this.PublicationDate=PublicationDate;
		this.Edition=Edition;
		this.price=price;
		this.count=count;
		listUser=new ArrayList<>();
		
	}

	public String toString()
	{
		return "BookId: "+BookId+"\n"+"BookName: "+Title+"\n"+"Description: "+Description+"\n"+"PublicationDate: "+PublicationDate+"\n"+"Edition"+Edition+"\n"+"Price: "+price+"count: "+count;
	}

}