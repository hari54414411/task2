import java.util.*;
class UserDetails
{

	Scanner sc=new Scanner(System.in);

	public void SearchBook()
	{
		System.out.println("Enter the Book Id:");
		int bookId=sc.nextInt();
		
		if(DataBase.book.containsKey(bookId))
		{
			System.out.println(DataBase.book.get(bookId));
		}
		else
		{
			System.out.println("The book is NOT available in the library");
		}
	}


	public void Issuebook(int userid)
	{

		System.out.println("Enter the Book Id:");
		int bookId=sc.nextInt();
		
		if(DataBase.book.containsKey(bookId))
		{
		
			int c=DataBase.book.get(bookId).count;
			if(c>0)
			{
				Book b=DataBase.book.get(bookId);
				User u=DataBase.user.get(userid);
				b.count--;
				u.listBook.add(b);
				b.listUser.add(u);
			System.out.println("-------Successfully book taken-------");
				
				
			}
			else
			{
				System.out.println("Currently No Books");
			}
			
		}
		else
		{
			System.out.println("The book is NOT available in the library");
		}
		
	}

	public void ReturnBook()
	{
		
	}


	

}