import java.util.*;
class Admin
{


	Scanner sc=new Scanner(System.in);
	int Bookid=1;
	int userId=1;
	public void Addbook()
	{
		
		System.out.println("--------Adding Book--------");	
		
		System.out.println("Enter the BookTitle");
		String Booktitle=sc.next();
			
		System.out.println("Enter the Book Description");
		String BookDescription=sc.next();

		System.out.println("Enter the Author Details:");
		String Authordetails=sc.next();

		System.out.println("Enter the Book Publication date");
		String PublicationDate=sc.next();

		System.out.println("Enter the Book Edition:");
		String Edition=sc.next();

		System.out.println("Enter the Book Price");
		double Bookprice=sc.nextDouble();

		System.out.println("Enter the Book Count");
		int BookCount=sc.nextInt();

		

		Book b=new Book(Bookid,Booktitle,BookDescription,Authordetails,PublicationDate,Edition,Bookprice,BookCount);
		DataBase.book.put(Bookid++,b);

		System.out.println("------------Successfully Book Added------------");
		
	}

	public void Existingbook()
	{
		System.out.println("Enter the Book ID");
		int bookID=sc.nextInt();

	if (DataBase.book.containsKey(bookID)) 
	{
       
       		 DataBase.book.remove(bookID);
       		 System.out.println("-----------Book Successfully Removed-----------");
    	} 
	else 
	{
        	System.out.println("Book with ID " + bookID + " not found");
        }

	}


	public void list_of_books()
	{

	System.out.println("------------List Of Bookes------------");

	
       		for(int i=1;i<Bookid;i++)
		{
			if (DataBase.book.containsKey(i)) 
			{
				System.out.println(DataBase.book.get(i));
				System.out.println("---------------------------");


			}
		
		}
     	}

	public void Add_new_User()
	{

		System.out.println("Enter the Username");
		String username=sc.next();
			
		System.out.println("Enter the User password");
		String userpassword=sc.next();

		System.out.println("Enter the User Age:");
		int userage=sc.nextInt();

		System.out.println("Enter the User Gender");
		String usergender=sc.next();

		System.out.println("Enter the User Joining Date:");
		String JD=sc.next();
		

		User u=new User(userId,username,userpassword,userage,usergender,JD);
		DataBase.user.put(userId++,u);

		System.out.println("------------Successfully User Added------------");
	}

	public void Remove_existing_user()
	{
		System.out.println("Enter the User ID");
		int ID=sc.nextInt();

	if (DataBase.user.containsKey(ID)) 
	{
       
       		 DataBase.user.remove(ID);
       		 System.out.println("-----------User Successfully Removed-----------");
    	} 
	else 
	{
        	System.out.println("User with ID " + ID + " not found");
        }


	}

	public void list_users()
	{
		System.out.println("------------List Of Users------------");

	
       		for(int i=1;i<userId;i++)
		{
			if (DataBase.user.containsKey(i)) 
			{
				System.out.println(DataBase.user.get(i));
				System.out.println("---------------------------");


			}
		
		}

	}

	
}