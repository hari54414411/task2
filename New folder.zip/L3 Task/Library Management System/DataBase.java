import java.util.*;
class DataBase
{
	static Map<Integer,Book> book=new HashMap<>();
	static Map<Integer,User> user=new HashMap<>();	

}