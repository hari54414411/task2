import java.util.*;
class User
{
public static void main(String[] args)
{
Scanner s=new Scanner(System.in);
System.out.println("Enter the name:");
String name=s.next();

System.out.println("Enter the Mobile Number:");
long mobilenumber=s.nextLong();

System.out.println("Enter the Your Address:");
String address=s.next();



int quantity;
int menu;
boolean loop=true;
 List<Order> orders = new ArrayList<>();

while(loop)
{
System.out.println("Enter the choice \n1.order food\n2.Exit");
int choice=s.nextInt();


switch(choice)
{
case 1:
{
System.out.println("Menu:\n1.Dose\n2.Idly\n3.kalDosa\n4.Chapathi\n5.Parota");
System.out.println("Enter the food choice:");
menu=s.nextInt();

String[] menuItems = {"Dose", "Idly", "kalDosa", "Chapathi", "Parota"};

System.out.println("Enter the quantity of food:");
quantity=s.nextInt();
Order order = new Order(name, mobilenumber, address, menuItems[menu - 1], quantity);

orders.add(order);
Restaurants restaurant = new Restaurants(orders);
restaurant.Orderfoodtorestaurants();


}
break;
case 2:
{
loop=false;
}
break;
}
}




}
}
