class Order
{
		
	 String name;
	 long number;
	 String address;
	 String foodname;
	 int quantity;

        
	
	public Order(String name,long number,String address,String foodname,int quantity)
	{
	this.name=name;
	this.number=number;
	this.address=address;
        this.foodname=foodname;
        this.quantity=quantity;
       
	}

		 

}
