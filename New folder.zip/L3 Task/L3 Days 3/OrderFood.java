class OrderFood
{
	String foodname;
	int quantity;
	OrderFood(String foodname,int quantity)
	{
		this.foodname=foodname;
		this.quantity=quantity;
	}
}