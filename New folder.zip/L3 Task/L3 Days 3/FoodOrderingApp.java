import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

// Abstract class for food item
abstract class FoodItem {
    String name;
    double price;

    abstract void prepare();
}

// Concrete food items
class Pizza extends FoodItem {
    @Override
    void prepare() {
        System.out.println("Preparing pizza: " + name);
    }
}

class Burger extends FoodItem {
    @Override
    void prepare() {
        System.out.println("Preparing burger: " + name);
    }
}

// Restaurant class
class Restaurant {
    String name;
    Map<String, FoodItem> menu;

    public Restaurant(String name) {
        this.name = name;
        menu = new HashMap<>();
    }

    void addToMenu(String itemName, FoodItem item) {
        menu.put(itemName, item);
    }

    FoodItem getItemFromMenu(String itemName) {
        return menu.get(itemName);
    }
}

// User class
class User {
    String name;
    String email;
    String phoneNumber;
    List<FoodItem> cart;

    public User(String name, String email, String phoneNumber) {
        this.name = name;
        this.email = email;
        this.phoneNumber = phoneNumber;
        cart = new ArrayList<>();
    }

    void addToCart(FoodItem item) {
        cart.add(item);
    }

    void removeFromCart(FoodItem item) {
        cart.remove(item);
    }

    void viewCart() {
        System.out.println("Items in cart for " + name + ":");
        for (FoodItem item : cart) {
            System.out.println(item.name + " - $" + item.price);
        }
    }
}

// Order class
class Order {
    static int orderIdCounter = 1;
    int orderId;
    User user;
    List<FoodItem> items;

    public Order(User user, List<FoodItem> items) {
        this.orderId = orderIdCounter++;
        this.user = user;
        this.items = items;
    }

    void displayOrderDetails() {
        System.out.println("Order ID: " + orderId);
        System.out.println("User: " + user.name);
        System.out.println("Items:");
        for (FoodItem item : items) {
            System.out.println(item.name + " - $" + item.price);
        }
    }
}

// Main application class
public class FoodOrderingApp {
    Map<User, List<Order>> orderHistory;
    List<Restaurant> restaurants;

    public FoodOrderingApp() {
        orderHistory = new ConcurrentHashMap<>();
        restaurants = new ArrayList<>();
    }

    void addRestaurant(Restaurant restaurant) {
        restaurants.add(restaurant);
    }

    void placeOrder(User user, Restaurant restaurant, List<String> itemNames) {
        List<FoodItem> items = new ArrayList<>();
        for (String itemName : itemNames) {
            FoodItem item = restaurant.getItemFromMenu(itemName);
            if (item != null) {
                items.add(item);
            } else {
                System.out.println("Item " + itemName + " not found in the menu of " + restaurant.name);
            }
        }
        if (!items.isEmpty()) {
            Order order = new Order(user, items);
            orderHistory.computeIfAbsent(user, k -> new ArrayList<>()).add(order);
            order.displayOrderDetails();
        }
    }

    public static void main(String[] args) {
        FoodOrderingApp app = new FoodOrderingApp();

        // Create restaurants
        Restaurant restaurant1 = new Restaurant("Restaurant 1");
        restaurant1.addToMenu("Pizza", new Pizza());
        restaurant1.addToMenu("Burger", new Burger());
        app.addRestaurant(restaurant1);

        // Create users
        User user1 = new User("User 1", "user1@example.com", "1234567890");

        // Place orders
        app.placeOrder(user1, restaurant1, Arrays.asList("Pizza", "Burger"));
    }
}
