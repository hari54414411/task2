interface CustomerDetails{
abstract String getDetails();
}

\\Cutomer Class
class customer implements CustomerDetails{
	private String ph_no;
	private String name;
	private String location;
		customer(String ph_no,String name,String location){
			this.ph_no=ph_no;
			this.name=name;
			this.location=location;
		}
	public String getDetails(){
		return "Phone Number :"+ph_no+" Name :"+" Location :"+location;
	}
	public String getph_no(){
			return ph_no;
		}

		
}

\\Delivery Partner

class DeliveryPartner{
	static int Did=1;
	private int id;
	private String ph_no;
	private String name;
	DeliveryPartner(String ph_no,String name){
	this.ph_no=ph_no;
	this.name=name;
	id=Did++;
	}
}

\\Restaurant
class Restaurant{
		static int billId;
		private int bill;
		private String hotelName;
		private HashMap<String,Double> food=new HashMap();
		Restaurant(String hotelName){
			this.hotelName=Name;
			}
		public void setFood(HashMap a){
			this.food=a;
		}
		public HashMap getFood(){
			return food;
		}
		public String getName(){
			return hotelName;
		}		
}

\\DataBase
class dataBase{
		HashMap<String,customer>cust=new HashMap();
		HashMap<Integer,Restaurant>rest=new HashMap();
	}

\\MainClass
class Food{
		static int re=1;
		static dataBase dB=new dataBase();
		static Scanner s=new Scanner(System.in);
		public static void main(String [] args){
		System.out.println("Enter the Number of restaurant");
		int no=s.nextInt();
		for(int i=0;i<no;i++){
	Map<String,Integer> m = new HashMap<>();
			m.put("dosa",50);
			m.put("idly",20);
			m.put("poori",60);
		System.out.println("ENter you hotel name");
		String name=s.next();
		Restaurant r=new Restaurant(name);
		r.setFood(m);
		dB.rest.put(re++,r);
			}
			boolean b=true;
			while(b){
			System.out.println("\t\t\t\n1.Restaurants\t\t\t\n2.Customer\t\t\t\n3.Exit")
			int inp=s.nextInt();
			switch(inp){
				case 1:restaurant(); break;
				case 2:customer();break;
				case 3:b=false;
				default :System.out.println("ENter the valid");
			}
			}
		}
		public static void customer(){
		boolean b=true;
		while(b){
			System.out.println("\t\t\t\n1.Sign up\t\t\t\n2.Login\t\t\t\n3.Exit")
			int inp=s.nextInt();
			switch(inp){
				case 1:{
						System.out.println("Enter Mobile Number")
						String ph_no=s.next();
						if(Pattern.matches("^[6-9]\\d{9}$",ph_no)){
						System.out.println("Enter your Name")
						String name=s.next();
						System.out.println("Enter your Location")
						String location=s.next();
						}
						else{
							System.out.println("Enter the valid one");
							break;
						}
					customer c-new customer(ph_no,name,location);
 dB.cust.put(c.getPh_no(),c);
						break;
					}
				case 2:{
					System.out.println("Enter Mobile Number")
						String ph_no=s.next();
						if(Pattern.matches("^[6-9]\\d{9}$",ph_no) && db.cust.containsKey(ph_no)){
							order();
					}
				}
				case 3:b=false;
				default :System.out.println("ENter the valid");
			}
			}

		}
			public static void order(){
				int i=1;
 for (Map.Entry<String, Integer> entry : dB.rest.entrySet) {
            System.out.println((i++)+" "+entry.getValue().getName());
        }
 System.out.println(("Pick YOur Hotel");
			int pick=s.nextInt();
		if(dB.rest.containsKey(pick)){
		HashMap<String,Double>m=db.rest.get(pick).getFood();
 for (Map.Entry<String, Double> entry : m.entrySet) {
            System.out.println(("Dish "+entry.getKey()+" value "+entry.getValue());
        }
		String dish=s.next();
		if(m.containsKey(dish)){}

			}
			}
	}
Actions
