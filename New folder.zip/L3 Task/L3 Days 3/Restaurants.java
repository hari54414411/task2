import java.util.*;
class Restaurants {
    private List<Order> orders;

    public Restaurants(List<Order> orders) {
        this.orders = orders;
    }

    public void Orderfoodtorestaurants() {
        
        System.out.println("Order received by the restaurant!");
        for (Order order : orders) {
            System.out.println("Order details:");
            System.out.println("Name: " + order.name);
            System.out.println("Mobile Number: " + order.number);
            System.out.println("Address: " + order.address);
            System.out.println("Food: " + order.foodname);
            System.out.println("Quantity: " + order.quantity);
            System.out.println("-------------------------------");
            
}
DeliveryBoy.assignDelivery(orders);
    }
}
class DeliveryBoy {
    public static void assignDelivery(List<Order> orders) {
        System.out.println("Assigning delivery to a delivery boy...");
        for (Order order : orders) {
            System.out.println("Delivery assigned for order by " + order.name);
        }
        System.out.println("Delivery completed successfully!");
    }
}