class Cancel
{
    public void cancelTicket(int passengerId)
    {
       
        PassengerDetails p =Availability.passengers.get(passengerId);
        Availability.book.remove(Integer.valueOf(passengerId));

        int positionBooked = p.number;

        System.out.println("---------------cancelled Successfully");
        if(p.alloted.equals("Normal")) 
        { 
          Availability.AvailableNormalSets++;
          Availability.availablenormalsets.add(positionBooked);
        }
        else if(p.alloted.equals("SL"))
        { 
          Availability.AvailablSLSets++;
          Availability.availableslsets.add(positionBooked);
        }
        else if(p.alloted.equals("AC"))
        { 
          Availability.AvailableAcSets++;
          Availability.availableacsets.add(positionBooked);
        }
}
}