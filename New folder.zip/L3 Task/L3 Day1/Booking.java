import java.util.*;
class Booking
{
public static void BookTicket(PassengerDetails p)
{

if((Availability.AvailableNormalSets==0&&Availability.AvailablSLSets==0)||Availability.AvailableAcSets==0)
{
System.out.println("No Tickects Available in train");
return;
}
if((Availability.AvailableNormalSets>0||Availability.AvailablSLSets>0)||Availability.AvailableAcSets>0)
{
System.out.println("Tickets are Available:");
if(p.BP.equals("NormalSeating"))
{
System.out.println("Normal Berth Given");
Availability.book(p,(Availability.availablenormalsets.get(0)),"NormalSeating");
Availability.availablenormalsets.remove(0);
Availability.AvailableNormalSets--;
}
else if(p.BP.equals("SL"))
{
System.out.println("SL Berth Given");
Availability.book(p,(Availability.availableslsets.get(0)),"SL");
Availability.availableslsets.remove(0);
Availability.AvailablSLSets--;
}
else if(p.BP.equals("AC"))
{
System.out.println("AC Berth Given");
Availability.book(p,(Availability.availableacsets.get(0)),"AC");
Availability.availableacsets.remove(0);
Availability.AvailableAcSets--;
}
if(Availability.AvailableNormalSets>0)
{
System.out.println("Normal Berth Given");
Availability.book(p,(Availability.availablenormalsets.get(0)),"NormalSeating");
Availability.availablenormalsets.remove(0);
Availability.AvailableNormalSets--;

}
else if(Availability.AvailablSLSets>0)
{
System.out.println("SL Berth Given");
Availability.book(p,(Availability.availableslsets.get(0)),"SL");
Availability.availableslsets.remove(0);
Availability.AvailablSLSets--;
}
else if(Availability.AvailableAcSets>0)
{
System.out.println("AC Berth Given");
Availability.book(p,(Availability.availableacsets.get(0)),"AC");
Availability.availableacsets.remove(0);
Availability.AvailableAcSets--;

}
}
}
}