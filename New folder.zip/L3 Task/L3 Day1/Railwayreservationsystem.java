import java.util.*;
class Railwayreservationsystem
{

public static void main(String[] args)
{
boolean loop=true;
while(loop)
{
System.out.println("1. Booking\n2. Availability checking\n3. Cancellation\n4. Prepare chart\n5. Exit");
Scanner s=new Scanner(System.in);

int choice=s.nextInt();

switch(choice)
{

case 1:
{
System.out.println("Enter the passenger Details,:");
System.out.println("Enter the passenger Name:");
String Name=s.next();
System.out.println("Enter the passenger Age:");
int Age=s.nextInt();
System.out.println("Enter the pessenger berth perference(Normal/SL/AC)");
String BP=s.next();
Booking b=new Booking();
PassengerDetails p=new PassengerDetails(Name,Age,BP);
b.BookTicket(p);
break;
}
case 2:
{

Availability ab=new Availability();
ab.availability();
break;

}
case 3:
{
Cancel c=new Cancel();
System.out.println("enter the passengerID:");
int id=s.nextInt();
if(!Availability.passengers.containsKey(id))
{
System.out.println("Passenger detail Unknown");
}
else
{
c.cancelTicket(id);
}
break;
}
case 4:
{
Availability pd=new Availability();
pd.Preparechart();
break;
}
case 5:
{
loop=false;
}

}
}
}
}