import java.util.*;
class Availability
{
public static int AvailableNormalSets=10;
public static int AvailablSLSets=10;
public static int AvailableAcSets=10;

static List<Integer> availablenormalsets=new ArrayList<>(Arrays.asList(1,2,3,4,5,6,7,8,9,10));
static List<Integer> availableslsets=new ArrayList<>(Arrays.asList(1,2,3,4,5,6,7,8,9,10));
static List<Integer> availableacsets=new ArrayList<>(Arrays.asList(1,2,3,4,5,6,7,8,9,10));

static Map<Integer, PassengerDetails> passengers = new HashMap<>();
static ArrayList<Integer> book=new ArrayList<Integer>();

public static void availability()
{
System.out.println("AvailabilityNormalTickets:"+AvailableNormalSets);
System.out.println("AvailabilitySLTickets    :"+AvailablSLSets);
System.out.println("AvailabilityACTickets    :"+AvailablSLSets);
}



public static void book(PassengerDetails p, int berthInfo,String allotedBerth)
    {
        p.number = berthInfo;
        p.alloted = allotedBerth;
        passengers.put(p.passengerId,p);
        book.add(p.passengerId);  
        System.out.println("--------------------------Booked Successfully");
    }


    public static void Preparechart()
    {
        if(passengers.size() == 0)
        {
            System.out.println("No details of passengers");
            return;
        }
        for(PassengerDetails p1 : passengers.values())
        {
            System.out.println("PASSENGER ID " + p1.passengerId );
            System.out.println(" Name " + p1.Name );
            System.out.println(" Age " + p1.Age );
            System.out.println(" Status " + p1.number + p1.alloted);
            System.out.println("--------------------------");
        }
    }



}