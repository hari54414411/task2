class PassengerDetails
{
String Name;
int Age;
String BP;
static int id=1;
int passengerId;
String alloted;
int number;
PassengerDetails(String Name,int Age,String BP)
{
this.Name=Name;
this.Age=Age;
this.BP=BP;
this.passengerId=id++;
alloted="";
number=-1;
}
}