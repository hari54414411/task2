import java.util.*;
import java.time.LocalDate;

class Functions
{

	public static void Search(String name)
	{
	
	if(Database.map.containsKey(name))
	{
	System.out.println("Your Enter the Correct Contact Number");
System.out.println("--------Contact Successfully Search--------");
	Call(name);
	

	}
	else
	{
	System.out.println("Your Enter the Invaild Phone number");
	}
	}


	public static void Call(String name) {
    CallFunctions c;
    LocalDate startTime = LocalDate.now();
    if (Database.map.containsKey(name)) {
        c = Database.map.get(name);
        if (c != null) {
            System.out.println(c.name + "\n" + c.phonenumber);
            System.out.println("--------Contact Successfully Calling--------");

            c.startCall();
            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            c.endCall();
            c.time.add(startTime.toString());
        } else {
            System.out.println("Contact details not found.");
        }
    } else {
        System.out.println("Contact not found in the database.");
    }
}

	public static void Delete(String name)	
	{
	if(Database.map.containsKey(name))
	{
	Scanner scan=new Scanner(System.in);

	System.out.println("Your Enter the Vaild name");
	System.out.println("Give OK for Delete Contact");
	String delete=scan.next();
	if(delete.equals("ok"))
	{
	Database.map.remove(name);
	System.out.println("--------Successfully Contact Deleted--------");
	}
	}
	else
	{
	System.out.println("Please Enter the Vaild Contact Number");
	}
	}

	public static void update(String name, long newPhoneNumber) {
    if(Database.map.containsKey(name)) {
        CallFunctions contact = Database.map.get(name);
        contact.setPhoneNumber(newPhoneNumber);
        Database.map.put(name, contact);
        System.out.println("Contact number updated successfully for " + name);
    } else {
        System.out.println("Contact " + name + " not found.");
System.out.println("--------Successfully Contact Update--------");
    }
}
}

