import java.util.*;
class Database
{
	static Map<String,CallFunctions> map=new HashMap<>();
}