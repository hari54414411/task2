import java.util.*;
class ContactManagement
{
public static void main(String[] args)
{
Scanner s=new Scanner(System.in);

boolean loop=true;
while(loop)
{
System.out.println("Enter The Option:");
System.out.println("1.AddContact\n2.Call\n3.Search Contact\n4.Delete Contact\n5.Update Contact\n6.Exit");
int option=s.nextInt();
Functions f=new Functions();

switch(option)
{
case 1:
{
	System.out.println("Enter the Person Name:");
	String name=s.next();

	System.out.println("Enter the Person Number:");
	long phonenumber=s.nextLong();

	System.out.println("Enter the Person CompanyName:");
	String companyname=s.next();

	CallFunctions c=new CallFunctions(name,phonenumber,companyname);
	Database.map.put(name,c);
        System.out.println("--------Contact Successfully ADD--------");


}
break;
case 2:
{

System.out.println("Enter the phonenumber:");
String name=s.next();
f.Call(name);

}
break;

case 3:
{

System.out.println("Enter the Search ContactPersonName:");
String search=s.next();
f.Search(search);

}
break;

case 4:
{
System.out.println("Enter the name to Delete Contact:");
String name=s.next();
f.Delete(name);

}
break;

case 5:
{
System.out.println("Enter the Name for Update:");
String name=s.next();
System.out.println("Enter the update number:");
int number=s.nextInt();
f.update(name,number);

}
break;

case 6:
{
loop=false;
}
break;
}
}



}
}