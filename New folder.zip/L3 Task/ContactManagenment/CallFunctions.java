import java.util.*;
import java.time.LocalDate;
class CallFunctions
{
	Long phonenumber;
        String name;
	String companyname;
	ArrayList<String> time;
	LocalDate startTime;
        LocalDate endTime; 
        long phoneNumber; 
	public CallFunctions(String name,Long phonenumber,String companyname)
	{
	this.name=name;
	this.phonenumber=phonenumber;
	this.companyname=companyname;
        this.time=new ArrayList<>();
	}

     public void startCall() {
        startTime = LocalDate.now();
    }

    public void endCall() {
        endTime = LocalDate.now();
    }
public void setPhoneNumber(long phoneNumber) {
    this.phoneNumber = phoneNumber;
}

	
}