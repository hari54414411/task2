class UserDetails
{
String name;
String mail;
long number;
int ID;
String password;
boolean approve;
boolean rejected;
int ZID;

	UserDetails(String name,String mail,long number,int ID,String password)
	{	
	this.name=name;
	this.mail=mail;
	this.number=number;
	this.ID=ID;
	this.password=password;

	}
}
