import java.util.*;
class User
{
       	
	public static void Register()
	{
       Scanner scan=new Scanner(System.in);
	PasswordValidator p=new PasswordValidator();

	System.out.println("Enter the Name");
	String name=scan.next();

	System.out.println("Enter the mailId ");
 	String mail=scan.next();

	System.out.println("Enter the mobile");
	long mobilenumber=scan.nextLong();

	System.out.println("Enter H_ID(It is a unique ID, given to humans by the government)");
	int ID=scan.nextInt();

	System.out.println("Enter the password(condition of password must 4 letter& 4 Number& one special Character ):");
	String password=scan.next();
	
	//if (p.isValidPassword(password)) {

            System.out.println("Password is valid.");
            UserDetails UD=new UserDetails(name,mail,mobilenumber,ID,password);
		DataBase.map1.put(ID,UD);
		DataBase.q.add(UD);
		

     //   } 
	
	}

	public static void login()
	{
	Scanner scan=new Scanner(System.in);
	PasswordValidator p=new PasswordValidator();
		
	System.out.println("Enter the mail to login:");
 	String mail=scan.next();
	
	System.out.println("Enter the password:");
	String password=scan.next();

	if (p.isValidPassword(password)) 
	{

            System.out.println("Password is valid.");
            
        } 
	else 
	{
            System.out.println("Password is invalid.");
        }

	}


	public static void Applicationstatus(int id)
	{
	
	if(DataBase.map1.get(id).approve)
	{
	System.out.println("Your Application has Approved");
	
	System.out.println("Admit Generate Login Id:"+DataBase.map1.get(id).ZID);
	}
	
	else if(DataBase.map1.get(id).rejected)
	{
	System.out.println("Your Application has be Rejected");
	}
	else
	{
	System.out.println("Your Application is Witing for Apporval");
	}
	}


}