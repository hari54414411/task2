import java.util.*;
class DataBase
{
static Map<Integer,UserDetails> map1=new HashMap<>();
static Queue<UserDetails> q=new LinkedList<>();

static Map<Integer,UserDetails> map2=new HashMap<>();


}