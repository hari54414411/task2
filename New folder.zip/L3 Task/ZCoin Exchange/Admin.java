import java.util.*;
class Admin
{

static int id=1;
public static void AdminLogin()
{
boolean loop=true;
System.out.println("-------Admin Login Page--------");
Scanner sc=new Scanner(System.in);
while(loop)
{
System.out.println("1.Show new Application \n2.Transactions\n3.Exit");
int option=sc.nextInt();

	switch(option)
	{
		case 1:
		{
		shownewApplication();
		}
		break;
		case 2:
		{
		Transactions();
		}
		break;
		case 3:
		{
		loop=false;
		}
		break;
	}
}

}

public static void shownewApplication()
{
Scanner s=new Scanner(System.in);
UserDetails u=DataBase.q.poll();
System.out.println("-------------Waiting Applications-------------");


	System.out.println("Name:"+u.name);
	System.out.println("Mail:"+u.mail);
	System.out.println("Mobilenumber:"+u.number);
        System.out.println("ID:"+u.ID);

System.out.println("1.Approve\n2.Reject");
int num=s.nextInt();
if(num==1)
{

u.approve=true;
u.ZID=id++;
DataBase.map2.put(u.ZID,u);

}
else if(num==2)
{
u.rejected=true;
}
}

public static void Transactions()
{


}




	
}