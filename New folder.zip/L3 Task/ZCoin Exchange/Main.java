import java.util.*;

class Main
{
public static void main(String[] args)
{
System.out.println("---------ZCoin Exchange---------");
	Scanner s=new Scanner(System.in);
        boolean loop=true;
        User user=new User();
	Admin a=new Admin();
	while(loop)
	{
		System.out.println("1.Register\n2.LogIn\n3.Admin Login \n4.Application status \n5.Exit");
		int choice=s.nextInt();

		switch(choice)
		{
			case 1:
			{
		        user.Register();
			}
			break;

			case 2:
			{	
			user.login();
			}
			break;
			
			case 3:
			{
			a.AdminLogin();
			}
                        break;

			case 4:
			{
			System.out.println("Enter the Your ID:" );
			int id=s.nextInt();
			user.Applicationstatus(id);
			}
			break;

			case 5:
			{
			loop=false;
			}
                        break;
		}
	
	}
				

}
}