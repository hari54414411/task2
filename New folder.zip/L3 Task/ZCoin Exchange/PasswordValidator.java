import java.util.regex.Matcher;
import java.util.regex.Pattern;

class PasswordValidator {

        public static boolean isValidPassword(String password) {
        String letterRegex = "[a-zA-Z]{4}";
        String numberRegex = "\\d{4}";
        String specialCharRegex = "[!@#$%^&*()-_+=<>?]";

     
        Pattern pattern = Pattern.compile(letterRegex);
        Matcher matcher = pattern.matcher(password);
        boolean hasFourLetters = matcher.find();

        pattern = Pattern.compile(numberRegex);
        matcher = pattern.matcher(password);
        boolean hasFourNumbers = matcher.find();

        pattern = Pattern.compile(specialCharRegex);
        matcher = pattern.matcher(password);
        boolean hasSpecialChar = matcher.find();

        return hasFourLetters && hasFourNumbers && hasSpecialChar;
    }
}
