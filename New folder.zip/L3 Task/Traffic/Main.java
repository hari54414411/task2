class TrafficSignal implements Runnable {
         static final int Redtiming=5000;
	 static final int Yellowtiming=2000;
	 static final int Greentiming=5000;
         static String CurrentSignal="Red";



	public void run()
	{	
		while(true)
		{
			try{
			switch(CurrentSignal)
			{
				case "Red":
				{
					System.out.println("Red Light");
					Thread.sleep(Redtiming);
					CurrentSignal="Yellow";
				}
				break;
				
				case "Yellow":
				{
					System.out.println("Yellow Light");
					Thread.sleep(Yellowtiming);
					CurrentSignal="Green";
				}
				break;

				case "Green":
				{
					System.out.println("Green Light");
					Thread.sleep(Greentiming);
					CurrentSignal="Green";
				}
				break;


			}
			} catch (InterruptedException e) {
                    e.printStackTrace();
                }
		}
	
	}
}


class Main
{
public static void main(String[] args)
{
  Thread t = new Thread(new TrafficSignal());
  t.start();
}
}