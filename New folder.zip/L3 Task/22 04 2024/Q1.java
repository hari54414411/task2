class Q1 {
    public static boolean validUtf8(int[] data) {
        int rem=0;
        for(int i:data){
            if(rem==0){
                if(i>>7==0b0)
                    rem=0;
                else if(i>>5==0b0110)
                    rem=1;
                else if(i>>4==0b01110)
                    rem=2;
                else if(i>>3==0b011110)
                    rem=3;
                else return false;
            }
            else{
                if(i>>6==0b10)rem--;
                else return false;
            }
        }
        return rem==0;
    }

	public static void main(String[] args)
	{
		int arr[]={197,130,1};
		System.out.println(validUtf8(arr));
	}
}
