import java.util.*; 
class Q2
{

	public static int[][] method(int arr[][],int k)
	{
		Map<Integer[],Double> map=new HashMap<>();
		for(int i=0;i<arr.length;i++)
		{
			int p1=arr[i][0];
			int p2=arr[0][i];
			double dis=Math.sqrt((p1*p1)+(p2*p2));
			Integer a[]=new Integer[]{p1,p2};
			map.put(a,dis);
		}

PriorityQueue<Integer[]> q=new PriorityQueue<>((a,b)->(map.get(a)==map.get(b)) 
                                                                ? Integer.compare(a[0],b[0]) 
                                                                : map.get(a)-map.get(b));	
	q.addAll(map.keySet());
	int ans[][]=new int[k][2];
	for(int i=0;i<k && !q.isEmpty();i++)
	{
		Integer[] tem=q.poll();
		ans[i][0]=tem[0];
		ans[0][i]=tem[1];
	}

	return ans;
				
	}

	public static void main(String[] args)
	{
		int arr[][]={{1,3},{-2,2}};
		int k=1;
		int ans[][]=method(arr,k);
		for(int num[]:ans)
		{
			System.out.println(Arrays.toString(num));
		}
		
		
	}
}