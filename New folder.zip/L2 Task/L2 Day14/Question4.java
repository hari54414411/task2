class Question4
{
public static void main(String[] args)
{
int n=7;
int mid=n/2;
for(int i=0;i<7;i++)
{
	for(int j=0;j<7;j++)
	{
		if(i+j>=3)
		{
			System.out.print();
		}
		else
		{
			System.out.print(" ");
		}
	}
System.out.println();
}


}
}