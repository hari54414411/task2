class Question9
{
public static void main(String[] args)
{
int n=12;
char c='A';
int mid=n/2;
for(int i=0;i<n;i++)
{
        c='A';
	for(int j=0;j<=mid;j++)
	{
		if(j<=mid-i-1)
		{
			System.out.print(c++ +"  ");
		}
	}
System.out.println();
}

}
}