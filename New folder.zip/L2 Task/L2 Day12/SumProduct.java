import java.util.*;
class SumProduct
{
public static int[] method(int arr[])
{
int result[]=new int[arr.length];
result[0]=1;
int product=1;

	for(int i=1;i<arr.length;i++)
	{
		result[i]=result[i-1]*arr[i-1];
	}
	
	for(int i=arr.length-1;i>=0;i--)
	{
		result[i]*=product;
		 product*=arr[i];
	}
return result;

}
public static void main(String[] args)
{
	int arr[]={5, 3, 4, 2, 6, 8};
	System.out.println(Arrays.toString(method(arr)));

}
}