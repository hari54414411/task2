public class NumberToWords {

    public static final String[] units = {"", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"};
    public static final String[] teens = {"Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen",
                                            "Seventeen", "Eighteen", "Nineteen"};
    public static final String[] tens = {"", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"};
    public static final String[] thousands = {"", "Thousand", "Million", "Billion"};

    public static String convertToWords(long num) {
        if (num == 0) {
            return "Zero";
        }
        
        int i = 0;
        String words = "";

        while (num > 0) {
            if (num % 1000 != 0) {
                words = convertChunkToWords((int)(num % 1000)) + thousands[i] + " " + words;
            }
            num /= 1000;
            i++;
        }

        return words.trim();
    }

    public static String convertChunkToWords(int num) {
        String current;

        if (num % 100 < 10) {
            current = units[num % 10];
            num /= 10;
            if (num % 10 != 0) {
                current = tens[num % 10] + current;
                num /= 10;
            }
        } else if (num % 100 < 20) {
            current = teens[num % 10];
            num /= 100;
        } else {
            current = units[num % 10];
            num /= 10;
            current = tens[num % 10] + current;
            num /= 10;
        }
        if (num == 0) return current;
        return units[num] + "Hundred" + current;
    }

    public static void main(String[] args) {
        System.out.println(convertToWords(21522329901L)); 
	    }
}
