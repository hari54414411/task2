import java.util.*;
class Sumtarget
{
public static void findthecombinations(int index,int arr[],int target,List<List<Integer>> ans,List<Integer> ds)
{
	if(index==arr.length)
	{
		if(target==0)
		{
			
			ans.add(new ArrayList<>(ds));
		}
                return;
	}

	if(arr[index]<=target)
	{
		ds.add(arr[index]);
		findthecombinations(index,arr,target-arr[index],ans,ds);
		ds.remove(ds.size()-1);

	}
findthecombinations(index+1,arr,target,ans,ds);

} 

public static List<List<Integer>> method(int arr[],int target)
{
	List<List<Integer>> ans=new ArrayList<>();
	findthecombinations(0,arr,target,ans,new ArrayList<>());
	return ans;
}

public static void main(String[] args)
{
int arr[]={1,2,3,4,5};
int target=5;
System.out.println(method(arr,target));
}
}