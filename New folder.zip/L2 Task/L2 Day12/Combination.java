class Combination
{
public static void main(String[] args)
{
	int arr[]={1, 2, 1};
	int k=2;

	for(int i=0;i<arr.length;i++)
	{
		for(int j=i;j<arr.length;j++)
		{
			if(i==j||arr[i]<arr[j])
			{
				System.out.print("{"+arr[i]+" , "+arr[j]+"}");
			}

		}
	}		

}
}