import java.util.*;

class Distance
{
		public static void method(int a[],int x,int n){
		if(x>n){

		System.out.println(Arrays.toString(a));

		}

		for(int i=0;i<2*n;i++)
		{
 		if (a[i] == -1 && (i + x + 1) < 2*n && a[i + x + 1] == -1)
                {	
			
				a[i]=x;
				a[i+x+1]=x;
				method(a,x+1,n);
				a[i]=-1;
				a[i+x+1]=-1;
		}
			
		}
}
	public static void main(String []s){

		int n=3;
		int a[] = new int[2*n];
                Arrays.fill(a, -1);
		method(a,1,n);


}



}
