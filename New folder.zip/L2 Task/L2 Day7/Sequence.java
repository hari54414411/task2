class Sequence
{
public static void main(String[] args)
{
String s="112358";
int sum=0;
String s1="";
boolean b=true;

	for(int i=1;i<s.length();i++)
	{
	sum=s.charAt(i-1)-'0'+s.charAt(i)-'0';
	s1=sum+"";
        System.out.println(sum+"  "+s1);
		if(s1.equals(s.charAt(i+1)))
		{
		continue;
		}
		
		
	}
System.out.println(b);

}
}