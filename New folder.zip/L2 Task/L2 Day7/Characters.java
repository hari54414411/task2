class characters
{
public static void main(String[] args)
{
String s="FADE";
char c;
	for(int i=0;i<s.length();i++)
	{
	

	
	
	}
}
}