class Spaces
{

public static String addSpaces(String s, int[] spaces) 
    {
        int j=0;
        String s1="";
	int i=0;
        while(i<s.length())
        { 
            if(j<spaces.length && i==spaces[j])
            {
            	
                s1+=" "+s.charAt(i);
		j++;

            }
            else
            {
               s1+=s.charAt(i);
            }
	i++;
        }
        return s1;
    }

public static void main(String[] args)
{
String s = "LeetcodeHelpsMeLearn"; 
int spaces[]= {8,13,15};
System.out.println(addSpaces(s,spaces));
}
}