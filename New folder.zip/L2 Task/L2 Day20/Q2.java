class Q2
{

	public static int method(int arr[])
	{
		int dp[]=new int[arr.length];
		int n=arr.length;

		if(n<3)
		{
			return 0;
		}

		int count=0;

		for(int i=2;i<n;i++)
		{
			if(arr[i]-arr[i-1]==arr[i-1]-arr[i-2])
			{
				dp[i]=dp[i-1]+1;
				count+=dp[i];
			}
		}
		return count;
		
	}

	public static void main(String[] args)
	{
		int arr[]={3,-1,-5,-9};
		System.out.println(method(arr));
	}
}