class Q1
{

	public static int method(int n)
	{
		int dp[]=new int[n+1];

		dp[0]=0;
		dp[1]=1;
		int max=0;
		for(int i=1;i<=n;i++)
		{
			if(2*i<=n)
			{
				dp[2*i]=dp[i];
				if(max<dp[2*i])
				{
					max=dp[2*i];
				}
							}
			if(2*i+1<=n)
			{
				dp[2*i+1]=dp[i]+dp[i+1];
				if(max<dp[2*i+1])
				{
					max=dp[2*i+1];
				}

			}	
				
		}
		return max;
	}

	public static void main(String[] args)
	{
		int n=3;
		System.out.println(method(n));
	}
}