import java.util.*;
class Truncate {
public static String truncateSentence(String s, int k) 
{
StringBuilder sb=new StringBuilder();
String s1[]=s.split(" ");
for(int i=0;i<k;i++)
{
sb.append(s1[i]+" ");
}
return sb.toString().trim();  
    }
public static void main(String[] args)
{
System.out.println(truncateSentence("Hello how are you Contestant", 4));
}
}