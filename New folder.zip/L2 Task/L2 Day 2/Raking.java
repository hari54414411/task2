import java.util.*;
class Raking
{
public static void main(String[] args)
{
int arr[]={1,5,6,3,10};
int rank[]={100,0,1,100,2};
for(int i=0;i<arr.length;i++)
{
for(int j=0;j<arr.length-i-1;j++)
{
if(rank[j] > rank[j + 1] || (rank[j] == rank[j + 1] && arr[j] > arr[j + 1])) {

int temp = arr[j];
arr[j] = arr[j + 1];
arr[j + 1] = temp;

temp = rank[j];
rank[j] = rank[j + 1];
rank[j + 1] = temp;
}
}
}
System.out.println(Arrays.toString(arr));
}
}