import java.util.*;
public class MirrorPair{
	public static void main(String args[]){
		int arr1[]={52,48,71,55,44};
		int arr2[]={84,99,71,48,22};
		mirrorPair(arr1,arr2);
	}

	public static void mirrorPair(int arr1[],int arr2[]){
		HashMap<Integer,Integer> map=new HashMap<>();
		for(int i:arr1){
			map.put(mirror(i),i);
		}
		for(int i:arr2){
			if(map.containsKey(i)){
				System.out.println(map.get(i)+","+i);
			}
		}
	}
	public static int mirror(int i){
		int op=0;
		while(i>0){
			int rem=i%10;
			i/=10;
			op=op*10+rem;
		}
		return op;
	}

}