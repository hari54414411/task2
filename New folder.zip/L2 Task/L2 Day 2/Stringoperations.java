class Stringoperations
{
public static void main(String[] args)
{
String s[]= {"++X","++X","X++"};
int num=0;
for(int i=0;i<s.length;i++)
{
if(s[i].charAt(1)=='+')
{
num++;
}
else
{
num--;
}
}
System.out.println(num);
}
}