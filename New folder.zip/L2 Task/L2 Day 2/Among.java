import java.util.*;
class  Among
{
public static void main(String[] args)
{
int arr[]={1,2,3,4,5,6,7};
int m=5;
int n=6;

int arr2[]=new int[arr.length];

int count=0;
int count1=0;

for(int i=0;i<arr.length;i++)
{
if(m%arr[i]==0)
{
	count++;
}
else if(n%arr[i]==0)
{
	count1++;
}
}
int ind=0;
int end=count+count1;
for(int i=0;i<arr.length;i++)
{
if(m%arr[i]==0)
{
	arr2[ind++]=arr[i];
}
else if(n%arr[i]==0)
{
	arr2[count++]=arr[i];
}
else
{
	arr2[end++]=arr[i];
}

}

System.out.println(Arrays.toString(arr2));

}
}
