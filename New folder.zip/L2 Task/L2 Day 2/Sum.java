class Sum
{
    public static boolean method(int n, int A) {
        while (n > 0) {
            int r = n % 10;
            n = n / 10;
            if (r == A) {
                return true;
            }
        }
        return false;
    }

    public static void main(String[] args) {
        int arr[] = {106, 12, 13, 16};
        int A = 6;
        int sum = 0;
        for (int i = 0; i < arr.length; i++) {
            boolean b = method(arr[i], A);
            if (b) {
                sum += i;
            }
        }
        System.out.println(sum);
    }
}
