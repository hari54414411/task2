class SignFunc
{
public static void main(String[] args)
{
int arr[]={-1,-2,-3,-4,3,2,1};
double sum=arr[0];
for(int i=1;i<arr.length;i++)
{
sum=sum*arr[i];
}
if(sum<0)
{
System.out.println(-1);
}
else if(0<sum)
{
System.out.println(1);
}
else
{
System.out.println(0);
}
}
}