class closestNumber
{
public static int method(int arr[])
{
int min=-100000;
int max=100000;

for(int num:arr)
{
if(num>0&&num<max)
{
max=num;
}
if(num<0&&num>min)
{
min=num;
}
if(num==0)
{
return 0;
}
}
return Math.abs(max)<=Math.abs(min)?max:min;
}
public static void main(String[] args)
{
int arr[]={-4,-2,4,8};
System.out.println(method(arr));
}
}