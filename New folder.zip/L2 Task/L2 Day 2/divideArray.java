class divideArray
{
public static boolean method(int arr[])
{
int arr2[]=new int[501];
for(int i:arr)
{
arr2[i]++;
}
for(int i:arr2)
{
if(i%2==1)
{
return false;
}
}
return true;

}
public static void main(String[] args)
{
int arr[]={3,2,3,2,2,2};
System.out.println(method(arr));
}
}