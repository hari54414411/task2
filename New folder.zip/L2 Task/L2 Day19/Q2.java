class Q2
{
	public static int method(int arr[])
	{
		int first=arr[0];
		int second=arr[1];
		int n=arr.length;
		
		if(n<=2)
		{
			return Math.min(first,second);
		}	

		for(int i=2;i<n;i++)
		{
			int current=arr[i]+Math.min(first,second);
			first=second;
			second=current;
		}
	return Math.min(first,second);
		
	}
	public static void main(String[] args)
	{
		int arr[]={1,100,1,1,1,100,1,1,100,1};
		System.out.println(method(arr));
	}
		
}
	