class Q3{
    public static boolean divisorGame(int n) 
{
        boolean[] dp = new boolean[n + 1];
        dp[2] = true;

        for (int i = 3; i <= n; i++) 
	{
            for (int x = 1; x < i; x++) 
	    {
                if (i % x == 0 && !dp[i - x]) 
		{
                    dp[i] = true;
                    break; 
                }
            }
        }
        
        return dp[n];
    }

    public static void main(String[] args) 
    {
     
        System.out.println(divisorGame(2)); 
        System.out.println(divisorGame(3));
    }
}
