class Q1
{

	public static boolean method(String s,String t)
	{
		int i=0;int j=0;
		while(i<t.length())
		{
			if(s.charAt(j)==t.charAt(i))
			{
				j++;
			}
			i++;
			if(j==s.length())
			{
				return true;
			}
		}
return false;
	}
	
	public static void main(String[] args)
	{
		String s="abc";
		String t="ahbgdc";
		System.out.println(method(s,t));			
	}
}