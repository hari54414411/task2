class Q5
{
    public static int subsetXORSum(int[] nums) {
        int sum = 0;
        for (int num : nums) {
            sum |= num;
        }
        return sum << (nums.length - 1);
    }

    public static void main(String[] args) 
    {
    
        
        
        int[] nums1 = {1, 3};
        System.out.println(subsetXORSum(nums1)); 
        
        int[] nums2 = {5, 1, 6};
        System.out.println(subsetXORSum(nums2));
        
        
        int[] nums3 = {3, 4, 5, 6, 7, 8};
        System.out.println(subsetXORSum(nums3)); 
    }
}
