class Q10
{
    public static String removeOuterParentheses(String s) {
        StringBuilder result = new StringBuilder();
        int opened = 0;
        for (char ch : s.toCharArray()) {
            if (ch == '(' && opened++ > 0) result.append(ch);
            if (ch == ')' && opened-- > 1) result.append(ch);
        }
        return result.toString();
    }

public static void main(String[] args)
{
	String s =  "(()())(())(()(()))";
	System.out.println(removeOuterParentheses(s));
}

}