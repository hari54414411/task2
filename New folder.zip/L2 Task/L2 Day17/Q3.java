class Q3 {
    public static long sumOfVowelsInSubstrings(String word) {
        long count = 0;
        for (int i = 0; i < word.length(); i++) {
            for (int j = i; j < word.length(); j++) {
                if (isVowel(word.charAt(j))) {
                    count++;
                }
            }
        }
        return count;
    }
    public static boolean isVowel(char c) {
        return c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u';
    }

    public static void main(String[] args) {
      

        String word1 = "aba";
        System.out.println(sumOfVowelsInSubstrings(word1)); // Output: 6
        
   
        String word2 = "abc";
        System.out.println(sumOfVowelsInSubstrings(word2)); // Output: 3
        
 
        String word3 = "ltcd";
        System.out.println(sumOfVowelsInSubstrings(word3)); // Output: 0
    }
}
