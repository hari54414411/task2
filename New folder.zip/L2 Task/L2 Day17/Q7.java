class Q7 {
    public static int change(int n, int m, int[] S) {
        int[] dp = new int[n + 1];
        dp[0] = 1;

        for (int j = 0; j < m; j++) {
            for (int i = S[j]; i <= n; i++) {
                dp[i] += dp[i - S[j]];
            }
        }

        return dp[n];
    }

    public static void main(String[] args) {
      
        
 
        int n1 = 4, m1 = 3;
        int[] S1 = {1, 2, 3};
        System.out.println(change(n1, m1, S1));
        
    
        int n2 = 10, m2 = 4;
        int[] S2 = {2, 5, 3, 6};
        System.out.println(change(n2, m2, S2)); 
    }
}
