class Q6
{
    public static double getProbability(int[] balls) {
        return dfs(balls, 0, 0, 0, 0, new Double[balls.length + 1][balls.length + 1][balls.length * 2 + 1]);
    }

    private static double dfs(int[] balls, int index, int sumA, int sumB, int cnt, Double[][][] memo) {
        if (index == balls.length) {
            return sumA == sumB && cnt == balls.length / 2 ? 1 : 0;
        }
        if (memo[index][sumA][cnt] != null) return memo[index][sumA][cnt];
        
        double res = 0;
        for (int i = 0; i <= balls[index]; ++i) {
            int j = balls[index] - i;
            if (cnt + i <= balls.length / 2 && cnt + j <= balls.length / 2) {
                res += dfs(balls, index + 1, sumA + (i == 0 ? 0 : 1), sumB + (j == 0 ? 0 : 1), cnt + i + j, memo);
            }
        }
        return memo[index][sumA][cnt] = res;
    }

    public static void main(String[] args) {
       
        
        int[] balls1 = {1, 1};
        System.out.println(getProbability(balls1));
        
        int[] balls2 = {2, 1, 1};
        System.out.println(getProbability(balls2)); 
        
        
        int[] balls3 = {1, 2, 1, 2};
        System.out.println(getProbability(balls3)); 
    }
}
