import java.util.*;

class Q1 {
    public static int[] diStringMatch(String s) {
        int n = s.length();
        int[] result = new int[n + 1];
        int min = 0, max = n;
        for (int i = 0; i < n; i++) {
            if (s.charAt(i) == 'I') {
                result[i] = min++;
            } else {
                result[i] = max--;
            }
        }
        result[n] = min; 
        return result;
    }

    public static void main(String[] args) {
     
        
       
        String s1 = "IDID";
        System.out.println(Arrays.toString(diStringMatch(s1))); 
        
        String s2 = "III";
        System.out.println(Arrays.toString(diStringMatch(s2)));
  
        String s3 = "DDI";
        System.out.println(Arrays.toString(diStringMatch(s3))); 
    }
}
