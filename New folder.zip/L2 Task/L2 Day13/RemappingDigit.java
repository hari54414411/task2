class RemappingDigit
{
 	public static int mapping(int num)
	{
		String s=String.valueOf(num);
		
		int index=0;
		int max=0;int min=0;
		boolean flag=true;
		char firstchar=s.charAt(0);
		for(int i=0;i<s.length();i++)
		{
			if(s.charAt(i)!='9')
			{
				flag=false;
				index=i;	
				break;
			}
		max=(max*10)+(s.charAt(i)-'0');			
		}
		if(flag)
		{
			return num;	
		}
		int temp=s.charAt(index);
		for(int i=index;i<s.length();i++)
		{
			if(temp==s.charAt(i))
			{
				max=(max*10)+9;
			}	
			else
			{
				max=(max*10)+s.charAt(i)-'0';
			}
		}

		for(int i=0;i<s.length();i++)
		{
			if(firstchar!=s.charAt(i))
			{
				min=(min*10)+s.charAt(i)-'0';
			}
			else
			{
				min=(min*10)+0;
			}
		}
return max-min;
		
	

	}
public static void main(String[] args)
{
int num=90;
System.out.println(mapping(num));

}
}