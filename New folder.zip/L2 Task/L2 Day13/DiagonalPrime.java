class DiagonalPrime{
    public static int diagonalPrime(int[][] nums) 
    {
        int max=0;
        int ans=0;
        for(int i=0;i<nums.length;i++)
        {
            for(int j=0;j<nums[0].length;j++)
            {
                if(i==j||i+j==nums.length-1)
                {
                   if(prime(nums[i][j]))
                   {
                        if(max<nums[i][j])
                        {
                        max=nums[i][j];
                        }
                   } 
                }
            }
        }
        return max;
        
    }
    
 public static boolean prime( int n){
          if(n==1) return false;
            if (n==2) return true;
            for(int i=2;i*i<=n;i++){
                if(n%i==0) return false;
            }
            return true;
        }
public static void main(String[] args)
{
	int arr[][]={{1,2,3},{5,6,7},{9,10,11}};
	int arr1[][]={{1,2,3},{5,17,7},{9,11,10}};
	System.out.println(diagonalPrime(arr));
	System.out.println(diagonalPrime(arr1));
}

}