class Bag
{
public static int method(int ones,int zeros,int negs,int k)
{
	if(k<=ones)
	{
		return k;
	}
	else if(k<=ones+zeros)
	{
		return ones;
	}
 return ones-(k-(ones+zeros));

}
public static void main(String[] args)
{
int numOnes = 3;
int numZeros=2;
int numNegOnes=0;
int k=6;
System.out.println(method(numOnes,numZeros,numNegOnes,k));

}
}