class Symmetric
{

	public static int method(int low,int high)
	{
		int count=0;
		for(int i=low;i<=high;i++)
		{
			if(symmetric(i))
			{
				count++;
			}
		}	
	return count;
	}

public static boolean symmetric(int num)
{
	String s=String.valueOf(num);
	int len=s.length();
	int mid=len/2;
	int s1=0;int s2=0;
	if(len%2==1)
	{
		return false;
	}
	
	for(int i=0;i<mid;i++)
	{
		s1=s.charAt(i)-'0';
		s2=s.charAt(mid+i)-'0';
		
	}

	return s1==s2;
	
}
	
public static void main(String[] args)
{
int low=1200;
int high=1230;

System.out.println(method(low,high));

}
}