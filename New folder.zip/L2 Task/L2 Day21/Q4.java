class Q4
{

	public static String method(String s,int x)
	{
		StringBuilder sb=new StringBuilder();
		char c1[]=new char[26];
		for(char c:s.toCharArray())
		{
			c1[c-'a']++;	
		}

		for(char c:s.toCharArray())
		{
			char c2=' ';
			int index=c-'a';
			
			if(c1[c-'a']%2==0)
			{
				c2=(char)(((c-'a'+x)%26)+'a');
			}

			else
			{
				c2=(char)(((c - 'a' - x + 26) % 26) + 'a');
			}
		sb.append(c2);
		}
return sb.toString();
	}

	public static void main(String[] args)
	{
		String s="aabbc";
		int k=5;
		System.out.println(method(s,k));
	}
}