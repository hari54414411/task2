class Customerwealth
{
public static void main(String[] args)
{
int arr[][]={{2,8,7},{7,1,3},{1,9,5}};
int customerwealth;
int max=0;
for(int i=0;i<arr.length;i++)
{
customerwealth=0;
for(int j=0;j<arr[i].length;j++)
{
customerwealth+=arr[i][j];
}
if(customerwealth>=max)
{
max=customerwealth;
}

}
System.out.println(max);
}
}