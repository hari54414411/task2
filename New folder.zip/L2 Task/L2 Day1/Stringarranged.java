class Stringarranged
{
public static int arranged(String s[],int column)
{

int count=0;
for(int i=1;i<s[0].length();i++)
{
if(s[i].charAt(column)<s[i-1].charAt(column))
{
 count++;
break;

}
}
return count;
}
public static void main(String[] args)
{
String s[]={"zyx","wvu","tsr"};
int count=0;
for(int i=0;i<s[0].length();i++)
{
count+=arranged(s,i);
}
System.out.println(count);
}
}