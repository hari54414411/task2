import java.util.*;
class Percentage
{
public static void main(String[] args)
{
int arr[]={1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,3};
int count=(int) Math.round(arr.length*0.05);
int sum=0;
for(int i=count;i<arr.length-count;i++)
{
	sum+=arr[i];
}
double mean=(double) sum/(arr.length-(2*count));
System.out.println(mean);
}
}