import java.util.*;
class Freq
{
public static void main(String[] args)
{
int arr[]={1,2,3,4};
int frequence=0;
for(int i=0;i<arr.length;i=i+2)
{
frequence+=arr[i];
}
int arr2[]=new int[frequence];
int k=0;
for(int i=0;i<arr.length;i=i+2)
{
for(int j=0;j<arr[i];j++)
{
arr2[k]=arr[i+1];
k++;
}
}
System.out.println(Arrays.toString(arr2));
}
}