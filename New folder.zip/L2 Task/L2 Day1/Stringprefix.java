class Stringprefix
{
public static boolean counting(String s,String s1)
{
for(int i=0;i<s1.length();i++)
{
if(s.charAt(i)!=s1.charAt(i))
{
return false;
}
}
return true;
}
public static void main(String[] args)
{
String word[]={"pay","attention","practice","attend"};
String pref = "at";
int count=0;
for(int i=0;i<word.length;i++)
{
if(word[i].length()>=pref.length()&&counting(word[i],pref))
{
count++;
}
}
System.out.println(count);
}
}