import java.util.*;
class Candies
{
public static void main(String[] args)
{
int candies[]= {12,1,12};
boolean b[]=new boolean[candies.length];
int extraCandies = 10;
int max=0;
for(int i=0;i<candies.length;i++)
{
if(candies[i]>max)
{
max=candies[i];
}
}

for(int i=0;i<candies.length;i++)
{
if(candies[i]+extraCandies>=max)
{
b[i]=true;
}
else
{
b[i]=false;
}
}
System.out.println(Arrays.toString(b));
}
}