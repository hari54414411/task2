class TransformString {
    public static String transformString(String s, int k) {
        while (s.length() > k) {
            StringBuilder sb = new StringBuilder();
            int i = 0;
            while (i < s.length()) {
                int sum = 0;
                for (int j = 0; j < k && i + j < s.length(); j++) {
                    sum += s.charAt(i + j) - '0';
                }
                sb.append(sum);
                i += k;
            }
            s = sb.toString();
        }
        return s;
    }

    public static void main(String[] args) {
        String s1 = "11111222223";
        int k1 = 3;
        System.out.println(transformString(s1, k1)); 

       
    }
}
