public class SumOddLengthSubarrays {
    public static int sumOddLengthSubarrays(int[] arr) {
        int totalSum = 0;
        int n = arr.length;
	
        for (int i = 0; i < n; i++) {
            for (int j = i; j < n; j += 2) { 
		
                totalSum += sum(arr, i, j); 
            }
        }
        return totalSum;
    }
    
    private static int sum(int[] arr, int start, int end) {
        int sum = 0;
        for (int k = start; k <= end; k++) {
            sum += arr[k];
        }
        return sum;
    }

    public static void main(String[] args) {
        int[] arr1 = {1, 4, 2, 5, 3};
      
        
        System.out.println(sumOddLengthSubarrays(arr1)); 
            }
}
