import java.util.*;
class Pair
{
public static int Reverse(int num)
{
int r;int reverse=0;
while(num>0)
{
r=num%10;
reverse=(reverse*10)+r;
num=num/10;

}
return reverse;
}
public static void main(String[] args)
{

int A[]={52,48,71,55,44};
int B[]={84,99,71,48,22};

Map<Integer,Integer> map=new HashMap<>();
for(int i=0;i<A.length;i++)
{
map.put(Reverse(A[i]),A[i]);
}

for(int i=0;i<B.length;i++)
{
if(map.containsKey(B[i]))
{
System.out.print(map.get(B[i]));
System.out.print(" , ");
System.out.print(B[i]);
}
System.out.println();
}
}
}