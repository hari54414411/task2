class Product
{
public static void main(String[] args)
{
int arr[]={-2, -40, 0, -2, -3};
int prefix=1;int suffix=1;
int ans=0;
for(int i=0;i<arr.length;i++)
{
	if(prefix==0)
	{
	prefix=1;
	}
	if(suffix==0)
	{
	suffix=1;
	}
	prefix*=arr[i];
	suffix*=arr[arr.length-i-1];
        ans=Math.max(ans,Math.max(prefix,suffix));
	
	     	
}
System.out.println(ans);
	
}


}