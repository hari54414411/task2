class Power3
{
	public static boolean isPowerOfFour(int n)
	{
	if (n <= 0)
	{
            return false;
	}
        else if (n == 1)
	{

            return true;
	}
        else if (n % 3 != 0)
	{
            return false;
	}
        else
	{
            return isPowerOfFour(n /3);
	}
    }

public static void main(String[] args)
{
	int n=27;
		
	System.out.println(isPowerOfFour(n));
}
}