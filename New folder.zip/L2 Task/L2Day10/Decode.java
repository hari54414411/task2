class Decode {
    public static String decodeString(String s) {
      StringBuilder result = new StringBuilder();
        int i = 0;
        
        while (i < s.length()
        {
            char currentChar = s.charAt(i);
            
            if (Character.isDigit(currentChar)) 
	    {
                int numStart = i;
                while (Character.isDigit(s.charAt(i + 1))) 
		{
                    i++;
                }
                int num = Integer.parseInt(s.substring(numStart, i + 1));
                
                int start = i + 2;
                int end = findEndOfEncodedString(s, start);
                

                String decodedString = decodeString(s.substring(start, end));
                for (int j = 0; j < num; j++) 
		{
                    result.append(decodedString);
                }
                i = end + 1;
            } else {
                result.append(currentChar);
                i++;
            }
        }
        
        return result.toString();
    }
    
    private int findEndOfEncodedString(String s, int start) 
	{
        int openBrackets = 1;
        int i = start;
        while (openBrackets != 0) {
            if (s.charAt(i) == '[') {
                openBrackets++;
            } else if (s.charAt(i) == ']') {
                openBrackets--;
            }
            i++;
        }
        return i - 1;
    }

public static void main(String[] args)
{
	String s="2[a]3[bc]";
	System.out.println(decodeString(s));

}
}