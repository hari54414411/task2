import java.util.*;
class Reverse
{
	public static void method(char c[])
	{
		int n=c.length;
		for(int i=0;i<n/2;i++)
		{
		char temp=c[n-i-1];
		c[n-i-1]=c[i];
		c[i]=temp;
		
  		}
	}
public static void main(String[] args)
{
	char c[]={'h','e','l','l','o'};
	method(c);
        System.out.println(Arrays.toString(c));

	
	

}

}