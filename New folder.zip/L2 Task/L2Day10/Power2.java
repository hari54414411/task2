class Power2
{
	public static boolean isPowerOfFour(int n)
	{
	if (n <= 0)
	{
            return false;
	}
        else if (n == 1)
	{

            return true;
	}
        else if (n % 2 != 0)
	{
            return false;
	}
        else
	{
            return isPowerOfFour(n /2);
	}
    }

public static void main(String[] args)
{
	int n=9;
		
	System.out.println(isPowerOfFour(n));
}
}