class ListNode {
    int val;
    ListNode next;
    ListNode() {}
    ListNode(int val) { this.val = val; }
    ListNode(int val, ListNode next) { this.val = val; this.next = next; }
}

class MergeTwoSortedLists {
    public ListNode mergeTwoLists(ListNode l1, ListNode l2) {
        
        ListNode dummy = new ListNode();
   
        ListNode current = dummy;
        
        
        while (l1 != null && l2 != null) 
	{

               if (l1.val < l2.val) 
		{
                current.next = l1;
                l1 = l1.next;
            } else {
                current.next = l2;
                l2 = l2.next;
            }
            current = current.next;
        }
	 	while (l1 != null)
		{

                current.next = l1;
                l1 = l1.next;
		current = current.next;
		}

	        while (l2 != null)
		{

                current.next = l2;
                l2 = l2.next;
		current = current.next;
		}

        
                       
               return dummy.next;
    }
    
    public static void main(String[] args) {
       
        ListNode list1 = new ListNode(1);
        list1.next = new ListNode(2);
        list1.next.next = new ListNode(4);

        ListNode list2 = new ListNode(1);
        list2.next = new ListNode(3);
        list2.next.next = new ListNode(4);

       
        MergeTwoSortedLists merger = new MergeTwoSortedLists();

        
        ListNode mergedList = merger.mergeTwoLists(list1, list2);
        while (mergedList != null) {
            System.out.print(mergedList.val + " ");
            mergedList = mergedList.next;
        }
    }
}
