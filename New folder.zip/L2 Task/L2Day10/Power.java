class Power
{
	public static boolean isPowerOfFour(int n,int power)
	{
	if (n <= 0)
	{
            return false;
	}
        else if (n == 1)
	{

            return true;
	}
        else if (n % 4 != 0)
	{
            return false;
	}
        else
	{
            return isPowerOfFour(n /power,power);
	}
    }

public static void main(String[] args)
{
	int n=64;
	int power=4;	
	System.out.println(isPowerOfFour(n,power));
}
}