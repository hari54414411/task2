class ReformatString
 {
    public static String reformat(String s) 
{
        StringBuilder letters = new StringBuilder();
        StringBuilder digits = new StringBuilder();

        for (char c : s.toCharArray()) {
            if (Character.isDigit(c)) {
                digits.append(c);
            } else {
                letters.append(c);
            }
        }

        int diff = Math.abs(letters.length() - digits.length());
        if (diff > 1) {
            return "";
        }

        StringBuilder result = new StringBuilder();
        int i = 0;
        int j = 0;

      
        while (i < letters.length() && j < digits.length()) {
            if (letters.length() > digits.length()) {
                result.append(letters.charAt(i++));
                result.append(digits.charAt(j++));
            } else {
                result.append(digits.charAt(j++));
                result.append(letters.charAt(i++));
            }
        }

        
        if (i < letters.length()) {
            result.append(letters.charAt(i));
        }
        if (j < digits.length()) {
            result.append(digits.charAt(j));
        }

        return result.toString();
    }

    public static void main(String[] args) {
        String s1 = "a0b1c2";
        String s2 = "leetcode";
        String s3 = "1229857369";

        System.out.println(reformat(s1)); // Output: "0a1b2c"
        System.out.println(reformat(s2)); // Output: ""
        System.out.println(reformat(s3)); // Output: ""
    }
}
