class Palindrome
{
public static boolean method(String s)
{
 if(s.isEmpty())
        {
           return true; 
        }
        int i=0;
        int j=s.length()-1;
        s=s.toLowerCase();

        while(i<j)
        {
           if(!Character.isLetterOrDigit(s.charAt(i)))
           {
               i++;
           }
           else if(!Character.isLetterOrDigit(s.charAt(j))) 
           {
               j--;
           }
           else
           {
               if(s.charAt(i)!=s.charAt(j))
               {
                   return false;
               }
               i++;
               j--;
           }
        }
        return true;

}
public static void main(String[] args)
{
String  s ="A man, a plan, a canal: Panama";

System.out.println(method(s));
}
}