class Shifting
{

public static boolean method(String s,String goal)
{
String s1=s+s;
int count=0;
int j=0;
for(int i=0;i<s1.length();i++)
{
	if(s1.charAt(i)==goal.charAt(j)&&j<goal.length())
	{
		count++;
		j++;	
	}	

}
if(count==goal.length())
{
return true;
}
return false;
}

public static void main(String[] args)
{
String s = "abcde";
String goal = "cdeab";
method(s,goal);
}
}