
class Binary
{
public static void main(String[] args)
{
String a="11";String b="1";
int i=a.length()-1;
int j=b.length()-1;
int carry=0;

StringBuilder sb=new StringBuilder();
while(i>=0||j>=0)
{
	int bit1=(i>=0)?a.charAt(i)-'0':0;
	int bit2=(j>=0)?b.charAt(j)-'0':0;
	int sum=bit1+bit2+carry;
	sb.insert(0,sum%2);
	carry=sum/2;
	i--;j--;
	
}
if(carry!=0)
    {
        sb.insert(0,carry);
    }
    System.out.println(sb);

}
}