class Diagonalpattern 
{
public static void main(String[] args)
{
String s="helloo";
int mid=s.length()/2;
int n=s.length();
if(s.length()%2==1)
{
for(int i=0;i<s.length();i++)
{
	for(int j=0;j<s.length();j++)
	{
	if(i+j==mid||j-i==mid||i-j==mid||i+j==(n+ (n/2))-1)
	{
	System.out.print(s.charAt(j));
	}
	else
	{
	System.out.print(" ");
	}	
	}
System.out.println();
}
}
else
{
System.out.println("Not Possible");
}
}
}