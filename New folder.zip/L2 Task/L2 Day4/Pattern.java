import java.util.*;
class Pattern
{
	public static boolean method(int arr[])
	{
		Stack<Integer> s=new Stack<>();
		int min=Integer.MIN_VALUE;
		for(int i=arr.length-1;i>=0;i--)
		{
		if(arr[i]<min)
		{	
		return true;	
		}
		while(!s.isEmpty() && s.peek()<arr[i])
		{
			min=s.pop();	
		}
		s.push(arr[i]);
		}
		return false;	
	}
public static void main(String[] args)
{
	int arr[]={1,2,3,4};
	System.out.println(method(arr));
	
}
}