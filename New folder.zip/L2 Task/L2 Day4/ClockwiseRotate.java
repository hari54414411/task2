class ClockwiseRotate
{
public static void method(int arr[],int low,int high)
{
	while(low<high)
	{
	int temp=arr[low];
	arr[low]=arr[high];
	arr[high]=temp;
	low++;
	high--;
	}
}
public static void main(String[] args)
{
	int A[] = {1, 2, 3, 4, 5};
	int k=1;
	method(A,0,A.length-1);
	method(A,0,k-1);
	method(A,k,A.length-1);
	for(int i=0;i<A.length;i++)
	{
	System.out.println(A[i]+" ");
	}

}
}
