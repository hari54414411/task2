import java.util.*;
class PairSum
{
public static void main(String[] args)
{
int N = 4;
int K=6;
int arr[] = {1, 1, 1, 1};
int pair=0;
Map<Integer,Integer> map=new HashMap<>();

	for(int num:arr){
		if(map.containsKey(num))
		{
			map.put(num,map.get(num)+1);	
		}
		else
		{
			map.put(num,1);
		}
	}

	for(int num:arr)
	{
	int sum=K-num;
	if(map.containsKey(sum))
	{
		pair+=map.get(num);
	}
	if(sum==num)
	{
	pair--;
	}
}

System.out.println(pair/2);



}
}