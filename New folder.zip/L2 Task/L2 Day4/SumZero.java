import java.util.*;
class SumZero
{
public static boolean method(int arr[])
{
	Set<Integer> s=new HashSet<>();
	int sum=0;

	for(int i=0;i<arr.length;i++)
	{
		sum+=arr[i];
		if(sum==0||s.contains(sum))
		{
		return true;
			
		}
		s.add(arr[i]);

	}
return false;
	


}
public static void main(String[] args)
{
	int arr[]={4,2,-3,1,6};
	System.out.println(method(arr));
}
}