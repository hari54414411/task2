import java.util.HashSet;

public class SubarrayWithZeroSum{
    public static boolean subarrayWithZeroSum(int[] arr) {
        HashSet<Integer> prefixSums = new HashSet<>();
        int prefixSum = 0;

        for (int num : arr) {
            prefixSum += num;

            if (prefixSum == 0 || prefixSums.contains(prefixSum)) {
                return true;
            }

            prefixSums.add(prefixSum);
        }

        return false;
    }

    public static void main(String[] args) {
        int[] arr1 = {4, 2, -3, 1, 6};
        System.out.println(subarrayWithZeroSum(arr1)); // Output: true

        int[] arr2 = {4, 2, 0, 1, 6};
        System.out.println(subarrayWithZeroSum(arr2)); // Output: true

        
}
}