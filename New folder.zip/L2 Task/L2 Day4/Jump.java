class Jump
{
public static void main(String[] args)
{
	int N = 6; 
	int arr[] = {1, 4, 3, 2, 6, 7};
	int jump=0;
	int max=0;
	int currentend=0;

	for(int i=0;i<N-1;i++)
	{
	max=Math.max(max,arr[i]+i);
	if(i==currentend)
	{
	jump++;
	currentend=max;	
	}
}
System.out.println(jump);

}
}