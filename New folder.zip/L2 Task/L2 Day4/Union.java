import java.util.*;
class Union
{
public static void main(String[] args)
{
int arr[]={1,2,3,4,5};
int arr1[]={1,2,3};
Set<Integer> set=new HashSet<>();

	for(int num:arr)
	{
		set.add(num);
	}
	for(int num:arr1)
	{
		set.add(num);
	}
System.out.println(set.size());





}
}