class Matrix
{
public static void main(String[] args)
{
int arr[][] ={{0, 1, 1, 1},
           {0, 0, 1, 1},
           {1, 1, 1, 1},
           {0, 0, 0, 0}};
int min=6;
int ans=0;
	for(int i=0;i<arr.length;i++)
	{				
	int temp=10;
	for(int j=0;j<arr[0].length;j++)
	{
          	if(arr[i][j]==1)
		{
			temp=j;
			break;
		}
		
	
	}	
	if(temp<min)
	{
	min=temp;
	ans=i;
	}
	
	}
System.out.println(ans);
}
}