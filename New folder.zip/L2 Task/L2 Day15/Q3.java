class Q3
{

	public static int method(int arr[])
	{
		int ones=0,twos=0;
		for(int num:arr)
		{
			ones=(ones^num) & ~twos;
			twos=(twos^num) & ~ones;
	        }
return ones;	
	}

public static void main(String[] args)
{
	int num[]={2,2,3,2,3,3,99};
	System.out.println(method(num));

}
}