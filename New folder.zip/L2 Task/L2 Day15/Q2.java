import java.util.*;
class Q2
{

public static List<List> method(int arr[])
{
	int n=1<<arr.length;
	List<List> ans=new ArrayList<>();

	for(int i=0;i<n-1;i++)
	{
	List<Integer> l=new ArrayList<>();
		for(int j=0;j<arr.length;j++)
		{
			if((i&(1<<j))!=0)
			{
				l.add(arr[j]);
			}
		}
		ans.add(l);
	

	}
	return ans;
}
public static void main(String[] args)
{
	int arr[]={1,2,3};
	System.out.println(method(arr));
}
}