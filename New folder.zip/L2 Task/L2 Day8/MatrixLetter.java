class MatrixLetter
{
public static boolean method(char arr[][],String s )
{
for(int i=0;i<arr.length;i++)
{	
	for(int j=0;j<arr.length;j++)
	{
		if(arr[i][j]==s.charAt(0))
		{
			if(method1(arr,i,j,s))
			{	
			return true;	
			}
		}
		
	}	
}
return false;

}

public static boolean method1(char arr[][],int i,int j,String s)
{
	int index=0;
	for(int k=i;k<arr.length;k++)
	{
		if(arr[k][j]==s.charAt(index))
		{	
			index++;		
		}	
	}
	if(s.length()==index)
	{
	return true;
	}

	for(int k=j;k<arr.length;k++)
	{
		if(arr[j][k]==s.charAt(index))
		{	
			index++;		
		}	
	}
	if(s.length()==index)
	{
	return true;
	}


	
return false;
}
 
public static void main(String[] args)
{
char arr[][]={{'h','o','l','z'},{'a','l','o','o'},{'a', 'b', 'c','h'},{'o', 'k', 'j', 'o'}};
String s="zoho";
System.out.println(method(arr,s));

}
}