class ConsecutiveOnes {

    public static int countConsecutiveOnes(int[][] grid) {
        if (grid == null || grid.length == 0) {
            return 0;
        }

        int rows = grid.length;
        int cols = grid[0].length;
        int count = 0;

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                if (grid[i][j] == 1) {
                    dfs(grid, i, j);
                    count++;
                }
            }
        }

        return count;
    }

    private static void dfs(int[][] grid, int row, int col) {
        int rows = grid.length;
        int cols = grid[0].length;

        if (row < 0 || col < 0 || row >= rows || col >= cols || grid[row][col] != 1) {
            return;
        }

        grid[row][col] = 0; // Mark visited

        dfs(grid, row + 1, col);
        dfs(grid, row - 1, col); 
        dfs(grid, row, col + 1); 
        dfs(grid, row, col - 1); 
    }

    public static void main(String[] args) {
        int[][] grid = {
                {1, 1, 0, 0, 0},
                {0, 1, 0, 0, 1},
                {1, 0, 0, 1, 1},
                {0, 0, 0, 0, 0},
                {1, 0, 1, 0, 1}
        };

        int count = countConsecutiveOnes(grid);
        System.out.println("Number of consecutive ones: " + count);
    }
}
