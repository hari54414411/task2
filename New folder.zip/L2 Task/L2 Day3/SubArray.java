class SubArray
{
public static void main(String[] args)
{
int arr[] ={2, 6, 0, 9, 7, 3, 1, 4, 1, 10};
int target = 15;
int i=0;int j=0;int sum=0;
while(j<arr.length)
{
if(sum==target)
{
break;
}

if(j<arr.length)
{
sum+=arr[j++];
}

if(sum>target)
{
sum-=arr[i++];
}


}
for(int k=i;k<j;k++)
{
System.out.println(arr[k]+" ");
}



}
}