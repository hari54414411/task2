import java.util.*;
class Stoneweight 
{
        public static int lastStoneWeight(int[] stones) {
        PriorityQueue<Integer> pq = new PriorityQueue<>(Collections.reverseOrder());

        for(int i=0; i<stones.length; i++){
            pq.add(stones[i]);
        }

        while(pq.size()>1)
	{
            int a = pq.poll();
            int b = pq.poll();

            if(a-b!=0){
                pq.add(a-b);
            }
        }
        if(pq.isEmpty()){
            return 0;
        }
        return pq.poll();
        }
public static void main(String[] args)
{
int stones[]= {2,7,4,1,8,1};
System.out.println(lastStoneWeight(stones));
}
}