import java.util.*;
class Ball 
{
	public static void main(String[]args){
		int[] dir={-1,1,-1,1,-1,-1,1,1};
		int[] ball={5,4,5,6,3,1,2,3};
		System.out.println(check(dir,ball));
	}
	public static List<Integer> check(int[]dir,int[]ball){
		List<Integer> list=new ArrayList<Integer>();
		int j=1;int i=0;
		for(;j<dir.length;j++){
			if(dir[i]==-1 || dir[i]==dir[j]){ list.add(ball[i]); i=j;}
			else i=(ball[i]>ball[j])?i:j;
		}
		if(dir[j-1]==1)list.add(ball[j-1]);
		else if(dir[i]-dir[j-1]==0) list.add((ball[i]>ball[j-1])?ball[i]:ball[j-1]);

		return list;
	}
}

