import java.util.*;
class Con
{
public static void Sort(int arr[])
{
for(int i=0;i<arr.length;i++)
{
for(int j=i+1;j<arr.length;j++)
{
if(arr[i]>arr[j])
{
int temp=arr[i];
arr[i]=arr[j];
arr[j]=temp;
}
}

}
}
public static void main(String[] args)
{
int arr[]={-1,5,4,2,0,3,1};
Sort(arr);
int sum=0;
int count=0;
for(int i=1;i<arr.length;i++)
{
sum=arr[i-1]+1;
if(sum==arr[i])
{
count++;
}
else
{
break;
}
}
if(count==arr.length-1)
{
System.out.println("The array contains consecutive integers from "+arr[0]+" to "+arr[arr.length-1]);
}
else
{
System.out.println("The array does not contain consecutive integers as element");
}
}
}