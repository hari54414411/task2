import java.util.*;
class Changing
{
public static void main(String[] args)
{
int arr[]={1,-1,3,2,-7,-5,11,6};
int arr2[]=new int[arr.length];
int pos=0;
for(int i:arr)
{
if(0<i)
{
pos++;
}
}
int ind=0;
for(int i=0;i<arr.length;i++)
{
if(arr[i]>0)
{
arr2[ind++]=arr[i];
}
else
{
arr2[pos++]=arr[i];
}
}
System.out.println(Arrays.toString(arr2));
}
}