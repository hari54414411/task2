import java.util.*;

class Split {
    public static void main(String[] args) {
        int arr[] = {58, 24, 13, 15, 63, 8, 81, 1, 78};
        int length = arr.length / 2;

        if (arr.length % 2 != 0) {
            length = arr.length / 2 + 1;
        }

        int arr1[] = new int[length];
        int arr2[] = new int[arr.length - length];

        for (int i = 0; i < length; i++) {
            arr1[i] = arr[i];
        }

        for (int i = length; i < arr.length; i++) {
            arr2[i - length] = arr[i];
        }

        System.out.println(Arrays.toString(arr1));
        System.out.println(Arrays.toString(arr2));
    }
}
