import java.util.*;
class Rotate
{
public static void method(int arr[],int low,int high)
{
while(low<high)
{
int temp=arr[low];
arr[low]=arr[high];
arr[high]=temp;
low++;
high--;
}
}
public static void main(String[] args)
{
int arr[]={1,2,3,4,5,6,7};
int k=3;
method(arr,0,arr.length-1);
method(arr,0,k-1);
method(arr,k,arr.length-1);
System.out.println(Arrays.toString(arr));
}
}