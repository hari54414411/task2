class Hospital
{
public static void main(String[] args)
{
int Cases[]={1,2,3,1,4,5,2,3,6};
int k=3;
int i=0;int j=0;
int sum=0;
int max=0;
while(i<Cases.length)
{
if(j>=k)
{
sum-=Cases[i++];
}
if(j<Cases.length)
{
sum+=Cases[j++];
}
if(max<sum)
{
max=sum;
}
}
System.out.println(max);
}
}