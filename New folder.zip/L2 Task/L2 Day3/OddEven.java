import java.util.*;
class OddEven
{
public static void main(String[] args)
{
Scanner s=new Scanner(System.in);
int arr[]=new int[20];
int positive=0;
int negative=0;
int odd=0;
int even=0;
int zero=0;
for(int i=0;i<20;i++)
{
System.out.println("Enter the number:");
int num=s.nextInt();
arr[i]=num;
}
for(int i=0;i<arr.length;i++)
{
if(0<arr[i])
{
positive++;
if(arr[i]%2==0)
{
even++;
}
else
{
odd++;
}
}
else if(0>arr[i])
{
negative++;
if(arr[i]%2==0)
{
even++;
}
else
{
odd++;
}

}
else
{
zero++;
}
}

System.out.println(positive+"number of positive numbers");
System.out.println(negative+"number of negative numbers");
System.out.println(odd+"number of odd numbers");
System.out.println(even+"number of even numbers");
System.out.println(zero+"number  of os");
}
}