import java.util.*;
class MaxandMin
{
public static void main(String[] args)
{
Scanner s=new Scanner(System.in);
System.out.println("Enter the size of the Arrays:");
int Size=s.nextInt();
System.out.println("Enter the Array Values:");
int[] arr=new int[Size];
for(int i=0;i<arr.length;i++)
{
arr[i]=s.nextInt();
}
int max=Integer.MIN_VALUE;
int min=Integer.MAX_VALUE;
int second_min=min;


for(int i=0;i<arr.length;i++)
{
    if(arr[i]>max){
	max=arr[i];	
    }
    if(arr[i]<min){
	second_min=min;
	min=arr[i];
	
    }
    if(arr[i]<second_min && min!=arr[i]){
	second_min=arr[i];
    }
}
System.out.println("maximum difference:"+(max-min));
System.out.println("minimum difference:"+(second_min-min));
}
}