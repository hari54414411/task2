import java.util.*;
class Q2
{
	public static int MissingNumber(int arr[],int N)
	{
	Queue<Integer> q=new LinkedList<>();
		for(int i=1;i<=N;i++)
		{
			q.add(i);
		}

		for(int i=0;i<arr.length;i++)
		{
			q.remove(arr[i]);
		}
return q.peek();
	} 
public static void main(String[] args)
{
	int arr[]={6,1,2,8,3,4,7,10,5};
	int N=10;
	System.out.println(MissingNumber(arr,N));
}
}