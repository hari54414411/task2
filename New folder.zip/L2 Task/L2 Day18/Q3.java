class Q3
{

	public static void main(String[] args)
	{
		int arr[]={1, 3, 5, 8, 9, 2, 6, 7, 6, 8, 9};
		System.out.println(Jump(arr));
	}
}