import java.util.*;
class Q5
{
	public static int Majority(int arr[])
	{
		Queue<Integer> q=new LinkedList<>();
		int count=1;
		q.add(arr[0]);

		for(int num:arr)
		{
			
			if(q.peek()==num)
			{
				count++;
			}
			else
			{
				count--;
			}
			if(count==0)
			{
				q.remove();
				q.add(num);
				count++;
			}

		}
		int ans=q.poll();
		int count1=0;
		for(int num:arr)
		{
			if(num==ans)
			{
				count1++;
			}
		}

		if(count1>(arr.length/2))
		{
			return ans;
		}
		return -1;
		
	}
	

	public static void main(String arg[])
	{
		int arr[]={3,1,2};
		System.out.println(Majority(arr));
	}
}