import java.util.*;
class Q1
{
	public static ArrayList<Integer> SubArray(int arr[],int s)
	{
		Queue<Integer> que=new LinkedList<>();
		ArrayList<Integer> a=new ArrayList<>();
		int sum=0;
		for(int i=0;i<arr.length;i++)
		{
			sum+=arr[i];
			que.add(i);
			while(sum>s)
			{
				sum-=arr[que.poll()];
			}
	
			if(s==sum)
			{
				a.add(que.peek()+1);
				a.add(i+1);
				return a;	 
			}	
		}	
	a.add(-1);
	return a;
		
	}
public static void main(String[] args)
{

	int arr[]={1,2,3,4,5,6,7,8,9,10};
	int s=15;
	System.out.println(SubArray(arr,s));
}
}