import java.util.*;
class Q4
{

	public static Queue<Integer> Sorting(int arr[])
	{
		Queue<Integer> q=new PriorityQueue<>();
		for(int num:arr)
		{
			q.add(num);
		}
	return q;
				
	}

	public static void main(String[] args)
	{
		int arr[]={0,2,1,2,0};
		System.out.println(Sorting(arr));
	}
}