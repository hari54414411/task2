import java.util.*;
class Q6
{

public static int[] method(String s)
{
int count1=0;
int count2=s.length();
int arr[]=new int[s.length()+1];

for(int i=0;i<=s.length;i++)
{
	if(s.charAt(i).equals('I'))
	{
		arr[i]=count1;
		count1++;

	}
	else if(s.charAt(i).equals('D'))
	{
		arr[i]=count2;
		count2--;
	}
	arr[i]=count2;
}
return arr;

}
public static void main(String[] args)
{
String s="IDID";
System.out.println(Arrays.toString(method(s)));

}
}