import java.util.*;
class Q1
{

public static void method(int index,String s[],List<List<String>> ans)
{

if(index==s.length)
{
	List<String> ds=new ArrayList<>();
	for(int i=0;i<s.length;i++)
	{
		ds.add(s[i]);
	}
ans.add(new ArrayList<>(ds));
return;

}

for(int i=index;i<s.length;i++)
{
	swap(i,index,s);
	method(index+1,s,ans);
        swap(i,index,s);
}
}


public static void swap(int i,int j,String s[])
{
	String c=s[i];
	s[i]=s[j];
	s[j]=c;
	
}
public static void main(String[] args)
{
String s[]={"A","B","C"};
List<List<String>> ans=new ArrayList<>();
method(0,s,ans);
System.out.println(ans);



}
}