class MaxWealth
{
public static void main(String[] args)
{
int arr[][]={{1,2,3},{3,2,1}};int max=0;int sum=0;

	for(int i=0;i<arr.length;i++)
	{

	sum=0;
		for(int j=0;j<arr[0].length;j++)
		{
			sum+=arr[i][j];
		}
		if(max<sum)
		{	
		max=sum;
		}

	}
System.out.println(max);

}

}