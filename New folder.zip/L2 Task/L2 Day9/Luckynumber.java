class Luckynumber
{
public static void main(String[] args)
{

int arr[][]={{3,7,8},{9,11,13},{15,16,17}};
int min=arr[0][0];

for(int i=0;i<arr.length;i++)
{
	for(int j=0;j<arr[0].length;j++)
	{	
		if(arr[i]<min)
		{	
		min=
		}
	}	
}