class Frogs {
    public static int minNumberOfFrogs(String croakOfFrogs) {
        int[] count = new int[5]; 
        int maxFrogs = 0;        int frogs = 0; 
        
        for (char c : croakOfFrogs.toCharArray()) {
            switch (c) {
                case 'c':
                    count[0]++;
                    frogs++;
                    maxFrogs = Math.max(maxFrogs, frogs);
                    break;
                case 'r':
                    count[1]++;
                    if (count[1] > count[0]) 
                        return -1;
                    break;
                case 'o':
                    count[2]++;
                    if (count[2] > count[1]) 
                        return -1;
                    break;
                case 'a':
                    count[3]++;
                    if (count[3] > count[2]) 
                        return -1;
                    break;
                case 'k':
                    count[4]++;
                    if (count[4] > count[3]) 
                        return -1;
                    frogs--;
                    break;
            }
        }
        
        return frogs == 0 ? maxFrogs : -1;
    }
public static void main(String[] args)
{
String  croakOfFrogs ="crcoakroak";
System.out.println(minNumberOfFrogs(croakOfFrogs));
}
}
