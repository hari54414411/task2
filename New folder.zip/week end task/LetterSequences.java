import java.util.HashMap;
import java.util.Map;

public class LetterSequences {

    public static int countSequences(String tiles) {
        Map<Character, Integer> letterCount = new HashMap<>();
        for (char c : tiles.toCharArray()) {
            letterCount.put(c, letterCount.getOrDefault(c, 0) + 1);
        }
                return backtrack(letterCount);
    }

    private static int backtrack(Map<Character, Integer> counter) {
        int count = 0;
                for (char letter : counter.keySet()) {
                       if (counter.get(letter) > 0) {
		count++;
              
                counter.put(letter, counter.get(letter) - 1);
                                count += backtrack(counter);
                               counter.put(letter, counter.get(letter) + 1);
            }
        }
        return count;
    }

    public static void main(String[] args) {
        String tiles1 = "AAB";
        System.out.println(countSequences(tiles1));  // Output: 8

        String tiles2 = "AAABBC";
        System.out.println(countSequences(tiles2));  // Output: 188
    }
}
