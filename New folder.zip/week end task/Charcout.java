class Charcout {
    public static void main(String[] args) {
      
        String S ="aba";
        int count = 0;
        
               for (int i = 0; i < S.length(); i++) {
                   count += expandAroundCenter(S, i, i);
            
            if (i < S.length() - 1 && S.charAt(i) == S.charAt(i + 1)) {
                count += expandAroundCenter(S, i, i + 1);
            }
        }
        
        // Print the count of special substrings
        System.out.println(count);
    }
    
 
    private static int expandAroundCenter(String s, int left, int right) {
        int count = 0;
        while (left >= 0 && right < s.length() && s.charAt(left) == s.charAt(right)) {
            count++;
            left--;
            right++;
        }
        
        return count;
    }
}
