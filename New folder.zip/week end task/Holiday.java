import java.io.BufferedReader;
import java.io.InputStreamReader;
 
class Holiday
 {
    public static void main(String args[] ) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine());
        char[] s = br.readLine().toCharArray();
        int[] count = new int[26];
     
        long ans = 0;
        for(int i=0; i<n; i++){
            int curr = 0;
            for(int j=i+1; j<n; j++){
                if(s[i]==s[j]){
               
                    ans += curr;
                }
                curr += count[s[j]-'a'];
            }
            count[s[i]-'a']++;
        }
        System.out.println(ans);
    }
}