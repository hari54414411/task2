import java.util.Scanner;

class Specialsubstring 
{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int k = scanner.nextInt();
        int m = scanner.nextInt();
        String s = scanner.next();
        
        StringBuilder transformedString = new StringBuilder(s);         
        int operations = 0;         
        for (int i = 0; i <= n - k; i++) {
            int onesCount = 0;
            
            for (int j = i; j < i + k; j++) {
                if (transformedString.charAt(j) == '1')
                    onesCount++;
            }
       
            if (onesCount > m) {
                operations += onesCount - m;       
                for (int j = i; j < i + k && onesCount > m; j++) {
                    if (transformedString.charAt(j) == '1') {
                        transformedString.setCharAt(j, '0');
                        onesCount--;
                    }
                }
            }
        }
        
        System.out.println(operations);
        System.out.println(transformedString.toString());
    }
}
