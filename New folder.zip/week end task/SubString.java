class SubString
{
public static void main(String[] args)
{
String s="cdbkdub";
int L=0;
int R=5;
	for(int i=L;i<=R;i++)
	{
		System.out.print(s.charAt(i));
	}
}
}