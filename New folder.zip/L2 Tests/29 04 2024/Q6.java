import java.util.*;
class Q6
{

	public static int[] method(int arr[],int element,int index)
	{
		int arrnew[]=new int[arr.length+1];
		int i=0;
		int j=0;
		while(i<arrnew.length)
		{
			if(i==index)
			{
				arrnew[i++]=element;
						
			}
			else
			{
			
				arrnew[i++]=arr[j++];
			}
				
			
		}

		return arrnew;
	}
	public static void main(String[] args)
	{

		int arr[]={1,2,3,4,5,6,7,8};
		int element=0;
		int index=3;
		System.out.println(Arrays.toString(method(arr,element,index)));
		
	}
}