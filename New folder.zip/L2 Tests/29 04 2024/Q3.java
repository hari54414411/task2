import java.util.*;
class Q3
{
	public static ArrayList<List> method(int arr[],int sum)
	{
	ArrayList<List> l=new ArrayList<>();
		for(int i=0;i<arr.length;i++)
		{
			int sum1=0;
			ArrayList<Integer> l1=new ArrayList<>();
			for(int j=i;j<arr.length;j++)
			{
				sum1+=arr[j];
				if(sum==sum1)
				{
					for(int k=i;k<=j;k++)
					{
						l1.add(arr[k]);
					}
					l.add(l1);
				}
			}
		}
		return l;
			
	}
	public static void main(String[] args)
	{
		int arr[]={ 1, 3, -7, 3, 2, 3, 1, -3, -2, -2};
		int sum=0;
		System.out.println(method(arr,sum));
	}
}