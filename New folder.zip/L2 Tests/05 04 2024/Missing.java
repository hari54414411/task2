class Missing
{
public static void method(int[] arr){
		int len=arr.length;
		int[] arr2=new int[len+1];

		for(int i:arr)
		{
			arr2[i]++;
		}
		for(int i=1;i<=len;i++)
		{
			if(arr2[i]==0)
			{
				System.out.println("Missing:"+i);
			}
 			else if(arr2[i]==2)
			{
				System.out.println("Repeating:"+i);
			}
		}
		
		
	}


public static void main(String args[])
{
		int[] arr={3, 1, 3};
		method(arr);
	}
}

