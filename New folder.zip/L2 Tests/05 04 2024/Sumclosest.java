class Sumclosest
{
public static void main(String[] args)
{
int arr[] = {1, 3, 4, 7, 10};
int x = 15;
int left=0;
int i=0,j=0;
int sum=0;
int max=0;
int right=arr.length-1;

	while(left<right)
	{
		sum=arr[left]+arr[right];
	
	if(sum>max&&sum<x)
	{
	max=sum;
	i=left;
	j=right;
	}
        else if(sum<x)
	{
	left++;
	}
	else
	{
	right--;
	}

	}
System.out.println(arr[i]+" "+arr[j]);

}
}