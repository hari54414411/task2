class RotateArrays
{
public static void rotate(int nums[])
{
int len=nums.length;
int temp=nums[len-1];
		for(int i=len-1;i>0;i--)
		{
			nums[i]=nums[i-1];
		}
		nums[0]=temp;
}
public static void main(String[] args)
{
int arr[] = {3,2,1};
int sum=0;

int max=0;
	for(int i=0;i<arr.length;i++)
	{
	sum=0;
	rotate(arr);
	for(int j=0;j<arr.length;j++)
	{
	sum+=arr[j]*j;
	}
	if(sum>max)
	{
	max=sum;
	}
	}
System.out.println(max);
}
}