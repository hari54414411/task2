import java.util.*;
class Repeats
{
public static void main(String[] args)
{
	int arr[] = {6, 10, 5, 4, 9, 120, 4, 6, 10};
	int ans=0;
	Map<Integer,Integer> map=new HashMap<>();
	for(int num:arr)
	{
	if(map.containsKey(num))
	{
	map.put(num,map.get(num)+1);
	}
	else
	{
	map.put(num,1);	
	}
	}
	
	for(int num:arr)
	{
	if(map.get(num)>1)
	{
        ans=num; 
	System.out.println(ans);
        break;	
	}	
	}
	

	
}
}