import java.util.*;
public class Maxi{
	public static void main(String args[]){
		int arr[]={34, 8, 10, 3, 2, 80, 30, 33, 1};
		System.out.println(maxDif(arr));
		
	}
	public static int maxDif(int arr[]){
		int n=arr.length;
		int max=-1;
		for(int i=0;i<n;i++){
			for(int j=n-1;j>i && (j-i)>max;j--)
			{
				if(arr[j]>arr[i]){

					max=(j-i)>max?(j-i):max;
				}
			}
		}
		return max;
	}
	

}