class Majority
{
public static void main(String[] args)
{
int arr[]={3, 3, 4, 2, 4, 4, 2, 4, 4};
int count=0;int majority=0;
int n=arr.length/2;
for(int num:arr)
{ 	
	
	if(count==0)
	{	
	majority=num;
	count++;
	}
	else if(majority==num)
	{
	count++;
	}
	else
	{
	count--;
	}

        
}
System.out.println(count+" "+majority);

}

}