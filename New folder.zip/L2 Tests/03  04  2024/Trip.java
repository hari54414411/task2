import java.util.*;
class Trip
{
public static void main(String[] args)
{
int arr[]={5,4,3,2,1};
int sum = 9;
Arrays.sort(arr);
int i;
for(i=0;i<arr.length;i++)
{
int left=i+1;int right=arr.length-1;
while(left<right)
{
int target=arr[left]+arr[i]+arr[right];
if(sum==target)
{
System.out.println(arr[i]+" "+arr[left]+" "+arr[right]);
break;
}
else if(sum<target)
{
right--;
}
else
{
left++;
}
}
}
}
}