class Jump
{
public static int method(int arr[])
{
int jump=0;int currentend=0;int max=0;
	for(int i=0;i<arr.length-1;i++)
	{
	max=Math.max(max,arr[i]+i);
	if(currentend==i)
	{	
	jump++;
	currentend=max;
	}
	}
return jump;

}
public static void main(String[] args)
{
int arr[] = {1, 3, 5, 8, 9, 2, 6, 7, 6, 8, 9};
System.out.println(method(arr));
}
}