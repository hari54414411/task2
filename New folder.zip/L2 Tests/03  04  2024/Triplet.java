class Triplet
{
public static void main(String[] args)
{
int arr[]={12, 3, 4, 1, 6, 9};
int sum = 24;
int left=0;int right=arr.length-1;
int i;
for(i=1;i<arr.length;i++)
{
int target=arr[left]+arr[i]+arr[right];
if(sum==target)
{
break;
}
else if(sum<target)
{
left++;
}
else
{
right--;
}

}
System.out.println(arr[left]+" "+);
}
}