import java.util.*;
class Q2
{
	public static void main(String[] args)
	{

			Scanner sc=new Scanner(System.in);
			System.out.println("Enter the number of test cases t:");
			int t=sc.nextInt();
				
			for(int i=0;i<t;i++)
			{
				System.out.println("Enter the number of cities:");
				int cities=sc.nextInt();
				System.out.println((1 << cities)-1);
			}
	

		}

}