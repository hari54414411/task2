class Q4
{
	public static int method(int arr[])
	{
		int n=1<<arr.length;
		int sum=0;
		int sum2=0;
		for(int i=0;i<n;i++)
		{
			sum=0;
			for(int j=0;j<arr.length;j++)
			{
				if((i&(1<<j))!=0)
				{
					
					sum^=arr[j];
				}	
			}
			sum2+=sum;
		}
return sum2;
	}

	public static void main(String[] args)
	{
		int arr[]={3,4,5,6,7,8};
		System.out.println(method(arr));
	}
}