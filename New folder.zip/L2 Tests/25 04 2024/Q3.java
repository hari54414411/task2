
import java.util.*;
class Q3
{

		public static int method(int arr[])
		{
			
			int sum=0;
			while(arr.length>1)
			{
				int newarr[]=new int[arr.length-1];
				
				for(int j=0;j<arr.length-1;j++)
				{
					newarr[j]=(arr[j]+arr[j+1])%10;
						
				}
			arr=newarr;
			
			}
		return arr[0];
		}

		public static void main(String[] args)
		{
			int arr[]={2,3,4,5};
			System.out.println(method(arr));
			
		}

}