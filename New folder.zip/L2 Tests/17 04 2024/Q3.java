class Q3
{
public static void main(String [] args){
   String s="codesleepcode";
   char c=s.charAt(0);
			String a="";
			String b="";
			int k=0;

			for(int i=0,j=1;j<s.length();j++){
				if(s.charAt(j)==c){
					k=j;
					while(j<s.length()&&s.charAt(i)==s.charAt(j))
					{
					a+=s.charAt(i++)+"";
					b+=s.charAt(j++)+"";
					}
						if(a.equals(b)){
						System.out.println("X is : "+a);
						if(s.substring(a.length(),k).length()>1){
							System.out.println("Y is :"+s.substring(a.length(),k));
						}
						break;
					}
					else{
					j=k;
					i=0;	
					}
				}
			}
	}
}

