import java.util.*;
class Q2
{

public static List<List> method(String s[])
{
	int n=1<<s.length;
	List<List> ans=new ArrayList<>();
	for(int i=0;i<n;i++)
	{
		List<String> l=new ArrayList<>();
		for(int j=0;j<s.length;j++)
		{
			if((i&(1<<j))!=0)
			{	
				l.add(s[j]);
			}
		}
		ans.add(l);
	}	
	return ans;
}

public static void main(String[] args)
{
String s[]={"x", "y", "z"};
System.out.println(method(s));

}
}