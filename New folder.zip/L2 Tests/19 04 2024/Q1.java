import java.util.*;
class Q1
{
public static int[] nextGreaterElement(int[] nums1, int[] nums2)
{
          for(int i=0;i<nums1.length;i++){
            boolean flag=false;
            for(int j:nums2){
                if(j==nums1[i]){
                    flag=true;
                }
                if(flag && j>nums1[i]){
                    nums1[i]=j;
                    flag=false;
                    break;
                }
            }
            if(flag)nums1[i]=-1;
        }
        return nums1;
    }
	public static void main(String args[])
	{
		int[] num1={4,1,2};
		int[] num2={1,3,4,2};
		System.out.println(Arrays.toString(nextGreaterElement(num1,num2)));
		
	}
}