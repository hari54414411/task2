class Q3{
    public static String toHex(int num) {
        if (num == 0) return "0";
        StringBuilder sb = new StringBuilder();
        while (num != 0) {
            int digit = num & 0xf;
            sb.append(digit < 10 ? (char) ('0' + digit) : (char) ('a' + digit - 10));
            num >>>= 4; 
        }
        return sb.reverse().toString();
    }

    public static void main(String[] args) {
      
        int num1 = 26;
        System.out.println(toHex(num1)); 
        
  
        int num2 = -1;
        System.out.println(toHex(num2)); 
    }
}
