import java.util.*;
class Rotate
{
public static void rotate(int arr[],int low,int high)
{
	while(low<=high)
	{
	int temp=arr[low];
	arr[low]=arr[high];
	arr[high]=temp;
        low++;
	high--;
	}

}
public static void main(String[] args)
{
int arr[]={2,3,4,5,6};
int timerotate=1;
rotate(arr,0,arr.length-1);
rotate(arr,0,timerotate-1);
rotate(arr,timerotate,arr.length-1);
for(int i=0;i<arr.length;i++)
{
System.out.print(arr[i]+" ");
}	
}
}