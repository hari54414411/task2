import java.util.*;
class Pair1
{
public static int method(int arr[],int sum)
{
Map<Integer,Integer> map=new HashMap<>();

	
	int pair=0;
	for(int num:arr)
	{
		if(map.containsKey(num))
		{
			map.put(num,map.get(num)+1);
		}
		else
		{
			map.put(num,1);
		}
	}

	for(int num:arr)
	{
		int count=sum-num;
		if(map.containsKey(count))
		{
		pair+=map.get(num);
			if(count==num)
			{
			pair--;
			}
		}
	}
return pair/2;
	
}
public static void main(String[] args)
{
int arr[]={1, 5, 7, -1, 5};
int sum=6;
System.out.println(method(arr,sum));
}
}