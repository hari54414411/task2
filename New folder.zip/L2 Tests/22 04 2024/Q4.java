
import java.util.*;
public class Q4
{
	public static void main(String args[])
	{
		String ip="2019-02-10";
		String[] arr=ip.split("-");
		boolean is31=true;
		int days=0;
		for(int i=1;i<Integer.parseInt(arr[1]);i++ ){
			if(i==7) is31=true;
			if(is31){
				days+=31;
				is31=false;
			}
			else {
				days+=30;
				is31=true;
			}
			
		}
		int year=Integer.parseInt(arr[0]);
		int mon=Integer.parseInt(arr[1]);
		int d=Integer.parseInt(arr[2]);
		days+=d;
		if(mon>2){
			if(IsLeap(year))
				days-=1;
			else days-=2;
		}
		System.out.println(days);
		
	}
	static boolean IsLeap(int y){
    if((y % 400 == 0) || ((y % 100 != 0) && (y % 4 == 0))){
      return true;
    }
    else{
      return false;
    }
  }
}