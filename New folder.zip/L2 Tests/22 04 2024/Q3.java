class Q3
{
	public static int method(int arr[][])
	{
		int max=0;
		
		for(int i=1;i<arr.length;i++)
		{
			int x=Math.abs(arr[i][0]-arr[i-1][0]);
			int y=Math.abs(arr[i][1]-arr[i-1][1]);
			max+=Math.max(x,y);
		}	
return max;
	}

	public static void main(String[] args)
	{
		int arr[][]={{1,1},{3,4},{-1,0}};
		System.out.println(method(arr));
	}

}