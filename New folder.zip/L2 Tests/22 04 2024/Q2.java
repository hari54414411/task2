import java.util.*;
class Q2
{

	public static String findDifference(String[] words) 
	{
        int n = words[0].length();
        
 
        int[] diff = new int[n - 1];
        for (int i = 0; i < n - 1; i++) 
	{
            diff[i] = Math.abs(words[0].charAt(i + 1) - words[0].charAt(i));
        }
        
            for (int i = 1; i < words.length; i++) 
            {
            int[] currentDiff = new int[n - 1];
            for (int j = 0; j < n - 1; j++) 
	    {
                currentDiff[j] = Math.abs(words[i].charAt(j + 1) - words[i].charAt(j));
            }
            
            if (!Arrays.equals(diff, currentDiff)) 
	    {
                return words[i];
            }
        }
        
        return ""; 
    }
	public static void main(String[] args)
	{
		String s[]={"adc","wzy","abc"};	
		System.out.println(findDifference(s));
	}
}