class Q1
{
	public static int WaterBottle(int numBottles,int numExchange)
	{
        int totalBottles = numBottles;        
        int emptyBottles = numBottles;         
        while (emptyBottles >= numExchange) 
	{
            int exchangedBottles = emptyBottles / numExchange; 
            totalBottles += exchangedBottles;
            emptyBottles = exchangedBottles + (emptyBottles % numExchange); 
        }
        
        return totalBottles;
	}

	public static void main(String[] args)
	{
		int numBottles=15;
		int numExchange=4;
		System.out.println(WaterBottle(numBottles,numExchange));
	}
}