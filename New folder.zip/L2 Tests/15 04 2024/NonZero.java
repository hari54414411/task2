class NonZero
{
public static boolean method(int arr[][])
{
int m=arr.length;int n=arr[0].length;
		for(int i=0;i<m;i++)
		{
			for(int j=0;j<n;j++)
			{	
				
				if(i==j || i+j==n-1)
				{
					if(arr[i][j]==0)
					{
						return false;
					}
					else continue;
				}
				else if(arr[i][j]!=0)
				{ 
					return false;
				}
			}
		}
		return true;
}
public static void main(String[] args)
{
//int matrix[][]={{2,0,0,1},{0,3,1,0},{0,5,2,0},{4,0,0,2}};
int matrix[][]={{5,7,0},{0,3,1},{0,5,0}};
System.out.println(method(matrix));

}
}