class SumMatrix
{

	public static boolean method(int matrix[][])
	{
		int sum=0;
		int sum2=0;
		for(int i=0;i<matrix.length;i++)
		{
			sum+=matrix[0][i];	
		}
	
		for(int i=0;i<matrix.length;i++)
		{
		sum2=0;
			for(int j=0;j<matrix[0].length;j++)
			{
				sum2+=matrix[i][j];	
			}
			if(sum!=sum2)
			{
				return false;
			}
			
		}
return true;

	}
public static void main(String[] args)
{
	int martix[][]={{1,1,1},{1,2,3},{1,2,3}};
	System.out.println(method(martix));

}
}