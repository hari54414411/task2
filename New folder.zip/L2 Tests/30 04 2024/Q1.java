import java.util.*;
class Q1
{

	public static boolean method(String s,String goal)
	{
		char c[]=s.toCharArray();
	
		char temp=c[0];
		c[0]=c[1];
		c[1]=temp;
		String s1="";
		for(char c1:c)
		{
			s1+=c1;	
		}
		return s1.equals(goal);
	}

	public static void main(String[] args)
	{
		String s="ab";
		String goal="ab";
		System.out.println(method(s,goal));
	}
}