class Q2
{

	public static String method(int n)
	{
		StringBuilder sb=new StringBuilder();
		String s1="";
		int i=1;
		while(n>0)
		{
			sb.append(String.valueOf(n%10));
			n=n/10;
			if(i%3==0&&n>0)
			{
				sb.append(".");
			}
			i++;
		}	
		for(char c:sb.toString().toCharArray())
		{
			s1=c+s1;	
		}
		return s1;		
	}

	public static void main(String[] args)
	{
		int s=2000000;
		System.out.println(method(s));
	}
}