class Q3
{
	public static String method(String s)
	{
		String ans="";

		for(int i=0;i<s.length();i++)
		{
			if(s.charAt(i)!=' '&&s.charAt(i)!='-')
			{
				ans+=s.charAt(i);
			}
		}	

		while(i<ans.length())
		{
			
		}
		
		return ans;
	}

	public static void main(String[] args)
	{
		String s="1-23-45 6";
		System.out.println(method(s));
	}
}