class Q5{
    public static int method(String text, String brokenLetters) {
        
        String[] words = text.split(" ");
        int count = 0;

        for (String word : words) 
	{
            

            boolean isBroken = false;
            for (int i = 0; i < word.length(); i++) {
                char letter = word.charAt(i);
               

                for (int j = 0; j < brokenLetters.length(); j++) 
		{
                    if (brokenLetters.charAt(j) == letter) 
		    {
                        isBroken = true;
                        break;
                    }
                }

                if (isBroken) 
		{
                    break;
                }
            }
            

            if (!isBroken) 
	    {
                count++;
            }
        }
        return count;
    }

    public static void main(String[] args) {
      
        System.out.println(method("hello world", "ad"));    
	System.out.println(method("leet code", "lt")); 
        System.out.println(method("leet code", "e"));      
    }
}
