class Q4
{
	public static void main(String args[])
	{
		String s="a1";
		System.out.println(method(s));
		
	}
	public static boolean method(String c){
		int i=c.charAt(0)-'a';
		int j=c.charAt(1)-'1';
		if(i%2==0){
			if(j%2==0){
				return false;
			}
			else {
				return true;
			}
		}
		else{
			if(j%2==0){
				return true;
			}
			else {
				return false;
			}

		}
	}
}