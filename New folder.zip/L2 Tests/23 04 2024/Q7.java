class Q7
{
	public static void main(String[] args)
	{
		int n=5;
		int id=1;
		int arr[][]=new int[5][5];
		int top=0;int right=arr.length-1;
	        int left=0;int bottom=arr.length-1;

	while(top<=bottom && left<=right)
	{
		for(int i=left;i<=right;i++)
		{
		arr[top][i]=id++;
		}
		top++;
		
		for(int i=top;i<=bottom;i++)
		{
		arr[i][right]=id++;
		}
		right--;
		
		if(top<=bottom)
		{
			for(int i=right;i>=left;i--)
			{
			arr[bottom][i]=id++;	
			}
			bottom--;
		}
		
		if(left<=right)
		{
		for(int i=bottom;i>=top;i--)
		{
		arr[i][left]=id++;
		}
		left++;
		}


	}
	for(int i=0;i<arr.length;i++)
	{
		for(int j=0;j<arr[0].length;j++)
		{
			System.out.print(arr[i][j]+" ");
		}
	System.out.println();
	}



	}
}