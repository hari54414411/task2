class Q6
{
	public static void main(String[] args)
	{
		int n=9;
		int mid=n/2;

		for(int i=0;i<n;i++)
		{

			for(int j=0;j<n;j++)
			{
				if(i+j==mid||j-i==mid||i-j==mid||i+j==(n+ (n/2))-1)
				{
					System.out.print("*");
				}
				else
				{
					System.out.print(" ");
				}
			}
System.out.println();

		}
	}

}