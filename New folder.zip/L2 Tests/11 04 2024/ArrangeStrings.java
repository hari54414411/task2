class ArrangeStrings
{
public static void main(String[] args)
{
	String s="aaaabbbbcccc";
	StringBuilder sb=new StringBuilder();
	int len=s.length();
	char c[]=new char[26];
	for(int i=0;i<s.length();i++)
	{
		c[s.charAt(i)-'a']++;
	}

	while(0<len)
	{
		for(int i=0;i<26&&len>0;i++)
		{	
			if(c[i]>0)
			{
				sb.append((char)('a'+i));
				c[i]--;
				len--;
				
			}
		}

	for(int i=25;i>=0&&len>0;i--)
		{	
			if(c[i]>0)
			{
				sb.append((char)('a'+i));
				c[i]--;
				len--;
				
			}
		}

	}
System.out.println(sb);



}
}

