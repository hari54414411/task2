import java.util.*;
class Path
{
	public static void main(String[] args)
	{
		String s="NESWW";
		Set<String> visited = new HashSet<>();
                visited.add("0,0");
		int s1=0,s2=0;
		boolean flag=false;
		for(char c:s.toCharArray())
		{
			if(c=='N')
			{
				s1++;
			}
			else if(c=='S')
			{
				s1--;
			}
			else if(c=='E')
			{
				s2++;
			}
			else 
			{
				s2--;
			}
	    String current = s1 + "," + s2;
            if (visited.contains(current)) 
	    {
                   flag=true;
		    break;
            }
            visited.add(current);
		}
		if(flag)
		{
			System.out.println("true");
		}
		else
		{
			System.out.println("false");
		}
	}
}

