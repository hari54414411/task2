class OddOccurrences 
{
    public static void main(String[] args) {
        int n = 4;
	String ans="";
	if(n%2==0)
	{	
		for(int i=0;i<n-1;i++)
		{
			ans+='a';
		}	
		ans+='b';
	}
	else
	{
		for(int i=0;i<n;i++)
		{
			ans+='a';
		}
	
	}
	System.out.println(ans);
        
    }
}
