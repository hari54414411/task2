import java.util.*;
class Q5
{
public static void main(String[] args)
{
String str="()";

Stack<Character> st=new Stack<>();
boolean flag=false;
		for(int i=0;i<str.length();i++)
		{
			char c=str.charAt(i);
			if(c=='{' || c=='[' || c=='(')
			{
				st.push(c);
			}
			else{

				if(st.isEmpty())
				{
					flag=true;
					break;
				}

				char temp=st.pop();

				if(temp=='(' && c!=')')
				{
					flag=true;
					break;
				}
				else if(temp=='{' && c!='}')
				{
					flag=true;
					break;
				}
				else if(temp=='[' && temp==']')
				{
					flag=true;
					break;
				}
			}
			
		}

		if(!flag && st.isEmpty())
		{
			System.out.println(true);
		}
		else
		{
			System.out.println(false);
		}
	}
}
