class Q2
{
public static int Missingnumber(int num[])
{
	int n=num.length;
        int m=n*(n+1)/2;
	int sum=0;

for(int i=0;i<n;i++)
{
sum+=num[i];
}
return m-sum;
}
public static void main(String[] args)
{
	int num[]={3,0,1};
	System.out.println(Missingnumber(num));

	int num1[]={9,6,4,2,3,5,7,0,1};
	System.out.println(Missingnumber(num1));

	int num2[]={0,1};
	System.out.println(Missingnumber(num2));

}
}