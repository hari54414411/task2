class Q4
{
public static int Fibonacci(int n,int f0,int f1)
{
if(n==0)
{
	return f0+f1;
}

return Fibonacci(n-1,f1,f0+f1);

}
public static void main(String[] args)
{
	int n=4;
	int f0=0;
        int f1=1;

	System.out.println(Fibonacci(n-2,f0,f1));
}
} 