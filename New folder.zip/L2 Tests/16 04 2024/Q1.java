class Q1
{
public static boolean isPower(int num,int pow,int curr)
{
		if(curr>num) 
		{
			return false;
		}
		if(curr==num)
		{
			return true;
		}
		if(num==1)
		{
			return false;
		}

		return isPower(num,4,curr*pow);
}

public static void main(String args[])
{
		int num=16;
		System.out.println(isPower(num,4,1));
}
}