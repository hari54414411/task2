class Q2
{

	public static long method(int n)
	{
   		int ans=0;
    		for(int i=0;i<32;i++)
		{
    			ans=( ans << 1 ) | ( n & 1 );         
    			n = n >> 1;   
		}
	return ans;
}

	public static void main(String[] args)
	{
		int n=Integer.MIN_VALUE;
		System.out.println(method(n));
		
	}
}