class Q1
{

	public static int method(int left,int right)
	{

		if(left==0||right==0)
		{
			return 0;
		}
		int count=left;
		left++;
		while(left<right)
		{
			count&=left;
			left++;
				
		}
return count;
	}
	public static void main(String[] args)
	{
		int left=5;
		int right=7;
		System.out.println(method(left,right));
	}
}