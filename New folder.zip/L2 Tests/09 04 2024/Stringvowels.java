import java.util.*;
class Stringvowels
{
 public static int method(String s1) {
        int res = 0;
        int n = s1.length();

        for (int i = 0; i < n; i++)
	{
            if ("aeiou".indexOf(s1.charAt(i)) >= 0)
	    {
                res += 1;
	    }
	}
        return res;
    }

public static void main(String args[])
{
	
	Scanner d = new Scanner(System.in);
	System.out.println("Enter the String");
	String s=d.next();
        int count=0;

		for(int i=0;i<s.length();i++)
		{
		String c="";
			for(int j=i+1;j<=s.length();j++)
			{
		
                	c=s.substring(i,j);
			System.out.println(c);
			count+=method(c);

			}

		}
	

		System.out.println(count);

}



}

