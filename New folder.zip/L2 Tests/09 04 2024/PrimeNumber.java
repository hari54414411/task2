class PrimeNumber
{
public static void main(String[] args)
{
   int count=0;
int num=10;
    
  for(int n=0;n<num;n++)
{  
int i,m=0,flag=0;  
  m=n/2;      
  if(n==0||n==1)
  {  
   count=0;    
  }
  else
  {  
   	for(i=2;i<=m;i++)
   	{      
    	if(n%i==0)
    	{      
           
     	flag=1;      
     	break;  
    
    	}      
   	}      
   	if(flag==0)  
	{ 
	count++;
	}  
  } 
}
	System.out.println(count);
}    
}   