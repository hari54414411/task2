import java.util.*;


class LongestSubstring {
    public static int method(String s, int k) {
        int maxLength = 0;
        int maxCount = 0;

        Map<Character, Integer> map = new HashMap<>();

        int left = 0;
        for (int right = 0; right < s.length(); right++) 
	{
            char currentChar = s.charAt(right);
	
            map.put(currentChar, map.getOrDefault(currentChar, 0) + 1);

            maxCount = Math.max(maxCount, map.get(currentChar));

            
            while (right - left + 1 - maxCount > k) 
	    {
                char leftChar = s.charAt(left);
	
                map.put(leftChar, map.get(leftChar) - 1);

                left++;
            }

            maxLength = Math.max(maxLength, right - left + 1);
        }

        return maxLength;
   }

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);

		System.out.println("Enter the String:");
		String s=sc.next();

		System.out.println("Enter the K values:");
		int k=sc.nextInt();

		System.out.println("MaxLength : "+method(s,k));
	
	}
}