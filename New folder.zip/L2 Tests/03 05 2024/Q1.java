import java.util.*;
class Q1
{

	public static int method(String s,int k)
	{

	int max=0;

	HashMap<Character, Integer> charCount = new HashMap<>();
        for (char c : s.toCharArray()) 
	{
            charCount.put(c, charCount.getOrDefault(c, 0) + 1);
        }
        
        
        for (char c : charCount.keySet()) 
	{
            if (charCount.get(c) >= k) 
	   {
          	max+=charCount.get(c);
            }
        }
        


       
        
        return max;
				
	}
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);

		System.out.println("Enter the String:");
		String s=sc.next();

		System.out.println("Enter the K values:");
		int k=sc.nextInt();

		System.out.println("MaxLength : "+method(s,k));
	}
}