import java.util.*;
class Q2
{

	public static boolean method(String s1,String s2)
	{
		Stack<Character> stack1=new Stack<>();
		Stack<Character> stack2=new Stack<>();

		for(int i=0;i<s1.length();i++)
		{
			if(s1.charAt(i)!='#')
			{
				stack1.push(s1.charAt(i));
			}
			else
			{
				stack1.pop();
			}	
		}

		for(int i=0;i<s2.length();i++)
		{
			if(s2.charAt(i)!='#')
			{
				stack2.push(s2.charAt(i));
			}
			else
			{
				stack2.pop();
			}	
		}
return stack1.toString().equals(stack2.toString());
	}
	
	public static void main(String[] args)
	{
		String s1="a#c";
		String s2="b";

		System.out.println(method(s1,s2));
	}

}