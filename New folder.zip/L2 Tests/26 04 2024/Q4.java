import java.util.*;
class Q4
{
    public static int[] finalPrices(int[] prices) {
        int n = prices.length;
        int[] answer = new int[n];
        Stack<Integer> stack = new Stack<>();

        for (int i = 0; i < n; i++) {
            while (!stack.isEmpty() && prices[stack.peek()] >= prices[i]) {
                int index = stack.pop();
                answer[index] = prices[index] - prices[i];
            }
            stack.push(i);
        }

        while (!stack.isEmpty()) {
            int index = stack.pop();
            answer[index] = prices[index];
        }

        return answer;
    }


    public static void main(String[] args) {
        int[] prices1 = {8, 4, 6, 2, 3};
        int[] prices2 = {1, 2, 3, 4, 5};
        int[] prices3 = {10, 1, 1, 6};

        System.out.println(Arrays.toString(finalPrices(prices3)));
           }
}
