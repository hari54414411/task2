import java.util.*;
class Q3
{

	public static int method(String s)	
	{
		Stack<Character> stack=new Stack<>();
		int max=0;
		for(int i=0;i<s.length();i++)
		{
			if(s.charAt(i)=='(')
			{
				stack.push(s.charAt(i));
				max=Math.max(max,stack.size());
			}
			else if(s.charAt(i)==')')
			{
				
				stack.pop();
			}
		}
return max;
	}

	public static void main(String[] args)
	{

		String s="(1)+((2))+(((3)))";
		System.out.println(method(s));	
	}

}