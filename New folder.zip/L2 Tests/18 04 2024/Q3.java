class Q3
{
public static int method(int arr[],int i)
{
	
	if(arr.length<=i)
	{
		return arr[arr.length-1]+1;
	}
	if(arr[i]==i)
	{
		return method(arr,i+1);
	}
	else
	{
		return i;
	}			

}
public static void main(String[] args)
{
	int arr[]={0, 1, 2, 3, 4, 5, 6};
	System.out.println(method(arr,0));
}
}