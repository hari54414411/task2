class Q2
{

public static int method(int arr[],int target,int start,int end)
{
	
	int mid=0;

	
	while(start<=end)
	{
		mid=(start+end)/2;
		if(target==arr[mid])
		{
			return mid;
		}
		else if(mid<target)
		{
			start++;
		}
		else 
		{
			end--;
		}
	method(arr,target,start,end);
       }
return -1;

       
	
}
public static void main(String[] args)
{
int arr[]={2, 3, 5, 7, 9};
int target=7;
int start=0;
int end=arr.length;

System.out.println(method(arr,target,start,end));	
}
}