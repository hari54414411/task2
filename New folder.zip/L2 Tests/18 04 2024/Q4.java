import java.util.*;
class Q4
{
public static void method(int arr[],int i,int j,int m)
{

	if (i >= j || j - i + 1 < m) {
            return;
        }

        for (int k = 0; k < m / 2; k++) 
	{
            int temp = arr[i + k];
            arr[i + k] = arr[i + m - 1 - k];
            arr[i + m - 1 - k] = temp;
        }

        method(arr,  i+ m, j, m);
}
public static void main(String[] args)
{
int arr[]={1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
int i=3;
int j=4;
int m=3;
method(arr,i,j,m);
System.out.println(Arrays.toString(arr));

}
}