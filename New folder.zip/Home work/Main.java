class Main
{
	public static void main(String[] args)
	{
		C2 c=new C2();
		c.method();
		c.method2();
	}
}



interface C3
{
	void method();
}

interface C4
{
	void method2();
}


class C2 implements C3,C4
{
	public void method()
	{
		System.out.println("Parent class interface 1");
	}

	public void method2()
	{
		System.out.println("Parent class interface 2");

	}
	
}


class C1 extends C2
{
	public void method()
	{
		System.out.println("Sub Class");
	}

	
}

