import java.util.*;
class Merge
{
public static void main(String[] args)
{
int arr[]={2, 3, 3, 4, 5, 7, 9};
int arr1[]= {1, 2, 4, 5, 7, 7, 9};
List<Integer> l=new ArrayList<>();
int i=0;int j=0;
int pre=0;

while(i<arr.length&&j<arr1.length)
{
	while(arr[i]==pre)
	{
	i++;
	}

	while(arr1[j]==pre)
	{
	j++;
	}

	if(arr[i]<arr1[j])
	{
	l.add(arr[i]);
	pre=arr[i];
	i++;
	}
	else if(arr[i]>=arr1[j])
	{
	l.add(arr1[j]);
	pre=arr1[j];
	j++;
	}
	else
	{
	l.add(arr[i]);
	i++;
	j++;
	}
}




	System.out.println(l);

}
}